package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceEntryRockyTest {

@Test public void testGetSubDictionary() throws IOException { assertTrue(entry instanceof COSArray); PDAnnotationWidget widget = createSimpleFormField(); try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) { COSBase base = ((COSObjectable<?>)widget).toCosObjec().getCOSObject(); IOUtils.copy((InputStream)base, baos); byte[] bytes = baos.toByteArray(); Document document = loadDocumentWithoutDecryption(bytes); Assertions.assertNotNull(document.getPageByIndex(0), "The page should be present."); } }

}