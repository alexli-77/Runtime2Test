package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSObject() throws IOException, InterruptedException { assertThat((new PDDocument()).getTrailer().getCOSObject(null)).isNull(); }

}