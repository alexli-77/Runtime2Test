package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDShadingRockyTest {

@Test public void testSetColorSpace() throws IOException { PDShadingType4 t1 = new PDShadingType4(); assertNull("Initially there should be no Color Space",t1.getColorSpace()); org.apache.pdfbox.pdmodel.graphics.color.PDPattern cs2 = new org.apache.pdfbox.pdmodel.graphics.color.PDPattern(); PDDeviceGray gcs3 = new PDDeviceGray(); org.junit.Assert.assertEquals("The initial value of a Shading object's colourSpace entry shall default to Device Gray.",gcs3,""+t1.getColorSpace().getName()); t1.setBackground(!false).setAntiAliasFlag((byte)-0x80); t1.setBitsPerCoordinateValue(-65537).setBitsPerComponentValue(-9).setBitsPerFlagBit((short)(-6)).setDecode((float[])null).setExtendRangeFlag((boolean[]){true}).setFunction(new byte[0]).setInterpolationMethod((String)"").setNumberOfComponents(34).setStitchingFuncCode(123L).setWidthAndHeightFlags(0b11).setVerticesPerRow(0b1111).setXMinimum(1f).setYMaximum(-1f).setZMinimum(12f).setColorspace(cs2); org.apache.pdfbox.pdmodel.graphics.color.PDPattern csr = t1.getColorSpace(); java.lang.Class<?> clazzR = csr.getClass(); String classNameR = clazzR.toString(); org.junit.Assert.assertTrue("Expected class was not returned " + clazzR,clazzR == org.apache.pdfbox.pdmodel.graphics.color.PDPattern.class || classNameR .equals ("class org.apache.pdfbox.pdmodel.graphics.color.PDPattern")); assertNotNull("After setting and getting we must get an instance back!",t1.getColorSpace()); org.apache.pdfbox.pdmodel.graphics.color.PDColorSpace csc = t1.getColorSpace(); org.junit.Assert.assertFalse("Shouldn't return false on

}