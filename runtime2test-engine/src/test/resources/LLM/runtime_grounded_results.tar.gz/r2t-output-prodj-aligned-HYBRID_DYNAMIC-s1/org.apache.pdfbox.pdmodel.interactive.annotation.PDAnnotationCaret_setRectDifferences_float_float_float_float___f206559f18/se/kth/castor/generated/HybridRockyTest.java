package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationCaretRockyTest {

@Test public void testSetGetRect() throws Exception{ PDAnnotationWidget widget1 = createDefaultPDAnnotations("test", null).getFirstPageChildOfTypeOrNull(PDAnnotationText.class); Assertions.assertNotEquals(-20f,widget1.getQuadPoints()); }

}