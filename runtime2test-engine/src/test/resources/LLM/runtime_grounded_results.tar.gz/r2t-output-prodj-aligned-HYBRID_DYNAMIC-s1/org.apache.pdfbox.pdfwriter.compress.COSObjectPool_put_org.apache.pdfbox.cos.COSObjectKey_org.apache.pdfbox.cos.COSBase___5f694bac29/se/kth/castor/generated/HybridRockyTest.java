package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSObjectPoolRockyTest {

@Test public void testPut() throws Exception { PdfDictionary dictionary1 = new PdfDictionary(); dictionary1.addItem("Hello", (PdfString)"World"); document.trailer().replaceItem(new COSObjectKey(256789L),dictionary1 ); assertEquals(document.xrefTracker.sizeOfAllObjectsIncludingFreeListAndCompressedStreams(),34); String pdfText = contentToString(writerFileContent[0]); System.out.println("\n\ndocument :"+pdfText+" \n\n"); writer.close(); reader = new PdfReader(destinationFolder + filename+".pdf"); outWriter = new FileOutputStream(filename + ".txt"); IOUtils.copy(reader.extractPagesToByteArrayAsStream(null)[0], outWriter); outWriter.flush(); outWriter.close(); pdfText = readFromResourceDir(filename+".txt").trim(); Assertions.assertNotNull(pdfText,"Document does contain Hello World!"); Assertions.assertTrue(!pdfText.isEmpty(),"There are characters in Document."); }

}