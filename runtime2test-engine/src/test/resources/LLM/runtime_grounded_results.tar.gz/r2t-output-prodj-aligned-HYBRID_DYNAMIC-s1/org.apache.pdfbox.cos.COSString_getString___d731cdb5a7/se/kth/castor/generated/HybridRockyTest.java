package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStringRockyTest {

@Test public void testGetStringWithBomUtf8() throws Exception { byte[] bomBytes = "\uFEFF".getBytes("utf-8"); String expectedValue = "\"\uD7FF\r\n\""; assertEquals(expectedValue, new PdfBoxCosString(bomBytes).getString()); }

}