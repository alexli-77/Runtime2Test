package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferedFileRockyTest {

@Test public void testCreateView() throws Exception { RandomAccessReadSource rarSrc = (RandomAccessReadSource) factory.createOrOpen("testfile"); Assertions.assertNotNull(rarSrc); org.junit.jupiter.api.Assertions.assertTrue(((org.apache.pdfbox.pdmodel.common.filespecification.PDStreamInputStreamAdapter) rarSrc).getWrappedObject().toString().startsWith("/R")); final byte[] expectedData = this.readExpectedContentAsBytes(); try (final InputStream inputstream = new ByteArrayOutputStream().toByteArrayInputStream(expectedData)) { rarSrc.writeTo(inputstream); IOUtils.closeQuietly(inputstream); org.junit.jupiter.api.Assertions.assertEquals(IOUtils.EOF, inputstream.available()); String s; while (-1 != (s = readFromRAF(raf)).length()) System.out.println(s + "\n\t" + getClass().getName()); org.junit.jupiter.api.Assertions.assertFalse(new File(tempFolder.resolve("testfile").normalize()).exists(), tempFolder.resolve("testfile").normalize().getAbsolutePath()); } catch (@SuppressWarnings("unused") IOException e) {} finally { closeAllResourcesAndDeleteFiles(false, true, tempFolder.resolve("testfile"), tempFolder.resolve(".tmp-testfile")); } }

}