package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDColorRockyTest {

@Test public void testGetComponentsEmptyColorSpaces() throws Exception { assertThat("Invalid number of components", instance().getComponents(), hasSize(0)); }

}