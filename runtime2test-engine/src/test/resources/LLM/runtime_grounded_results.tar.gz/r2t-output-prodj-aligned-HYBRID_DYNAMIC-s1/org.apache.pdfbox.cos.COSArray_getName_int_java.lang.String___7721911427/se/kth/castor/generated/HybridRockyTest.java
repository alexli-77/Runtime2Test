package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testGetName() throws Exception { COSBase[] values1 = new COSBased[]{new COSInteger((long)2), new COSFloat(.5f)}; assertEquals("2", list1.getString(0)); assertNull(list1.getString(-3)); assertNotNull(list1.toString()); }

}