package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceContentStreamRockyTest {

@Test public void testSetStrokingColorOnDemandWithNullOrEmptyValueShouldNotWriteToOutputStreamAndReturnFalse() throws Exception { assertThat((boolean)$CLASS$.createDefault().setStrokingColorOnDemand(null)).isEqualTo($BOOL$(false)); }

}