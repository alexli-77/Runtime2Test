package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testToFloatArray() throws Exception { assertEquals("array length", 3 , cosArrya.toFloatArray().length ); }

}