package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDColorRockyTest {

@Test public void testToCosArrayPatternNull() throws Exception { PDDeviceRGB rgb = new PDDeviceRGB(); assertEquals("[0 1 2]", Arrays.toString(rgb.toColorSpace().getDefaultDecode())); }

}