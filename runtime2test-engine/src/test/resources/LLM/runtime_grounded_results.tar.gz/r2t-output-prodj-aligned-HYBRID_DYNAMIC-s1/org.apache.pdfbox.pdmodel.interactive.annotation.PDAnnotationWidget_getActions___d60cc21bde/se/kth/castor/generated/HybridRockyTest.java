package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public void testGetActions() throws IOException { PDAcroForm form = acroForm(); assertNotNull("Should have had an Actions", form.getFieldByFullyQualifiedName("test").getActions()); }

}