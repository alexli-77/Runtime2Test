package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public void testGetSetAction1427356908() throws IOException, InterruptedException { PDAnnotationWidget widget = new PDAnnotationWidget(); Assertions.assertNull("Default value", widget.getAction()); PDFont font = new PdfBoxFont("Helvetica"); String text = "Some Text"; byte[] data = FontUtils.convertStringToBytes(text, Charsets.ISO_8859_1.name(), 1f); COSStream stream = document.addFile(data).toByteArrayResource()).build(); font.setDescriptor((PDCIDFontType0DescendantFont)document.loadCidFontFromFDFDictionary(stream)); PDAcroForm acroform = form.getAcroForm(); AcroFields fields = acroform == null?null:(new AcroForms(acroform)).fields; List<FieldPosition> positions = FieldUtilities.calculateTextPositionsForLayout(font, text, 30, true); Rectangle rect = layoutWithoutOverflowingLinesAtBottomOfPage(widget, LayoutResult.UNKNOWN_HEIGHT); for (int i = 0; i < positions.size(); ++i) { if (!positions.isEmpty()) { float x = posX + i*widthPerChar - paddingLeftRight; } else break;} assertEquals(rect.toString(), expectedRectangle.toString()); }

}