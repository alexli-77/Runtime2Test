package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFontDescriptorType1DifferencesInMetricsForKaiUi3eotfAndPdfBox5867ArialEOTF () throws Exception{ Font fd = PDDocument.load("target/test-output/" + "fonts" + "/fontdescriptor-type1.pdf").getPage(0).findDescendantOfClass(PDTrueTypeFont.class).getBaseFont().toPDFont(); assertEquals(-17.0f, fd.getWidthTableEntry(0), .0001f); }

}