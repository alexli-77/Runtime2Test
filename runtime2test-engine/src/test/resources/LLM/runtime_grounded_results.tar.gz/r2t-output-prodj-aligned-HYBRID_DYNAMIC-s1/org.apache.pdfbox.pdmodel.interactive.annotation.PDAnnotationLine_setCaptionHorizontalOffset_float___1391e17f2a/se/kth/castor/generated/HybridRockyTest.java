package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testSetCaptionHorizontalOffset() throws IOException { PDAnnotationWidget annot1 = createDefaultAnnot(); float expectedValue = -234; annot1.setCaptionVerticalPosition(-56789f).setRectangle(new Rectangle((int)(expectedValue + .5), 0, 0, 0)).setContents("test").setPageNumber(PDPageTreeNode.PAGEMODELNUMBER_NONE); assertEquals(annot1.getCaptionHorizontalOffset(), expectedValue, EPSILON); COSDocument doc = annot1.getCosObject().getDoc(); try (PDFStreamParser parser = new PDFStreamParser(doc)) { ByteBuffer buf = ByteBuffer.allocateDirect(parser.parse()); byte[] bytes = new byte[buf.remaining()]; buf.get(bytes); String s = "q\n" + "/P 12 Tf\n" + "-234.0 w\nn\ns\"Hello World!\\R\\Q\"BDC q 0 g /Helv 12 Tf EMC Q\n"; Assertions.assertThat(new String(bytes)).isEqualToIgnoringWhitespace(s); } finally { IOUtils.closeQuietly(doc); } }

}