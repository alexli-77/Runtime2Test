package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDShadingRockyTest {

@Test public void testSetBackground() throws IOException { PDDocument document = getDocument(); PDFont font1 = loadFont("Helvetica"); PDFont font2 = loadFont("Times-Roman"); COSDictionary rootDict = (COSDictionary)document.getDocument().getTrailer().getRoot(); assertEquals(0,rootDict.size()); Map<String, Object> pageAttributesMap = createPageAttributeMapWithValuesForType3FontsAndColors(); PageUtility.addAllPagesFromPDFBoxToPdf4j((PDDocument)document ,pageAttributesMap ); assertNotNull(document.getDocument().findObjectByKey(org.apache.pdfbox.cos.COSName.FONTS)); org.w3c.dom.Node node = ((ElementImpl )pageAttributesMap .values())[0]; NodeList childNodesOfFirstChild = node.getFirstChild().getChildNodes(); for (int i = 0 ;i <childNodesOfFirstChild .getLength ();++i ){ if ("font".equalsIgnoreCase(childNodesOfFirstChild.item(i).getLocalName())) { Element firstSubnode = (Element)(childNodesOfFirstChild. item(i)).getFirstChild(); assertTrue(firstSubnode instanceof Text || "image".equalsIgnoreCase(firstSubnode .getLocalName())); } else if ("background".equalsIgnoreCase(childNodesOfFirstChild.item(i).getLocalName())) { Attribute attribute = ((Text )childNodesOfFirstChild. item(i)) .getAttribute(new QName(XMLConstants.NULL_NS_URI,"color")); assertEquals("#FF987654",attribute .getValue()); } } document.close(); }

}