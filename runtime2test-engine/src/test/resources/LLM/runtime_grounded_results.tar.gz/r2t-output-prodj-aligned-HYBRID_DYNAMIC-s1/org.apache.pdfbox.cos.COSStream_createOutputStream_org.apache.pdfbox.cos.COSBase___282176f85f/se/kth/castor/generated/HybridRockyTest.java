package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

@Test public final void testCreateOutputStreamCosBaseNull() throws Exception { assertNotNull(stream.createOutputStream((org.apache.pdfbox.cos.COSBase)null)); }

}