package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDBoxStyleRockyTest {

@Test public final void testSetLineDash() throws IOException { try (PDPageContentStream cs = new PDPageContentStream(document)) { assertThat("Initial value", bds.getDictionary().containsKey(PDBorderStyleDictionary.LINE_DASH), is(false)); bds.addToPage(cs).lineWidth(0.1f).stroke(); assertThat("After adding to page and stroking once.", bds.isStroke(), equalTo(true)); assertThat("Has a non-null dictionary entry now that it has been added to a stream at least once.", bds.getDictionary().getDictionaryObject(PDBorderStyleDictionary.KEY_LINE_DASH), notNullValue()); bds.clearBorderDetails(); assertThat("Clearing border details removes all entries from the underlying COSDict.", bds.dictionary.size(), lessThanOrEqualTo(2)); // The only two items in there are .type & .width by default... so anything <3 should be fine here. clearing border styles clears out our custom stuff too! } catch (@SuppressWarnings("unused") Exception e){ fail("Unexpected exception!"); } finally { document.close(); }}

}