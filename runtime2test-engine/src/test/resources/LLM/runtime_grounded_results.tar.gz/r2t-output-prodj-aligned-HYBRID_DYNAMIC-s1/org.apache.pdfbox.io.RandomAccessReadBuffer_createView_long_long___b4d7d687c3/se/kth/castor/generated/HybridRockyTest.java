package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testCreateView() throws Exception { PdfFileSpecification fs; byte[] bytes = "test".getBytes("ISO-8859-1"); ByteArrayOutputStream baos = new ByteArrayOutputStream(); try (PDDocument doc = PDFBoxUtil.newPDFDocWithNewPages(2)) { pdStream = doc.addPage((pdDocument).createImageXObjectFromByteArray("/tmp", 0, -1, bytes)); fs = new PdfFileSpecification(null, pdfFilename, true, false, pdStream); assertEquals(-1L, fs.length()); RandomAccessInputStream rai = fs.asRaiForParsing(); InputStream is = rai.toInputStream(true); int b; while (-1 != (b = is.read())) { System.out.print((char) b); } } catch (Exception e) { throw new RuntimeException(e); } }

}