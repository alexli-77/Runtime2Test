package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testIsImage() throws Exception { PDForm pdForm1 = new PDForm(); Assertions.assertFalse("Should be no images", pdForm1.isImageXObject(new COSDictionary())); PDFont font = new PDSimpleFont(); Dictionary dict = new Dict(); COSDictionary cosDict = new COSDictionary(); COSArray array = new COSArray(); pdfDoc.addPage(pdForm1).setResources((PDResources)null); pdForm1.put("foo", "bar"); assertThatThrownBy(() -> { pdForm1.isImageXObject(null); }) .hasMessageContainingAll("name must not be null") .isInstanceOfAny(NullPointerException.class); assertThatThrownBy(() -> { pdForm1.isImageXObject(font); }) .hasMessageContainingAll("must be a valid dictionary object") .isExactlyInstanceOfType(IllegalArgumentException.class); pdForm1.put("image1234567890", dict); pdForm1.put("/MyImaginaryImageID", cosDict); pdForm1.put("foo", array); assertEquals("Incorrect result for \"image\" check!", Boolean.FALSE, pdForm1.isImageXObject(COSName.PAGE), ()->"Wrong Result!"); assertTrue("Missing or incorrect result!", pdForm1.isImageXObject(COSName.CROPBOX)); assertFalse("Found unexpected entry!", pdForm1.containsKey("foo")); assertFalse("Found unexpected entry!", pdForm1.isImageXObject(COSName.FOO)); assertFalse("Found unexpected entry!", pdForm1.isImageXObject(COSName.BAR)); assertFalse("Found unexpected entry!", pdForm1.isImageXObject(COSName.DICTIONARY)); assertFalse("Found unexpected entry!", pdForm1.isImageXObject(COSName.ARRAY)); }

}