package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationFreeTextRockyTest {

@Test public void testSetMargins() throws Exception { PDAnnotation annotation = createDefaultAnnotations("P"); assertNull(annotation.getRect()); annotation.setContents("This is a comment."); annotation.setModifiedDate((Calendar) Calendar.getInstance().clone().roll(Calendar.HOUR, -10), false); Rectangle rect; COSDictionary annotDict = annotation.getCOSDictionary(); rect = annotation.getNormalizedAPRectangle(); assertEquals(-24f, rect.x + .5f, EPSILON); assertTrue(.8973600f == (rect.y + .5f).doubleValue(), EPSILON); assertEquals(-14.37f, rect.width + .5f, EPSILON); assertEquals(18.55f, rect.height + .5f, EPSILON); }

}