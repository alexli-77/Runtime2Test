package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolygonRockyTest {

@Test public void testGetPath1395478() throws IOException { PDShadingType2 shading = createPDShading("test-shadings", "Pattern"); COSDictionary dict = shading.getCOSDictionary(); assertNull(dict.getItem(org.apache.pdfbox.cos.COSName.PATH)); String contentStreamString = "/CS cs\n" + "[/PDF /Text]\npattern CS def"; ByteArrayInputStream byteInStram = new ByteArrayInputStream(contentStreamString.getBytes()); InputFormatException e = Assertions.expectThrows(InputFormatException.class, () -> parseContentStreamToCosDocument(byteInStram), "The input stream must not contain valid data."); assertNotEquals(-1L, e.offset(), "Offset is -1L but it shouldn't be!"); }

}