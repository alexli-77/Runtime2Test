package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSWriterObjectStreamRockyTest {

@Test public final void testWriteObjectsToStreamWithCompression() throws Exception { COSSubstream substream = prepareSubstreamForCompressionTests(); assertNotNull(substream); assertTrue(!substream.isEmpty()); ByteSource expectedContent = Resources.asByteSource(Resources.getResource( "compressedObjStmExpected24367.bin")); assertEquals(expectedContent, substream.generateFinalizedAndGetContentsAsUnifiedFileSystemSafeByteSource()); }

}