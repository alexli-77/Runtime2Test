package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetBorder() throws IOException { COSDictionary dict = PDResources.load(new ByteArrayInputStream("1 0 obj << /ExtGState << >> endobj".getBytes())).getCOSDictionary(); assertThat((dict)).isNotNull(); PDBorderEffect ef = new PDBorderEffect(dict); assertThat(ef.getCOSBase()).describedAs("The dictionary was not set").isEqualTo(dict); assertThat(ef.getBorder()).hasSizeGreaterThanOrEqualTo(3); }

}