package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessInputStreamRockyTest {

@Test public void testSkip() throws IOException, InterruptedException { PDFTextStripper stripper = new PDFTextStripperByArea().setSortByPosition(true).addRegion("region", 582f, 367f ,194f, 525f ); PDDocument doc = loadPDF(new FileInputStream("/Users/jhiller/Documents/test-data/example.pdf")); String text = stripper.getText(doc); Assertions.assertEquals("This is a sample file to be used for testing purposes.\r\ntesting... \r\nMore Text\r\nEven more text.",text,"Unexpected result."); Thread.sleep(10*SECONDS); }

}