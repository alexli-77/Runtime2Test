package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public void testSetStartPointEndingStyle() throws Exception { PDAnnotationLine annotation1 = createDefaultAnnot(""); assertNull(annotation1.getInkList()); String[] styles = {"None", "ButtCap", "RoundCap"}; int i = 0; for (String s : styles) { annotation1.setStartPointEndingStyle(s); COSDocument doc2 = writeAndReadBackDoc(doc); COSStream stream = doc2.getFirstPage().findResourcesOfType(COSDictionary.class).iterator().next(); Assertions.assertNotEquals(-1L, stream.getLong(new COSBaseFilter[0]).longValue(), () -> "Could not find a reference to Line Endings in Annotation dictionary."); PDFont font = FontManagerFontConfigurerUtil.getInstanceForTestsOnly().createFallbackFreePdfBoxFontFromCosDictionary((COSDictionary)stream.asDict()); byte bt[] = font.encodeToBytes(styles[i]); try (InputStream is = new ByteArrayInputStream(bt)) { InputSource src = new InputSource(is); XMLParser p = new XMLParser(src); DocumentBuilderFactory dbfactory = DocumentBuilderFactory.newInstance(); DocumentBuilder builder = dbfactory.newDocumentBuilder(); org.w3c.dom.Element root = builder.parse(p.getInputSource()).getDocumentElement(); Node node = root.getElementsByTagNameNS("http://ns.adobe.com/illustrator/1984-12","le").item(0); Assertions.assertTrue(node instanceof Element); Element element = (Element)node; Attribute leAttr = element.attribute("startPointEndingStyles"); Assertions.assertFalse(element.hasChildNodes()); Assertions.assertEquals(styles[++i % styles.length], leAttr.getValue()); } } }

}