package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationSquareCircleRockyTest {

@Test public void testGetRectDifferencesNullValueForNoAnnotationDictionaryEntry() throws Exception { AnnotationUtils annotationUtil = Mockito.mock(AnnotationUtils.class, CALLS_REAL_METHODS); PDAcroForm acroform = Mockito.spy(new PDAcroForm()); when(acroform.isNeedAppearances()).thenReturn(true); when(annotationUtil.createDefaultResourcesIfMissing("")).thenCallRealMethod(); when(annotationUtil.createAcroFormWithoutFSAndFfEntries(any(), eq((PDAcroForm)null))).thenAnswer(invocationOnMock -> invocationOnMock.<String>getArgumentAt(0)); assertThatExceptionOfType(IllegalStateException.class).isThrownBy(() -> annotationUtil.processAnnotations(Collections.emptyList())); }

}