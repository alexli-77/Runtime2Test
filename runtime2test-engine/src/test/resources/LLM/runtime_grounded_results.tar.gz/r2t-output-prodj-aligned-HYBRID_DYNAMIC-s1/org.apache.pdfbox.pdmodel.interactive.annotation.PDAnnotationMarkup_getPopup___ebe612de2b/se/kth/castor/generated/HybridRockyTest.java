package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetPopUpNull() throws IOException { PDAnnotationText pdAnnot = createDefault(); assertThat("Wrong value returned", pdAnnot.getPopup(), is((PDAnnotationPopup)null)); }

}