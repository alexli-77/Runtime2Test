package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testGetString() throws IOException { final String str1 = "string"; final byte[] b1 = str1.getBytes("ISO-8859-2"); final String str2 = new String(b1); assertEquals("test", this.array.size(), 0); assertNull("test", this.array.toString()); try { this.array.setDirty(); fail("Should have thrown IllegalStateException."); } catch (final Exception e) {} assertTrue("testAddToArrayWithSetDirty false failed.", true); }

}