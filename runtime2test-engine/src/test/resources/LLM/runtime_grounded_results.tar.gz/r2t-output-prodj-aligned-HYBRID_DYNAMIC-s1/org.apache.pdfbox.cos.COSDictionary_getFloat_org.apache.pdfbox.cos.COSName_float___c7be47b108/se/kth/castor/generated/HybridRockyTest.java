package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetFloat() throws Exception { PDStream stream1 = new PDStream(doc, new ByteArrayInputStream("".getBytes())); PDAcroForm acroform = doc.getDocumentCatalog().setAcroForm((PDAcroForm)null); assertEquals(-42f,acroform.getFloat(new COSSymbol()),0f); }

}