package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetInt() throws Exception { assertEquals(-1, dc.getInt("First", "Second")); PDDocument doc = new PDDocument(); PDFont font = new PDSimpleFont(); doc.getPage(0).setResources(new PDRenderingOptions()); COSStream stream = doc.createCOSStream(); String contents = "/Helvetica findfont /BoldItalic-Oblique scalefont setfont\n" + "[576] 0 dtransform\npopmatrix showpage"; OutputStream os = stream.createUnfilteredOutputStream(); IOUtils.writeStringAsIsWithoutEscaping("\r\n", os); IOUtils.copy(contents, "\r\n".length(), os); os.close(); stream.putAll((Map<? extends COSSystemNodeBase, ? extends Object>) font.toPDStream().getCOSDictionary()); PDFontDescriptor fd = (PDFontDescriptor) font.getDescendantFont(true); float size = .0f; if (!fd.isEmbedded()) { System.err.println("WARNING! Font descriptor should have been embedded!"); } else { size = fd.getCapHeightPt(); } stream.addFilter(COSName.FLATE_DECODE); stream.asEncodedString("%F%EE"); doc.saveIncremental("/tmp/"+System.currentTimeMillis()+"_test.pdf"); doc.close(); pdDoc = PDDocument.load("/tmp/"+System.currentTimeMillis()+"_test.pdf"); PDPage page = pdDoc.getPages().get(0); pdfBoxResourceCache.clearCachesForCurrentThreadAndSessionId(); Dictionary dic = (Dictionary) page.findResourceOfType(stream, true); Assertions.checkNotNull(dic); Integer iVal = dic.getInt("First", "Second", -1); assertTrue(iVal > 0 || iVal < 0, () -> "Expected positive but got "+iVal); }

}