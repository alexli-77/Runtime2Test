package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDEncryptionRockyTest {

@Test public void testSetCryptFilters() throws IOException { PDStandardSecurityHandler pdSh = new PDStandardSecurityHandler((PRStream) encryptedDoc.clone(), ownerPassword); assertNull("Shouldn't have any filters", pdSh.getEncryptedDocument().getAsDict(PDPageTree.class).getEntry(COSName.ENCRYPTED_DICTIONARY), "Wrong number"); Map<String, Object> options = new HashMap<>(); String userPasswd = ""; StandardProtectionPolicy spp = new StandardProtectionPolicy(userPasswd, "", EncryptionConstants.ALLOW_SCREENREADERS | EncryptionConstants.NO_CHANGES_IN_CONTENTS ); SecurityProvider provider = SecurityProvider.getInstance(); try{provider.addSecurityHandler(new AES256SecurityHandler()); fail ("Expected exception wasn't thrown."); }catch(IllegalArgumentException e){assertEquals(e.getMessage(),"Not supported encryption algorithm 'AESv1'. Only RC4 and AES are allowed.", "Wrong error message");} finally{SecurityProvider.removeAllRegisteredAlgorithms();}}

}