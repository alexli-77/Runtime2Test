package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFormXObjectRockyTest {

@Test public void testGetBBox(){ assertEquals("-1 -1 10 10", pdFormTypeA.getBBox()); }

}