package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetExtGState() throws IOException { PDResources pdResoures = createPDDocument().getPage(1).findDescendantOfType(PDFormXObjectsSupplier.class).iterator().next().createContentStream(new Matrix()).getResources(); assertEquals("Should be a valid Ext G State.", true, pdResoures.hasExtGStates()); String gsname = "/GS"; assertNotNull("Expected to find an Ext G State named '" + gsname + "' but didn't!", pdResoures.getExtGState(gsname)); }

}