package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolygonRockyTest {

@Test public void testGetBorderEffect() throws IOException { assertNull(annot1.getBorderEffect()); }

}