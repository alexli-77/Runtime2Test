package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testEquals0123456789() throws Exception { assertFalse("different matrices", mtxA.equals(mtxB)); }

@Test public void testEqualsIdentity() throws Exception { Matrix identity = new Matrix(); Matrix otherIdentiy = new Matrix(identity); assertTrue("should be equal to itself and another instance of the same matrix.", identity.equals(otherIdentiy)); }

}