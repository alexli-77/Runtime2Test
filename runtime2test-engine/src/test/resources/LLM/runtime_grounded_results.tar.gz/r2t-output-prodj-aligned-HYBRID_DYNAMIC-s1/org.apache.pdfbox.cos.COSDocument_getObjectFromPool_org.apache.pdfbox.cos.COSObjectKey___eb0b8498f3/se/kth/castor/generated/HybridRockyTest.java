package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDocumentRockyTest {

@Test public void testGetObjectFromPoolForwardRef() throws IOException { COSParser parserMocked = mock(COSParser.class); when((parserMocked)).parseNextXREFPartiallyFilledCrossReferenceStream(anyInt(), anyLong()) .thenReturn(""); assertThatCode(() -> parserMocked.getObjectFromPool(new COSSharedContainerTokenizer(null), null)) .doesNotThrowAnyException(); verifyNoMoreInteractions(parserMocked); }

}