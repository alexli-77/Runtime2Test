package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetColorSpace() throws Exception { assertNotNull("PDFBOX-4001", documentCatalog.getPageString()); }

}