package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStringRockyTest {

@Test public void testEquals() throws IOException { String s = "Hello World"; byte[] b = pdfDocumentToStringToByteArray(s); assertTrue("Equal strings should be equal", cosStreamFromBytes(b).equals(new PdfCosString(s))); }

}