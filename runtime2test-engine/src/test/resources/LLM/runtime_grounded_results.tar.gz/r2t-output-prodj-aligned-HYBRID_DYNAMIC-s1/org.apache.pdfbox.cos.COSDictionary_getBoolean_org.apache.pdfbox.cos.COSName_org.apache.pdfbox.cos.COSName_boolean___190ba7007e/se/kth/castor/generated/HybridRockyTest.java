package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetBoolean() throws Exception { PDDocument doc = new PDFParser().parse("src/test/resources/com/tom_eckstein/pdfbox/functional/" + filename); assertTrue((doc).getPage(1)).getResources().isNeedToBeUpdated(); doc.close(); }

}