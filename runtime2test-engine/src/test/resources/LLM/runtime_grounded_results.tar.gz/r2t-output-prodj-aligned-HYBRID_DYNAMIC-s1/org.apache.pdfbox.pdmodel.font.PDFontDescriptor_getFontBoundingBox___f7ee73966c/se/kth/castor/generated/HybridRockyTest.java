package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFontBoundinigBoxWithMissingValueReturnNull() throws IOException { PDType1Font font = new PDType1Font(); assertTrue("Expected value should have been null",font.getFontBoundingBox() == null ); }

}