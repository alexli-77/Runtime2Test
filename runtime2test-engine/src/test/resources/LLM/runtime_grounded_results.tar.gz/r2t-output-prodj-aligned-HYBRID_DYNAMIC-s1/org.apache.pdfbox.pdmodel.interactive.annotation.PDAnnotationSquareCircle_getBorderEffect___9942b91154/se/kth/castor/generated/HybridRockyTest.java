package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationSquareCircleRockyTest {

@Test public void testGetBorderEffectWithoutEntryShouldReturnNull() throws Exception { PDAnnotationLine pdAnno = createDefaultPDAnnotation(); assertThat("A non-existing entry should not throw an exception", () -> pdAnno.getBorderEffect()).doesNotThrowAnyException(); }

}