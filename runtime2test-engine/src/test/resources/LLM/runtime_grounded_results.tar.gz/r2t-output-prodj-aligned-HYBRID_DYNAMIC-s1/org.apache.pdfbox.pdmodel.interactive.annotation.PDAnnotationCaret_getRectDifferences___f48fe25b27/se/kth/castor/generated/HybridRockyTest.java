package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationCaretRockyTest {

@Test public void testGetMarginSize1 () throws Exception { PdfAnnotation annot = createAnnot(); assertEquals("Wrong number of values", 4, annot.getRectDifferences().length); }

}