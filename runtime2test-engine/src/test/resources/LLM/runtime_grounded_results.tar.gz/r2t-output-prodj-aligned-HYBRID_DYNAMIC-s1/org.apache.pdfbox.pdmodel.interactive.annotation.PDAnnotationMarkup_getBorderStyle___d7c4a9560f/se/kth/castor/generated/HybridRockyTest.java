package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetBorderStyleWithNullEntryInDicitonaryShouldReturnNullAsResult() throws IOException { PdfBoxExtender extender = createPdfBoxExtender(); InputStream inputStream = this .createInputStream("empty-dictionary"); PDFont font = new FontLoader().loadFont("/fontpath", "ArialMT"); Document document = new Document(inputStream, 1024, 768, 593, 846); Assertions.assertThatThrownBy(() -> extender.extendAnnotationAppearanceForField(document)) .isInstanceOfAny(RuntimeException.class).hasMessageContainingAll("Could not read annotation appearance for field."); }

}