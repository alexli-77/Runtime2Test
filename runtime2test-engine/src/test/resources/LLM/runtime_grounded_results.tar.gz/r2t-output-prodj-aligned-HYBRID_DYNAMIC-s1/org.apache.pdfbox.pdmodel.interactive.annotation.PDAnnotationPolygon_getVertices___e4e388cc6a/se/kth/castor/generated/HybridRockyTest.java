package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolygonRockyTest {

@Test public void testGetVerticesNoEntriesReturnNull() throws Exception { COSDictionary dict1 = new COSDictionary(); assertEquals("Wrong number returned", 0, ((PDBaseShading) shadings[2]).getNumFunctions()); }

}