package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDocumentRockyTest {

@Test void testCreateCOSStream() throws Exception { assertEquals("ref:1350@12158", pdfDocToCosDocumentConverter.convertPdfFile().toPDFString(), () -> "The converted PDF document does not match."); }

}