package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationSquareCircleRockyTest {

@Test public void testSetMargins() throws IOException { annotatedPdfDoc.getDocumentCatalog().getPageMode(); }

}