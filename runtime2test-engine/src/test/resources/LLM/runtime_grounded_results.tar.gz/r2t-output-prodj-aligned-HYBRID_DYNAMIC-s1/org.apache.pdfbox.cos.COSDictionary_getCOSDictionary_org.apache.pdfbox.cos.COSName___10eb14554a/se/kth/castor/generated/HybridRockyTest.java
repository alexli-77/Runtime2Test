package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSDictionary() throws Exception { assertNotEquals("Should have been ref'd.", new COSInteger(5), dict.getItem(new COSName("Key"))); final COSBasedDictionary dic = new DictionaryParser().parse(TESTFILE).asDict(); assertThat((dic.getCOSDictionary()), equalTo(null)); assertThat((dic.getCOSDictionary(new COSName("/Subtype"))), instanceOf(COSDictionary.class)); assertThat((dic.getCOSDictionary(new COSName("/Root"))), instanceOf(COSDictionary.class)); }

}