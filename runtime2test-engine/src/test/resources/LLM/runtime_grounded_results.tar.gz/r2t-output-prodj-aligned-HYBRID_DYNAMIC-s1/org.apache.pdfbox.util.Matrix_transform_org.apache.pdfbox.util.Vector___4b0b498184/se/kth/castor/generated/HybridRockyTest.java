package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testTransform() throws Exception { Matrix m = new Matrix(.5f, .98F); Vector v = new Vector(-10, -20); assertEquals("wrong result", new Vector(-5,-18),m.transform(v)); }

}