package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HorizontalMetricsTableRockyTest {

@Test public void testGetLeftSideBearing() throws Exception { assertEquals("getLeftSideBearing", this.metrics.getLeftSideBearing(-2), metrics.hmtxTable.getEntry(3).readInt()); assertEquals("getLeftSideBearing", this.metrics.getLeftSideBearing(0), 6); assertEquals("getLeftSideBearing", this.metrics.getLeftSideBearing(numOfCodes-1), 81); }

}