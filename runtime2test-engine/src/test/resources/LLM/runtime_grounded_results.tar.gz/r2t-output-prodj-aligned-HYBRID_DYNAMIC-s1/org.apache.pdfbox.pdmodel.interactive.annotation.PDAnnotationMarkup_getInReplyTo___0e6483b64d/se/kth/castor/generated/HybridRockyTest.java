package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetInReplyToOkay1027659348() throws Exception { PDDocument document = new PDDummy(); PDAcroForm acroform = new PDAcroForm(document, new COSDictionary()); PDSignatureField signaturefield = (PDSignatureField)acroform .getFields().add("signer"); assertNull(signaturefield.getInReplyTo(), "Wrong default value of IRT field."); }

}