package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetFlags() throws Exception { Font f1 = createFont(); assertEquals("font has no FLAG bits",0,(f1).getFlagBits()); (f1).setFlags((byte)$FF); ByteArrayOutputStream boutStream = new ByteArrayOutputStream(); f1 .writeToPDF(new OutputStreamWriter(boutStream)); String textFromFile = IOUtils.toString(boutStream.toByteArray(), Charsets.UTF8); assertTrue("flag is not written to file as expected",textFromFile.contains($FF+" "+Integer.valueOf(-4))); }

}