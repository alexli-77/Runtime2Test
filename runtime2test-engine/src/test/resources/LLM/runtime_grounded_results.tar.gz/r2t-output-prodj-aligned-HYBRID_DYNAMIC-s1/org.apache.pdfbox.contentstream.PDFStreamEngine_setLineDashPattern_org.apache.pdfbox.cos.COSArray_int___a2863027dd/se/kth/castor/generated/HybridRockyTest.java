package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFStreamEngineRockyTest {

@Test public void testSetGetStrokeColor() throws IOException{ PDPaint paint1 = this.createPdpaint(); assertEquals("Should return the default color", ColorConstants.BLACK, ((PDFontPaintWrapper)paint1).getCurrentFont()); }

}