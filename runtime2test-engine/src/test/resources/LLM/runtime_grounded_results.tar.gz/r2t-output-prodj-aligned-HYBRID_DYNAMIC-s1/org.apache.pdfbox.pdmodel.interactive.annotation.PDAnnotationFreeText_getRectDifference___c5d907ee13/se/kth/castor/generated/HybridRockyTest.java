package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationFreeTextRockyTest {

@Test public void testGetRectDiffence() throws Exception { PDAcroForm acroForm = this.testPdfDocument.getAcroForm(); assertNotNull("No Acroform found",acroForm); PDDictionary fieldDict1 = createFieldDictionaryWithValueAndEntryValues("/F2","/XYZ"); PDFont font = PDType0Font.load(new FileInputStream ("src\\main\\resources\\fonts\\times-bold.afm"), "Cp1252", true, false); String value="Hello World"; COSString stringVal = new COSString(value + "\n" ); COSStream stream = new COSStream(null, 487963L, 487964L, 10L, 521L , 40L, 1L); OutputStream outputStream = stream.createUnfilteredOutputStream (); byte[] bytes = ((byte[])stringVal.toByteArray());outputStream .write(bytes);outputStream .close(); COSBase base = stringVal ; PDCosStream cosstream = new PDCosStream((COSDictionary)base,"");fieldDict1.setItem("V", cosstream); PDSignature signature = new PDSignature(); signature.constructAppearance(acroForm); signature.setContents("Some contents here!"); signature.addReason("This is a reason."); signature.signInteractive(pkcs1Signer, chain[0], digestAlgorithm, cryptoStandard, fieldDict1); ByteArrayOutputStream baos = new ByteArrayOutputStream(); this.testPdfWriter.copyIntoOs(baos); InputStream inputStream = new ByteArrayInputStream(baos.toByteArray()) ; PdfReader pdfreader = new PdfReader(inputStream ) ; Assertions.assertEquals("The signatures are not equal!",expectedOutputFileLength,(long)(pdfreader.calculateTrailerSize())); }

}