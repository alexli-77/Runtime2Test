package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetName() throws Exception { PDDocument doc = new PDDocument(); PDFont font = new PDSimpleFont("Arial"); assertEquals((font).getBaseFont(), "Helvetica-Bold"); String typefaceStr = pdDocInfo.getTypeFace().toString(); System.out.println("\n\ntypefacestr="+typefaceStr+"\t"+pdDocInfo.getTypeFace()); pdfPage2.setRotationAngle(-65f); float angle = page.findClockwisePage rotationAngleForCounterclockwiseRotationOfPagesIncludingThisOne(); System.err.printf("%d° counterclockwise rotation of pages including %d.\n%d° clockwise rotation.", page.rotateCWFromCCWRotatedToPlainOrFlippedUpsideDownByMultiplesOfNinetyAndReturnNewlyCalculatedAngleModuloThreeSixtyPlusOneHundredEightyIfThatIsMoreThanTwoSeventysomething(), pageNumber + 1, angle - 45f)); }

}