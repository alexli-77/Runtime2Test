package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessInputStreamRockyTest {

@Test public void testReadByteWithoutRestoreShouldNotThrowException() throws IOException { byte[] bytes = new byte[3]; pdfFileStreamInput.setCurrentPos(78); assertEquals(-1, pdfFileStreamInput.read(bytes)); assertTrue(!pdfFileStreamInput.hasMarkedPosition(), "Expected no marked positions"); assertFalse(pdfFileStreamInput.canUnmark(), "Can unmark must be false when the stream has not been reset."); }

@Test public void testReadByte() throws Exception { try (PDDocument document = loadSourcePdfFromResources("simple-a4page")) { PDPage page = getFirstPageOfPDFDoc(document); PDFTextStripperByArea stripper = new PDFTextStripperByArea().setTextLayoutStrategy(new SimpleColumnTextExtractionStrategy()).startPage(page).extractRegionsAsArray(); String textContent = stripper.getTextForRegion(stripper.getAcroFormFieldsIncludedImageAreasAndAnnotationsMap().values()); Assert.assertThat(textContent, CoreMatchers.containsStringIgnoringCase("This file contains only one A4")); } }

}