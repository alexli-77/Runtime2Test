package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFStreamEngineRockyTest {

@Test public void testShowTextStringsWithSpacingAndNewline() throws Exception { String str23456789abcdefghi = "23456789ABCDEFGHI"; PDPage page = new PDPixelMap(); PDFont fntTimesRomanBoldItalic = FontProviderUtil.createStandardPdfBoxFont(fpf, true, true); PageDrawer drawer = createPageDraweeForContentStreamOperations(); List<Object> listOfObjects = Arrays.<Object>asList(new COSFloat(-1), COSStrings.toCOSString("\n"), new COSInteger(str23456789abcdefghi)); contentStream.addOperation(Operator.TEXT_SHOW, OperandResolverFactory.buildSingleArgumentOperands(listOfObjects).resolve()); verifyNoMoreInteractions(drawer); assertTrue(!page.containsImageXobjects()); assertEquals(true, page.hasShownTextOnThisPage()); assertEquals(false, page.hasShownImagesOnThisPage()); }

}