package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSDictionary() throws Exception { assertNotEquals("null should never happen.", null, dict.getCOSDictionary()); }

}