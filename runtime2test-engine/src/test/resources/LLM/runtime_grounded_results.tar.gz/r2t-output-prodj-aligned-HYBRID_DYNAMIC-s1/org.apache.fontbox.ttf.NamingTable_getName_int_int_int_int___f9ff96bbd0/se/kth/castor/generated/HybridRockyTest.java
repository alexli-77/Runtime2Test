package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NamingTableRockyTest {

@Test public void testGetName() throws Exception { String result = names.getName((short)3,(byte)2,(byte)65001,(short)-798); assertEquals("",result,"Wrong value"); }

}