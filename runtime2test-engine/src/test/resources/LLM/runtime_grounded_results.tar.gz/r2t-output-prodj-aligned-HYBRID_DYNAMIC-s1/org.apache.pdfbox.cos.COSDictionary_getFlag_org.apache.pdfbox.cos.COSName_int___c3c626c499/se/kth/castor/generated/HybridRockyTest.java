package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetBoolean() throws Exception { assertTrue(getPdfObject().getDictionaryAsIs("F").getFlag(FIELDTYPE, FLAG)); }

}