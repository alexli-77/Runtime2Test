package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetFontFamily() throws Exception { Assertions.assertNull((Object)null); FontInfo info = getInstance(); String expectedValue = "$PARAM1"; assertEquals("Wrong value", expectedValue, actualValue); }

}