package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testToCosArray2DTransformMatrix() throws Exception { PDFont font = PDType1Font.HELVETICA; float size = 8f; AffineTransform at = font.getScaleX().createAffineTransform(size).concatenate(font.getTranslateX()); assertEquals("testToCosArray", "[[-592.0] [-432.0]]", Arrays.toString((at.toDoubleMatrix()).toArray())); }

}