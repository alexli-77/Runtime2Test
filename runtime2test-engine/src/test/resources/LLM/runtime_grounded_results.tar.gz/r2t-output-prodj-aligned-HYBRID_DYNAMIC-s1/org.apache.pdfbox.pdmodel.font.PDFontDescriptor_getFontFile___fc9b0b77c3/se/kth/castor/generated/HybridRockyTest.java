package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFontFile2048WithoutEmbedding() throws Exception { FontProgram fp = type1PFD.createFont(); Assertions.assertThat((fp)).isNotNull().extracting("embedded").containsOnlyOnce(false).asList(); PdfReader reader = new PdfReader(new FileInputStream(testResults + "font-file-without-encoding.pdf")); String textContent = PDFTextStripperByAreaUtil.getTextFromPage(reader, 1); assertEquals("\n",textContent,"Should contain line breaks"); }

}