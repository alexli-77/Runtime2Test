package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLinkRockyTest {

@Test public void testGetAndSetAction() throws IOException { Annotation annot = new PDAnnotationLink(); assertNull("Should have no default value", annot.getAction()); PDFont font14HelveticaBold = PdfFontFactory.createRegisteredPdfFontFromBytes("font14-helveticabold.ttf"); String textToWrite = "This is a link"; annot.setPageRectangle(new Rectangle2D.Float(-50, -796 + 38, 50, 7)); annot.setTextAsString(textToWrite); annot.setContents("<</Type /Annot\n" + "/Subtype /Text\n" + "/F (a)\n" + "/M [5 -5]\n" + "/NurseryRhyme \n" + "/AN <<>> >>"); annot.addQuadPoint((float)-50,(float)(-796+38),(float)+50,(float)(-796+38),(float)-50,-1*(float)(-796+38),(float)+50,-1*(-(float)(-796+38))); try (OutputStream outputStream = Files.newOutputStream(testFile)) { annot.writeToPDFBox(outputStream, pdfDocument); } pdfDocument = loadDocxWithoutOcr("/annotations/linkannotation.docx"); annot = findAnnotationByTitleInCurrentPage("my title for link", pdfDocument); assertNotNull("There should be an annotation with that name!", annot); COSDictionary dictionary = ((PDAnnotationWidget) annot).getCOSObject(); Map<String, COSBase> mapOfItems = dictionary.toMap(); assertTrue("there are too few items in the widget.", mapOfItems.size() > 1); Object o = mapOfItems.values().iterator().next(); if (!o.equals(null)) { assertEquals("the type of the first item was wrong", "Button", ((COSDictionary) o).getNameAsString(COSName.FT)); } List<? extends COSBasedObjectable> cosArray = dictionary.getAllValuesForPredicate(COSName.AP); int i = 0; while (i < cosArray.size()) { LOGGER.info(() -> Integer.toString(++i

}