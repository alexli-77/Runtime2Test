package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testToCOSNumberFloatListWithAllCosNumsAndEmptyStream() throws IOException, InvalidOperationException { List<Integer> intValues = Arrays.<Integer>asList(-1354827964,-2147483648, -1, 0 ,-1, 0xfffe, 0xffff, Integer.MAX_VALUE ); byte[] bytes = ByteUtils.toHex("stream\n" + "endstream"); PDDocument doc = createSimpleDoc(bytes); PDFont font = FontManager.createFont(doc,"Helvetica", false); assertEquals(font.getName(),"/F0"); COSDictionary dict = (COSDictionary)(objects.get(0)); String nameAsString = dict.getString(PDTextStateConstructingVisitor.NAME_KEY).toString(); LOG.info("/"+nameAsString+" "); assertTrue ("/F".equalsIgnoreCase(nameAsString ) || "/f".equalsIgnoreCase(nameAsString )|| "/F0".equalsIgnoreCase(nameAsString ),"/"+nameAsString); COSName cosName = dict.getKeyForValue(dict.getItem(PDTextStateConstructingVisitor.NAME_KEY),false); // /F or /f
// TODO FIXME: we should not use .contains here!
if (!cosName.getValue().contains("F")){ fail("Expected 'F' in "+cosName);} assertNotNull(cosName); List<Float> expectedResult = convertIntToListOfFloats(intValues); assertThat(array.toCOSNumberFloatList()).isEqualToComparingFieldByFieldRecursively(expectedResult); pdfClosed(doc); }

}