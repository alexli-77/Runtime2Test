package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public void testGetSetVerticiesWithNullValue() throws IOException, BadElementException { PDPolyLine polyline = new PDPolygon(); Assertions.assertThat(polyline).isNotNull(); }

}