package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public final void testCloseWithNullRandomAccessFileReaderAndTrueValueForCloseInputStreamParameter() throws Exception { RandomAccessReadingPDFParser parserUnderTest = new RandomAccessReadingPDFParser(null, false); assertThat("Asserting that the 'isClosed' flag is set to true.",parserUnderTest.getIsClosed(),equalTo((boolean)true)); assertThrows(IllegalStateException.class, () -> parserUnderTest.setPdfSourceStream(new ByteArrayInputStream(BYTE_ARRAY))); parserUnderTest.parseHeaderlessFDFDocumentOrDummyIfNotPossible(false).flatMap(fdf::validateXfaFormattingRulesSetInTheCosDictionary).ifPresentOrElse(Assertions::fail,"Nothing should happen."); Assertions.assertFalse(parserUnderTest.getIsClosed()); parserUnderTest.close(); assertThat("Asserting that the 'isClosed' flag has been reset after calling the method under test with a valid input stream parameter and closing it afterwards",parserUnderTest.getIsClosed(), equalTo((boolean)true)); }

}