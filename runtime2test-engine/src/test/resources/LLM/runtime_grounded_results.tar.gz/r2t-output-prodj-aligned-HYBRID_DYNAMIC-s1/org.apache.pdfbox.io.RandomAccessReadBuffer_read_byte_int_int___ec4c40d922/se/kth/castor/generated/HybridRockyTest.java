package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testReadByteArrayIntOffsetLength2() throws Exception { assertEquals(-1, new ByteRangeInputStream("test".getBytes()).read((new byte [3]).length)); }

@Test public void testReadByteArrayIntOffsetLength4() throws Exception { assertEquals(0, new ByteRangeInputStream().read((new byte []).length, 0, 0)); }

@Test public void testReadByteArrayNullObjectException() throws IOException { final InputStream stream = mockery.mockInstanceOfType( "stream", FileInputStream.class ); Mockery mokery = new Mockery(); mokery.checking( new Expectations(){{ oneOf( stream ).close(); will( throwThrowable( new NullPointerException())); }} ); try { new ByteRangeInputStream( null , Integer.MAX_VALUE ); fail(); } catch (final Throwable e){mokery.assertIsSatisfied();} }

@Test public void testReadByteArrayOffSetLen1() throws Exception { Assert.assertTrue( Arrays.equals( new String( "hello world" ) . getBytes(), new ByteRangeInputStream( "hello world".toCharArray()) . readAllBytes()) ); }

@Test public void testWriteToFileOutputStreamWithDifferentChunkSizeAndNoClose() throws Exception { setUpMockedObjectsForNonClosingOperationOnInputSteam( false ); final File fileOutputTemp = this.tempFolder.createNewFile(); OutputStream outputStream = Files.newOutputStream( Paths.get(fileOutputTemp . toURI()), StandardOpenOption.WRITE); PipedOutputStream pipedOutputStream = new PipedOutputStream(); Thread thread = createThreadThatPipesTheDataFromAnotherInputStreamIntoAWriter(pipedOutputStream, outputStream); inputStreamUnderTest.writeTo(outputStream); verifyOperationalStatusAfterExecution(thread, outputStream, true); }

@Test public void testAvailableReturnValueWhenNotYetInitialized() throws Exception { assertFalse(inputStreamUnderTest.isMarkSupported()); assertEquals(Integer.MIN_VALUE, inputStreamUnderTest.mark(16*1024)); assertEquals(0, inputStreamUnderTest.skip(Long.MAX_VALUE-8L)); assertEquals(0, inputStreamUnderTest.reset());

}