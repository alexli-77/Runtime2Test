package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetCapHeight() throws Exception { assertEquals("Should be equal", expectedValue, testedObject.getFont().getName()); }

}