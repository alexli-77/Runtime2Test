package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FlateFilterDecoderStreamRockyTest {

@Test public void testDecodeChunk() throws Exception { assertEquals("Hello World!".getBytes().length, decoderStream.read()); }

}