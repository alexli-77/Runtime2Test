package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public void testGetSetBorderStyle() throws IOException { PDAnnotationLine pdAnnot1 = new PDAnnotationLine(); assertNull("The default value should be empty", pdAnnot1.getBorderStyle()); BorderStyleDict bsd2 = new BorderStyleDict(); pdAnnot1.setBorderStyle(bsd2); assertEquals("The values are not equal", 0f, ((Float) (new Float((float) pdAnnot1.getBorderStyle().getWidth()))).intValue(), 0d); }

}