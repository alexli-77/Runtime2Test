package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationInkRockyTest {

@Test public void testSetGet() throws IOException { InkAnnotation annot1 = createDefaultInkAnnotation("annot"); PDFont font = PDType0Font.load(doc, TTFFileResourceLoader.getStreamForBytes(Standard14Fonts.HELVETICA), true); AnnotationUtils.createPopupForm(annot1).setFdfTextAsPlaintext("/Some text", doc, "en-US").saveToCosObject(); assertNull(annot2.getAppearance()); appStateDict = new COSDictionary(); appStateDict.putIfAbsent(PDPageContentStream.APPSTREAM_KEYWORD_FORMAT, PDPopupForm.SUBTYPE_NAME); annotations = new ArrayList<>(Collections.<PDFreeText>singletonList((PDFreeText) annot3)); annot3.setContents(new FDFDocument(documentFactory)).getAcroFieldsFromFieldMapAndObjects(appStateDict, Collections.<String, Object>emptyMap(), false); document.close(); }

}