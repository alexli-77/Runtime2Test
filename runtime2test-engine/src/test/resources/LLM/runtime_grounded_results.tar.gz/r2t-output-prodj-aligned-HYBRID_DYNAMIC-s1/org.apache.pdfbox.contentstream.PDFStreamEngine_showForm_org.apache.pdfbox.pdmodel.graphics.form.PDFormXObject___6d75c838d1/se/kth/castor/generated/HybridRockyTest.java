package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFStreamEngineRockyTest {

@Test public void testShowFormWithoutResourcesAndFonts() throws Exception { PDFont font = mock(PDFont.class); when(font.getName()).thenReturn("/F1"); PDFontDescriptor fd = mock(PDFontDescriptor.class); when(fd.isType3Font()).thenReturn(false); when(((PDSimpleFont)font).toUnicodeStringArray()).thenThrow(new UnsupportedOperationException()); when(font.getFontDictionary()).thenReturn(mock(COSDictionary.class)); when(font.getBaseFont()).thenReturn("/F2"); COSName name = COSBase.DEFAULT_SUBTYPE; when(name.equals(any())).thenAnswer(invocation -> invocation.<COSSubtype> getArgumentAt(0)==null ? false : true );when(documentContextMockedStatic.withDocument(Matchers.any(), Matchers.eq(true))).thenCallRealMethod(); try (PDFormXObject pdFormxobj = new PDFormXObject(mock(PDDocumentCatalog.class), mock(InputStreamFactory.class))) { documentRendererUnderTest.showForm(pdFormxobj); verifyZeroInteractions(contentWriterMock); assertThatThrownBy(() -> pdfRenderingSettingsService.renderToFileSystem(document)).hasMessageContainingAll("Cannot find any resources", "/F1", "/F2") .hasStackTraceContaining(".renderer.AbstractPdfBoxRenderer$5.evaluate(AbstractPdfBoxRenderer.java:478)", ".renderer.AbstractPdfBoxRenderer.renderInternal(AbstractPdfBoxRenderer.java:690)") ; } }

}