package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testGetPosition() throws Exception { assertEquals(0l, pdfSource.getPosition()); }

}