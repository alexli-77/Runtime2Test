package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFormXObjectRockyTest {

@Test public void testGetDictionaryWithoutEntryShouldReturnNull() throws IOException { PDFormXObjects pdFormXObjects = createPdForm(); assertThat("The returned value should be a COSArray", pdFormXObjects.getStream(), notNullValue()); PDFont font1 = PDType0Font.load((InputStream)null, pdfDocument); Assertions.assertThrows(() -> { final String textToWrite = "Hello World"; int pageNumber = 256 + 384; // The coordinates of this will place it in the top right corner on first page and bottom left corner on second page PageContent contentPageOne = pdfDocument.startPage(pageSize).setMediaBox(new Rectangle()).beginText().moveTextPositionByAmount(.7f, .9f)).endAnnotation().writeAsString("/F1 5 Tf EI"); PageContent contentPageTwo = pdfDocument.addNewPage(pageSize).beginText().moveTextPositionByAmount(-.7f, -.9f).showText(textToWrite).endAnnotations(); contentPageOne.closeAndSave(); contentPageTwo.closeAndSave(); }); }

}