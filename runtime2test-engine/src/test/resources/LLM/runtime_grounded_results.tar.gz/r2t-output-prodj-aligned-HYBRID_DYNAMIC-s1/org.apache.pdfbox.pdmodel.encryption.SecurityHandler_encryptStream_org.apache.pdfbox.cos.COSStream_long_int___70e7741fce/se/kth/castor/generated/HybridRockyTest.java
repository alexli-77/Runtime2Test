package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SecurityHandlerRockyTest {

@Test public final void testEncryptStream128BitAESNoPaddingWithNullKeyAndIv() throws Exception { PDDocument doc = new PDDocument(); ByteArrayOutputStream baos = new ByteArrayOutputStream(); PDPage page = new PDPage(); doc.addPage(page); PDCrypto cryptoDictionaryEntryValue = new PDCrypto(StandardProtectionPolicy.DEFAULT_ENCRYPTION_ALGORITHM, StandardProtectionPolicy.DEFAULT_KEY_SIZE, "".toCharArray(), "", SecurityProvider.BUILTIN).getCryptoDictionaryForPDFObject(); pdDocEncryption = new COSEncryption(); dictMap.put("/V", new Long(4)); dictMap.put("/R", new Integer(3)); dictMap.put("/O", new String("OwnerPassword")); dictMap.put("/U", new String("UserPassword")); dictMap.put("/Length", new Long((long)(baos.size()+56)/2-79L-(doc.getTrailer()).size())); dictMap.put("/CF", new HashMap()); Map<COSDictionary, COSDictionary> encDictList = new LinkedHashMap<>(); List<PDFieldLockupInformation> fieldInfoList = Collections.<PDFieldLockupInformation>emptyList(); DictionarySecurityHandler securityHandler = new DictionarySecurityHandler(pdDocEncryption, encryptionParams, standardDecrypterParameters); EncryptedType type = securityHandler.encrypt(dictMap, encDictList, fieldInfoList, baos); assertEquals(-101, type.getValue()); assertNotNull(type.getMessage()); }

}