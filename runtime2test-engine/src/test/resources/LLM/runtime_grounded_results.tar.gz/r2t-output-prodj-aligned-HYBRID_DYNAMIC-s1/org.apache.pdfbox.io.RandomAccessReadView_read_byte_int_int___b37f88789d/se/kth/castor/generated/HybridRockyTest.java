package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public void testIsAtEndOfFileWhenNotReachedYetThenReturnFalse() throws Exception { RandomAccessInputStream inputStream = newRandomAccessInputStreamWithMockedRandomAccessSourceThatAlwaysSucceedsInTheFirstCallToNextByteAndThrowsAnExceptionOnSecondTryForSizeCheckingAfterThatItWillContinueWorkingAsExpectedAgain() .withAvailableFromCurrentPositions((long) 5); assertEquals("Should not be at end of file yet.", false, inputStream.isEOF()); verifyZeroInteractions(mockRandomAccessSource); reset(mockRandomAccessSource); }

}