package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFontFile3() throws IOException, InvalidPasswordException { FontEncoding encoding = pdffont.getPdModel().createDefaultCMap(); assertNotNull("font file should have been set",encoding); Assertions.assertThatCode(() -> pdffont.getFontProgram()).doesNotThrowAnyException(); }

}