package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStringRockyTest {

@Test public void testHashcodeForceTrueAndFalseAreDifferentValues() throws Exception { assertNotEquals("Same byte array but force hex form is different", new PDFStreamByteObject(BYTEARRAY, true).hashCode(), new PDFStreamByteObject(BYTEARRAY, false) .hashCode()); }

}