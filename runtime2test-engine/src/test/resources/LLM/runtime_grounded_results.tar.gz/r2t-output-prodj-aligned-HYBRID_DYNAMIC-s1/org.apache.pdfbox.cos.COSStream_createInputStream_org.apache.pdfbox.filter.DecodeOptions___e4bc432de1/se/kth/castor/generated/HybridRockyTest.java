package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

@Test public void testGetFiltersForFlateCompressedDataWithoutPredictorAndColorspace() throws Exception { assertThat((Object[]) instanceToBeAnalysed.getFilters()).containsExactlyInAnyOrderElementsOf(new Object[]{"DCTDecode"}, getDefaultColorSpace()); }

}