package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetEmbededDict() throws Exception { PDDocument document = new PDFBoxResourceLoader().loadPDFDoc("few0253469"); assertEquals(document.getPage(0).getResources(), document.getTrailer().getCOSStream()); }

}