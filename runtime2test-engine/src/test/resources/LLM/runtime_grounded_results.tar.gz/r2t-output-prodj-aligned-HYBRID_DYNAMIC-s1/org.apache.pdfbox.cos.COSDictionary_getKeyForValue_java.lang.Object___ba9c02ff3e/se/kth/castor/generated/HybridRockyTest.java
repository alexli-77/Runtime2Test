package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetKey() throws Exception { COSDictionary dict1 = new COSDictionary(); assertEquals("0", dict1.keySet().toString()); assertTrue(!dict1.containsKey("5")); assertNotNull(dict1); COSSubset subset = dict1.createSubset("3"); assertFalse(subset == dict1); assertEquals(2L, subset.size()); final String expected[] = {"4","6"}; List listKeys = Arrays.asList(expected); Iterator iter = listKeys.iterator(); while (iter != null && iter.hasNext()) { assertTrue(subset.containsKey((String)(iter.next()).trim())); } DictionaryUtil.addElementToArray(listKeys,"8972"); DictionaryUtil.removeFromArray(listKeys,"4"); int i = -1 ;for(final Map.Entry e: subset.entrySet()) { i++; } assertEquals(-1 ,i ); }

}