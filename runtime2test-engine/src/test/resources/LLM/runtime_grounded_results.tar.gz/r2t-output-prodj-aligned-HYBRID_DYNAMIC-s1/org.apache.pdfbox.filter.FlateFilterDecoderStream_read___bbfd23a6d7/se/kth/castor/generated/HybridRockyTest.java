package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FlateFilterDecoderStreamRockyTest {

@Test public void testReadByteAfterEndOfStreamIsMinusOne(){ assertEquals(-1, inputSourceMock.read()); verify(inputStream).close(); }

}