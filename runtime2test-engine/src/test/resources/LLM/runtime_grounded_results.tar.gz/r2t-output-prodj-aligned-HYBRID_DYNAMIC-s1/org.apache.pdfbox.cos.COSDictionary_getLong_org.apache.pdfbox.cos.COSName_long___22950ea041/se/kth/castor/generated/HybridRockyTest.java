package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetLong() throws Exception { assertEquals((long) 205, dict.getLong("Length").intValue()); }

}