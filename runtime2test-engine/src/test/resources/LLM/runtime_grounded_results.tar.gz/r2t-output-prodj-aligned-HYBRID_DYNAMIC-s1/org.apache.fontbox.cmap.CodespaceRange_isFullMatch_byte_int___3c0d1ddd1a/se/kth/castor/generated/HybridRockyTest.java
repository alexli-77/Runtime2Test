package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CodespaceRangeRockyTest {

@Test public void testIsFullMatch() throws Exception { assertTrue("Should have been a full match", csr1.isFullMatch(new byte[]{0x43}, 1)); assertFalse("Should not have been a partial match", csr1.isPartialMatch(new byte[]{0x48})); }

}