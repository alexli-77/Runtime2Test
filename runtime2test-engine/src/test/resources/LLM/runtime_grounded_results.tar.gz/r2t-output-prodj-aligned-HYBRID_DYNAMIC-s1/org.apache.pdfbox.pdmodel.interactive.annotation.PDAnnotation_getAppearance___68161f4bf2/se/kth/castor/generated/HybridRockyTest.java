package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetAppearance() throws Exception { assertEquals("test failed - wrong type of result",null,$PDFANNOTATION$.getAppearance()); }

}