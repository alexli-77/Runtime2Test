package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PanoseFlagRockyTest {

@Test public void testGetByteArray() throws IOException, FontFormatException { PDType0Font font14 = new PDType0Font(doc, ttfFile); assertNotNull("font should not have been null", font14); byte[] bytes = font14.getDescriptor().toPDF()); String str2 = new java.lang.String(bytes).trim(); log.debug("str2=" + str2); assertTrue("Should contain " + "/Subtype /TrueType" , str2.contains("/Subtype /TrueType")); assertFalse("should NOT include Name but does:"+str2,"str2".indexOf("Name") != -1 ); }

}