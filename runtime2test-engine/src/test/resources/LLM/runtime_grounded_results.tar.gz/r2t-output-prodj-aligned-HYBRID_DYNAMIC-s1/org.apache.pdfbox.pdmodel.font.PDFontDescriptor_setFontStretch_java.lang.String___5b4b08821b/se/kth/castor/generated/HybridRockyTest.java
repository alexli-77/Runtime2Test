package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetFontStretch() throws Exception { Font fd = getDescendantFont(); assertNull("Default value",fd.getBaseFont()); String str="Condensed"; fd.setFontStretch(str); PDFontDescriptor desc = (PDFontDescriptor )((PDCIDict) ((PDComplexFileSpecification) fd).getAFDictionary()).getIncludedStream().getEntries().values().iterator().next(); Assertions.assertEquals(desc.getFontStretch(), "Condensed"); fd.removeSubsets(!true ); Assertions.assertFalse(desc.containsKey(org.apache.pdfbox.pdmodel.common.DCTerms.FORMAT)); Assertions .assertTrue(desc.getKeys().isEmpty()); }

}