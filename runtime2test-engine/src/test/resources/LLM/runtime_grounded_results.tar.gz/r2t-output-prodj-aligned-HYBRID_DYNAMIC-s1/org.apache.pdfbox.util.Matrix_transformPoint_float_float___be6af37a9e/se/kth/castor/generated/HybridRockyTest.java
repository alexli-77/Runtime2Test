package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testTransformPoint() throws Exception { assertEquals("transformed",new Point(-5,-8),MatrixUtils.createIdentity().translate(-10).rotateClockWiseQuarterTurn().scale(.5f,.5f).getAffineTransform().transform($POINTS$, null)); }

}