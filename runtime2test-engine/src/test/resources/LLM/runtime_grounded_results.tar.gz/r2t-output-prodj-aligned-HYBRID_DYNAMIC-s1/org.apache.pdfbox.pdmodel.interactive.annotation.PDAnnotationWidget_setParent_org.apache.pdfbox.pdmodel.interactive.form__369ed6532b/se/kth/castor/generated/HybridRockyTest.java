package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public final void testGetSetParentWithTerminalFieldsSharingTheirDict() throws Exception { org.junit.Assert.fail(); }

}