package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLinkRockyTest {

@Test public void testGetBorderStyleNull() throws IOException { PDAnnotationLine pdaline1 = createAcroFormField(); assertEquals("borderstyle", 0f, pdaline1.getBorderWidth(), EPSILON); }

}