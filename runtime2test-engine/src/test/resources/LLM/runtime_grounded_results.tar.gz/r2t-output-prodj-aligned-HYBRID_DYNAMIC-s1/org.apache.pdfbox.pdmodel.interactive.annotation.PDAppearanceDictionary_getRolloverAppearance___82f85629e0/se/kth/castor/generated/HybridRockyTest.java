package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceDictionaryRockyTest {

@Test public void testGetCOSDictionaryWithNullValueReturnsNull(){ assertThat(appearancesDict.getCOSDictionary("foo"),is((nullValue())) ); }

}