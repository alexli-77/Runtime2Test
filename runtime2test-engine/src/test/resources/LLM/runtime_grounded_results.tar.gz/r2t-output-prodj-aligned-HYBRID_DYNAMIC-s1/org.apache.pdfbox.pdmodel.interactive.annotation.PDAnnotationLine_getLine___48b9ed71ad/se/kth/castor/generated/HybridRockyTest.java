package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetLL() throws IOException { PDAnnotationMarkup annotation = new PDAnnotationText(); assertNull("No ll", annotation.getLink()); }

@Test public void testSetAndGetLL() throws Exception{PDDocument doc = new PDDocument(); PDFont font = PDType0Font.load(doc , ResourceLoader.pathToURL("/fonts/Helvetica-Bold.dfont"), false );PDPage page = new PDPage(); PDAcroForm form = new PDAcroForm(doc); pdAnnot = new PDAnnotationWidget(); pdAnnot.setRectangle(new PDRectangle(569f,487f));pdAnnot.setBorderColor(new COSArray(){});pdAnnot.setBackgroundColor(new COSArray(){});pdAnnot.setContents("\u30b7\u30e7");pdAnnot.setTextAlignment(PDBorderEffectDictionary.TEXTALIGNMENT_CENTERED);form.addField("testfield","text",pdAnnot);page.setLastModified(Calendar.getInstance().getTimeInMillis(), Calendar.getInstance().getTimeZoneOffset()) ;doc.addPage(page) ;PDAppearanceStream appearanceStreamUnderline = new PDAppearanceStream(doc, "", PageSize.A4, COSName.DINGBATS,"Identity-H");appearanceStreamUnderline .createDefaultResources();InputStream inputStreamUnderline = this.getClass().getResourceAsStream ("underline-annotation-stream-template.txt") ;String strDataForTemplate = IOUtils.toString(inputStreamUnderline, Charsets.ISO_8859_1); String dataWithPlaceholderReplacedByContentOfPDFBox = replaceAllOccurences(strDataForTemplate, "%%CONTENT%", "\n" + pdAnnot.getTextState().getFont().encodeDirectly((byte)(int)'Y')+". "); InputFormat format = new InputFormat(dataWithPlaceholderReplacedByContentOfPDFBox, true);format.parse(appearanceStreamUnderline.getOutputStream());List<PDAction> actions = ((PDAppearanceCharacteristicsDictionary)annotation.getCOSDictionary()).getActions(); List<PDAction> actionItems = actions == null?null:(actions instanceof ArrayList)?(

}