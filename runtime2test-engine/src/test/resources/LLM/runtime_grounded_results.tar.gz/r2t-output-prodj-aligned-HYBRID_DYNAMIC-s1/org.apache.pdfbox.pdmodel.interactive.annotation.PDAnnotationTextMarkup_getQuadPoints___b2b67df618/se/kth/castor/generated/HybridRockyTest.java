package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationTextMarkupRockyTest {

@Test public void testGetSetQuadPoints01() throws IOException, InterruptedException { PDAnnotationLine lineAnnot = new PDAnnotationLine(); assertNull("Default value must be null",lineAnnot.getQuadPoints()); }

}