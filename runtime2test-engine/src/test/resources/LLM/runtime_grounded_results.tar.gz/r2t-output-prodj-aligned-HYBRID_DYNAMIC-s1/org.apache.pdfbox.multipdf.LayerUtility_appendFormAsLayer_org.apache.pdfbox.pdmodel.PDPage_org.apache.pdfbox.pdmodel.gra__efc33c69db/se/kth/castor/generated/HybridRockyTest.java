package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LayerUtilityRockyTest {

@Test public void testGetAndSetRotationValueOfZeroIsIgnoredByConstructor() throws Exception { assertEquals(90, doc1.getNumberOfPages()); PDPage pdPage = doc2.getPage(doc2.getNumberOfPages() - 1); pdfWriter.setCreator(TESTINGAREA); int rotationVal = Integer.parseInt(rotatedFileContents[5]); switch (rotationVal % 360) { case 0 -> assertTrue(pdPage.findResources().containsKey("/R")); case 90 -> assertFalse(pdPage.findResources().containsKey("/R")); case 180 -> assertTrue(pdPage.findResources().containsKey("/R")); case 270 -> assertFalse(pdPage.findResources().containsKey("/R")); } }

}