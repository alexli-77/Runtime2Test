package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetSetCaptionVerticalOffset() throws Exception { assertEquals(-28, ctPageContentStreamDestinationDictionaryUnderTest.getCaptionVerticalOffset(), DELTA); }

}