package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceDictionaryRockyTest {

@Test public void testGetDefaultAndRolloverEntries() throws IOException, InterruptedException { PDAcroForm acroform = document1.getDocumentCatalog().getAcroForm(); assertNotNull("No Acroforms",acroform); Map<PDTerminalField, Object> fieldsMap = createFieldsMap(document1, "/Annot"); List<? extends PDFontDescriptor> fontsDescriptorsList = Arrays.asList((PDFontDescriptor[]) fontManager.parseFontFile("/Helv")); for (int i = 0 ;i < 32; ++i){ String fieldKey = "" + Character.toChars(97+i)[0]; final boolean hasValue = i%4 == 0 || i%5==0|| i %6 == 0; addTextFieldToAcroformWithoutSettingAPValues(acroform,fieldKey,""+(char)(i),hasValue?fontsDescriptorsList:"helvetica-bold"); } acroform.setNeedAppearances(true); document1.saveIncremental(new java.io.ByteArrayOutputStream()); setUp(); checkResultOfFirstPageForAllCharacters('a'); assertTrue("There should have been at least one Appearance Stream!",foundAtLeastOneAS); foundAtLeastOneAS = false; checkResultOfSecondPageForAllCharacters('b',false); assertFalse("Shouldn't find any AS on page two because none were generated.",foundAtLeastOneAS); try{ pdfBoxWriterUnderTest.writeTextOnEachCharacterPositionUsingGivenRotationAngle(rotatedWriteConfigurations[2], "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 !\"#$%&'()*+,-./:;<=>?\\{|}~`^°¹²³£§•¶©®™ª«»¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ¡¢¥€¤¦¨©¬®¯

}