package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testGetFontDescriptor() throws Exception { assertEquals("Helvetica", FontUtils.getBaseFontFromDictionary((new PDType0Font()).font).getName()); }

}