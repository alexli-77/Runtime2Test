package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationSquareCircleRockyTest {

@Test public void testGetSetMarginLeftRightTopBottom() throws Exception { PDBorderLineAnnotation annot1 = (PDBorderLineAnnotation)PDAnnotationFactory .createTextStamp(); assertEquals("wrong default value", new COSArrayList<>(new COSBase[0]), annot1.getBorder()); }

}