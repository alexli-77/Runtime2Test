package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetFontName() throws Exception { COSDictionary dict = getSimpleDict(); FontFileWriter writer = mock(FontFileWriter.class); PDFont fd = createMockedFD("TTFF", dict, writer); replayAll(); String result = fd.getBaseFont(); verifyAll(); assertEquals($BASIC$,result); resetAll(); pdfont.setFontDescriptor((PDFontDescendant)fd); fd.setFontFamily($FAMILY1$); verifyAll(); resetAll(); fd.setFontSubfamily($SUBFAMILY2$); verifyAll(); resetAll(); fd.setTypeFace($TYPE3$); verifyAll(); resetAll(); fd.setCharacterWidthArray($(CHARARRAY4$),$(WIDTH5$)); verifyAll(); resetAll(); fd.setCapHeight($(CAPHEIGHT6$)); verifyAll(); resetAll(); fd.setItalicAngle($(ITALIAN7$)); verifyAll(); resetAll(); fd.setAscentLine($(ASCENT8$)); verifyAll(); resetAll(); fd.setDescentLine($(DESCENT9$)); verifyAll(); resetAll(); fd.setXHeight($(XHEIGHT10$)); verifyAll(); resetAll(); fd.setStemV($(STEMV11$)); verifyAll(); resetAll(); fd.setFlags($(FLAGS12$)); verifyAll(); resetAll(); fd.setFirstChar($(FIRSTCH13$)); verifyAll(); resetAll(); fd.setLastCha $(LASTCHAR14$); verifyAll(); resetAll(); fd.setLeading($(LEADING15$)); verifyAll(); resetAll(); fd.setAvgWid($(AVGWIDTH16$)); verifyAll(); resetAll(); fd.setMaxWidth($(MAXWIDTH17$)); verifyAll(); resetAll(); fd.setMissingHexWid($(MISSINGEXTRAWIDTH18$)); verifyAll(); resetAll(); fd.setDefaultEncoding($(DEFAULTENCODED19$)); verifyAll(); resetAll(); fd.setNonAsciiPlacement($(NONASCIIPLACEMENT20$)); verifyAll(); resetAll(); fd.setExtendCollection($(EXTENDCOLLECT

}