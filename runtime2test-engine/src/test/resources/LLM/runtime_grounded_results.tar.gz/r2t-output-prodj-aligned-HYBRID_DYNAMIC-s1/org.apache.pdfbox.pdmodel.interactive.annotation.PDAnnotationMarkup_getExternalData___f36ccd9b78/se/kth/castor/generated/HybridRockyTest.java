package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetExternaData() throws Exception{ assertNull("Should be no externadata", annot1.getExternalData()); }

}