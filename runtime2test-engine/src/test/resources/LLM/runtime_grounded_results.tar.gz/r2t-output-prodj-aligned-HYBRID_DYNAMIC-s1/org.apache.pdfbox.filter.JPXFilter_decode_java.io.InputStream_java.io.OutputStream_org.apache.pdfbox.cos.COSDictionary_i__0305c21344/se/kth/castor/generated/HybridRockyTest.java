package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class JPXFilterRockyTest {

@Test public void testDecodeFileWithoutCodestreamBox() throws Exception { File file = getClass().getResourceAsStream("/jpx-withouthcodestreambox.jp2") .toURI() .getSchemeSpecificPart() .replaceFirst(".*/", "") .startsWith("/") ? null : new File(getClass().getResourceAsStream("/jpx-withouthcodestreambox.jp2").toURI()).getAbsoluteFile(); assertNotNull(file); try (PDDocument doc = PDDocument.load(file)) { PDFont font = new PDPixelFont(doc).fontForEncoding((String[])null); String text = ""; for (Object obj : doc.getPage(0).findObjectsOfSubtype(PDFunction.class)) { PDSampledFunction function = (PDSampledFunction)(obj instanceof COSArray && !((COSArray)obj).isEmpty()?((COSBase)((COSArray)obj).get(0)).fetchValue():obj); float minX = Float.parseFloat(function.getNameToken(4)); float maxY = Float.parseFloat(function.getNameToken(5)); float scaleFactor = Float.parseFloat(function.getNameToken(6)); int sizeX = Integer.parseInt(function.getNameToken(7)); int sizeY = Integer.parseInt(function.getNameToken(8)); float[] sampleValues = function.sampleToRangeValues(sizeX*sizeY); List<float[]> samplesList = Arrays.stream(sampleValues).mapToObj(f -> new float[]{f}).collect(Collectors.toCollection(() -> new ArrayList<>()) ); for (int j = 0; j <= sizeY - 1; j++) { StringBuilder sb = new StringBuilder("\n"); for (int i = 0; i <= sizeX - 1; i++) { final double vv = MathUtils.clamp(samplesList.get(Math.round((maxY - j)/scaleFactor)-minX), 0, 255)*255; char c = Character.forDigit(Math.floorMod(vv, 36), 36); while (!Character.isLetterOrDigit(c)) { c++; } sb.append(' ').append(c); } text += sb.toString(); } }

}