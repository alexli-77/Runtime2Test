package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public void testGetAppearanceCharacteristicsNull() throws Exception { PDAnnotationWidget widget = create(); assertNotNull("The returned value should never be null.",widget.getAppearance()); }

}