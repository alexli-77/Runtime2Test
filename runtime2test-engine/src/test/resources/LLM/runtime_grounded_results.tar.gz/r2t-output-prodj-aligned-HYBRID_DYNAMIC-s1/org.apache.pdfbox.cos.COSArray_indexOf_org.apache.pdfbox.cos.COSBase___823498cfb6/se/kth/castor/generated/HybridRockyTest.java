package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testIndex() throws Exception { COSArray array = new COSArray(); assertEquals(-1, array.indexOf((Object)null)); array.add("one"); assertEquals(-1,array.indexOf((Object)"two")); array.setInt(5,"five"); assertEquals(-1, array.indexOf((Object)7)); array.add("six"); array.removeAllObjects(); assertEquals(-1, array.indexOf((Object)"three")); }

}