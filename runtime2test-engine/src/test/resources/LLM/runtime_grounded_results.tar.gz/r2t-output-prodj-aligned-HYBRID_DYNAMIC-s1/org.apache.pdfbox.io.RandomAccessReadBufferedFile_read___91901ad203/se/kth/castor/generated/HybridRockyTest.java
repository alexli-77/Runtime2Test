package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferedFileRockyTest {

@Test public void testRead29451() throws IOException { assertEquals(-1, getReader().read()); }

@Test void testClose(); @SuppressWarnings({"unchecked","deprecation"}

}