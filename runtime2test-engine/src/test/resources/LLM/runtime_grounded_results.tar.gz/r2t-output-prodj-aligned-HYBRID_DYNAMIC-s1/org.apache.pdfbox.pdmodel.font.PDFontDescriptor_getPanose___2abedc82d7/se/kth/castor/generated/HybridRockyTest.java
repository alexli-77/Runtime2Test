package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetPanose10() throws Exception { PDType2Font font = load("lucidabright-type2"); assertEquals("/F694B538", font.getName()); Assertions.assertNull(font.getBaseFont(), "Expected no base font."); Optional<PDResources> resourcesOptional = font.getResourceCache().tryLoadCachedEntry(() -> () -> FontUtils.loadAllFormattedPagesFromPDF(new FileInputStream(testFile), false).stream() .map((page) -> page.getContents()) .filter(Objects::nonNull) .findFirst()).orElseThrow(() -> new IOException("Failed loading contents")); List<? extends PDFontInfoPage> pages = resourcesOptional.flatMap((resources) -> FontUtils.extractAndSaveIndividualGlyphImagesToTempDirectoryForDebugging(font, resources)).collect(Collectors.toList()); String firstImageFilename = Objects.requireNonNull(pages.iterator().next()).imageFilenames[0]; BufferedImage image = ImageIO.read(Files.asByteSource(firstImageFilename).inputStream()); int widthInPixels = image.getWidth(); double pixelsPerEm = Math.ceil(widthInPixels / FONTSZIE); System.out.println("\n\tWriting individual glyph images for debugging... (" + FONTSZIE + ")px per em:\n" ); AtomicInteger indexCounter = new AtomicInteger(-1); Map<Character, Integer> charCodeIndexMapping = IntStream.rangeClosed(' ', '~') .parallel() .unordered() // we don't need an ordered map here as there are only about ~75 characters anyway
                    .peek((i) -> indexCounter.incrementAndGet())// this works because Java treats integer literals like single character strings when passed into Character constructor
                .mapToObj((c) -> new SimpleImmutablePair<>((char) c, indexCounter.intValue())) .sorted((a, b)->{if (!isAsciiChar(b)) { return -1;} else if(!isAsciiChar(a)){ return 1;}else {return 0;} }) .collect( Collectors.toConcurrentMap((pair) -> pair.left, (pair) -> pair.right )); StringBuilder sb = new

}