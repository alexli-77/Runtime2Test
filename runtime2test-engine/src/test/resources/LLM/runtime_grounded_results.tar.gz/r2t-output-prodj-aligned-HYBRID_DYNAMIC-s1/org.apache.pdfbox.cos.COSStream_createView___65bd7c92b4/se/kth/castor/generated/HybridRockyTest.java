package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

junit.framework.Assert.assertEquals((long)(streamData.getBytes().length), pdfObjectReferenceTest.testPdfDocument().openOrNewStream("/Root").length());
// End of runtime facts for createView() method.
void setParent(COSDictionary parentDictionary); void close(); boolean hasOutputStreamWriter(); OutputStreamWriter getOutputStreamWriter(); int writeToOutputQuietlyAndClose(); COSArray generateFiltersForWrite(); static final String FILTER_DCT_ENCODE; static final String DEFLATE_FILTERNAME; @SuppressFBWarnings({ "UWF_UNWRITTEN_PUBLIC_OR_PROTECTED_FIELD" }) byte[] bf; }

}