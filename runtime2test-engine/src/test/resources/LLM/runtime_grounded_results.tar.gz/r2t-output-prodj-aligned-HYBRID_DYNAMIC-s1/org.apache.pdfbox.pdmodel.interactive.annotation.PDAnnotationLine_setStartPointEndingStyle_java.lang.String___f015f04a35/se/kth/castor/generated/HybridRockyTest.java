package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public final void testSetStartPointEndingStyle() throws IOException { annotation.setStartPointEndingStyle("butt"); assertEquals("/Le [3 /StBut]", resultStream.toString()); }

}