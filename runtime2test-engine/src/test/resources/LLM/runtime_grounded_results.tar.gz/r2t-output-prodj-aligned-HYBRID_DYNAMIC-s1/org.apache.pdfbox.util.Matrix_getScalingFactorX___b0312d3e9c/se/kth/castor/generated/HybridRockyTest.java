package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testGetScalingFactorX() throws Exception { assertEquals((float) Math.sqrt(3), mtrix.getScalingFactorX(), EPSILON); assertTrue("should be positive", mtrix.getScalingFactorY() > 0f && mtrix.getShearingCorrectionDegrees() == 0.0d); assertNotNull(mtrix.toString()); Matrix mtx = new Matrix(); String s = "[" + Arrays.deepToString(new Object[]{mtx}) + "]"; System.out.println(s); fail(); }

}