package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDRectangleRockyTest {

@Test public void testTransform() throws Exception { Matrix mtx = new Matrix(-1f, -1f, 189.38f, 285.41f); Rectangle rct = new Rectangle(new PDRectangle(1)); assertEquals("rect", mtx.createAffineTransform().createInverse().toString(), rct.transform(mtx).toGenericString()); }

}