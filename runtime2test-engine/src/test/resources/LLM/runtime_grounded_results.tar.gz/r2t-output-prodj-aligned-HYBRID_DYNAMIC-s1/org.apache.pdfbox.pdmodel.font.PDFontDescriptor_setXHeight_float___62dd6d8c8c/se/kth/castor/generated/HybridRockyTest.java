package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetXHeight() throws Exception { FontBoxFont fbffont1 = (new TrueTypeParser()).parse("src/test/resources/fonts/ttf-verticalwritingfont.otf"); assertEquals(-469.87, ((TrueTypeFont)fbffont1).getOS2Table().getTypoAscender(), DELTA); }

}