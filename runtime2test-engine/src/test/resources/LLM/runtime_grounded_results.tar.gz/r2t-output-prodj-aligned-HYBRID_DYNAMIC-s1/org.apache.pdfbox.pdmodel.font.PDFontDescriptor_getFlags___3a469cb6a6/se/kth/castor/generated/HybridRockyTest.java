package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFlagsNoCosArrayForFontFile5() throws IOException { FontBoxResourceLoader loader = new DefaultFontBoxResourceLoader(); final PDFontDescriptorDictionary fd = createFDDictionaryWithoutFlagEntry("fontfile"); PDType0Font type0Font = new PDType0Font(loader, null, "abc", "", "", true, false, false, 4896, 72, -100, FONTBBOX[1], FONTBBOX[0], FONTBBOX[2]-FONTBBOX[0], FONTBBOX[3]-FONTBBOX[1]); assertEquals((Integer) 0, type0Font.getPdfObject().getDirect()); assertNotNull(type0Font.getDescendantFonts()); AssertionsHelper.expectThrowsIllegalArgumentException(() -> type0Font.setToUnicode(fd)); }

}