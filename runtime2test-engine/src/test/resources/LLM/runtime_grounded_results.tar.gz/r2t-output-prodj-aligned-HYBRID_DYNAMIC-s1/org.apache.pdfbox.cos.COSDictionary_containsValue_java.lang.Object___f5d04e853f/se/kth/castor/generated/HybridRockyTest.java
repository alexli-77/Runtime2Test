package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testContainsValueWithCosNull() throws IOException { COSDictionary dictionary1 = new COSDictionary(); assertFalse("Expected false",dictionary1.containsValue(null)); }

}