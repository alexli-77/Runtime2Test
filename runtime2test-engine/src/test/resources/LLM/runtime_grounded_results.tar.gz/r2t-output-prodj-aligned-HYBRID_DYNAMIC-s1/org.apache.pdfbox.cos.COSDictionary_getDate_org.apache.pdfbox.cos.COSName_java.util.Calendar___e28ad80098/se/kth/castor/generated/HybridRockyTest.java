package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetDate() throws Exception { PDDocument doc = new PDFParser().parse("target/test-data/" + "helloWorld.pdf"); COSDictionary rootDict = doc.getDocumentCatalog(); Assertions.assertEquals(null, rootDict.getDate()); Calendar c1980 = Calendar.getInstance(); c1980.setTimeZone(java.time.ZoneOffset.UTC); c1980.clear(); c1980.set(1976, 3 - 1 /* months are zero based*/ , 25); rootDict.setDateTime(c1980); Calendar actualCalender = rootDict.getDate(); assertNotNull(actualCalender); assertTrue(Math.abs(c1980.getTimeInMillis() - actualCalender.getTimeInMillis()) < 100L); String s = rootDict.toString(); System.out.println(s); JSONAssert.assertJsonEquals(JSONCompareMode.STRICT, "{}\n", s, false); }

}