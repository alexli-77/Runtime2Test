package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HorizontalMetricsTableRockyTest {

@Test public void testGetAdvance() throws IOException, FontFormatException { assertEquals("testGetAdvance", font.getHorizontalAdvancement('c'), hmFont.getAdvanceWidth(98)); }

}