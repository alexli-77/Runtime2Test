package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFunctionRockyTest {

@Test public final void testSetRange() throws IOException { COSDictionary dict1 = new COSDictionary(); PDFunction func2 = new PDFunctionType4Function("0", "1"); assertNull(func2.getDomain()); String[] domain = {"a"}; func2.setDomain(domain); assertEquals(domain[0], ((PDFunctionType4) (((PDDictionaryWrapper)(func2)).getCOSDict())).getDomainString()); }

}