package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSObjectKeyRockyTest {

@Test public void testEquals() throws Exception { COSObjectKey cosObjOne = new COSObjectKey(); assertFalse("Should not be equal", cosObjOne .equals((null)));  }

@Test public final void testNotEqualNull() throws IOException, InvalidPropertiesFormatException { ByteArrayInputStream inStream = getByteArrayInputStreamForFile("/test-documents/" + INPUTFILENAME ); PDDocument doc = Loader.loadPDF(inStream); PDFMergerUtility pdfMU = new PDFMergerUtility(); byte[] bytesOut = pdfMU.appendDocuments(new ArrayList<PDDocument>(),doc).toByteArray(); String outString = convertBytesToString(bytesOut); Assertions.assertTrue(outString.contains(INVALIDREFS)); }

}