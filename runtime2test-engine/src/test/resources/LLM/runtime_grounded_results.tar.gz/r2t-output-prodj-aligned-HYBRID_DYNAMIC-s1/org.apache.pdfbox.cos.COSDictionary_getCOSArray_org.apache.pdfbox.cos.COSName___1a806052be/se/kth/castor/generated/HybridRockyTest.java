package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSArray() throws Exception { assertTrue("Should have been able to find dictionary.", dict != null && !dict.isEmpty()); assertEquals("Wrong type of value found at /Annots[0]", COSSubtype, annotTypeKeyValuePair.getValue().getNameAsString()); assertNotNull("Couldn't retrieve annotation dictionary!", annotationsDictObj); int i = -1; Iterator<java.util.Map.Entry<COSDictionary, Object>> iterator = pageDic.entrySet().iterator(); while (iterator.hasNext()) { ++i; java.util.Map.Entry<COSDictionary, Object> pair = iterator.next(); Pair<COSDictionary, String> pairToAdd = new MutablePair<>((COSDictionary)(pair.getKey()), "" + i); entries.addLast(new ImmutablePair<>(annotationsDictRef, pairToAdd)); pairsList.putIfAbsent(entries.peek(), new ArrayList<>()); List<MutablePair<Integer, Integer>> listOfEntriesForPageWithIndexZero = pagesList.getFirst(); listOfEntriesForPageWithIndexZero.set(0, new MutablePair<>(pageNumber, entries.size())); } assertEquals("Did not add correct number of keys-values into map.", numKeysPerAnnotation, annotationsDict.size()); Map<COSName, COSBase> nameBasePairs = annotationsDict.toMap(); Iterator<java.util.Map.Entry<COSName, COSBase>> iter = nameBasePairs.entrySet().iterator(); while (iter.hasNext()) { final java.util.Map.Entry<COSName, COSBase> next = iter.next(); final String valStr = valToStringConverter.convertFromBytesOrStream(null, next.getValue()).toString(); resultantValuesByKey.computeIfPresent(next.getKey(), (k, v) -> v += ", " + valStr).ifEmpty(() -> resultantValuesByKey.put(next.getKey(), valStr)); } assertFalse("There should only be one Annotation per Page so there shouldn't be any duplicates!", duplicatePagesExistInDocument); }

@Test void testGetCOSArray() throws IOException { PDFParser parser = new PDFParser(Files.newInputStream

}