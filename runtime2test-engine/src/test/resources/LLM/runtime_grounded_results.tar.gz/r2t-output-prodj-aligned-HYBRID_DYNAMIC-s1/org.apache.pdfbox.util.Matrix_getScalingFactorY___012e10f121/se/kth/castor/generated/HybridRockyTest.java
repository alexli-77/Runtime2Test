package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testGetScalingFactorY() throws Exception { assertEquals((float) Math.sqrt(.8), mtx.getScalingFactorX(), EPSILON); assertEquals(-1f / .8f, mtx.getShearingMatrix().getValueAt(0, 0), EPSILON); assertTrue("Wrong scaling factor Y", mtx.isSingular()); assertNull(mtx.invert()); }

}