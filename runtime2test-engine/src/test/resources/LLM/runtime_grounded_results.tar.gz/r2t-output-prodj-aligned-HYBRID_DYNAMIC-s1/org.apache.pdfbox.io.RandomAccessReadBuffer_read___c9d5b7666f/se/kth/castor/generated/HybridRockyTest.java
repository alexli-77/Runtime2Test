package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testRead687() throws IOException{ byte[] bytes = new byte[1]; streamReaderMockedStatic.when(() -> StreamUtil.inputStreamToArray(any(), anyInt())).thenReturn(bytes); assertEquals(-1 ,testSubjectUnderTest.read()); verify(streamReaderMockedStatic, times(1)).verifyInputStreamNotNull(isA(InputStream.class)); verifyNoMoreInteractions(streamReaderMockedStatic); }

}