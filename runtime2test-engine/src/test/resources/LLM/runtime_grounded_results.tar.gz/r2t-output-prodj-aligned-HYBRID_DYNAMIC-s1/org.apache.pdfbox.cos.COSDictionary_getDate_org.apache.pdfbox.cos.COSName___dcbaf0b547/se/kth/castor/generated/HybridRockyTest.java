package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetDate() throws IOException { PDDocument doc = new PDDocument(); PDFont font = new FOPDFFont(); Map<String, Object> map = new HashMap<>(); map.put("F1", "2016-05-30"); map.put("F2", "2016-05-30T14:39Z"); map.put("F3", "2017-08-02+08'00"); pdfBoxSetUpWithCustomDocAndMapOfStrings(doc, map, font); assertNotEquals(-1L, pdPageContentStreamFor("/Contents").getBeginTextPosition().x, 0d); Calendar cal = contentStreamFromKeywordAsPlaintext.getResources().getProperties().getProperty("CreationDate"); Assertions.assertThat(cal).isEqualToIgnoringHours(new GregorianCalendar()); ContentStreamManager csMgr = new ContentStreamManagerImpl(pdPageContentStreamFor("/Contents")); String creationdateStr = csMgr.parseDateTimeStampToString(csm => csm.getResources(), "yyyyMMddHHmmss"); DateTimeFormatter formatter = ISODateTimeFormat.basicDateTimeNoMillis(); LocalDateTime ldt = formatter.withZoneUTC().parseLocalDateTime(creationdateStr); assertTrue(ldt.equalsNow()); createFileUsingPDfDocument(); closeQuietly(document); deleteTempFilesAfterTestsAreFinished(); }

}