package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDColorRockyTest {

@Test public void testToRgbWithCmykColor() throws Exception { CMYKColor cmykcolor = new CMYKColor(); Color c = cmykcolor.getJavaColor().createDerivedColor(-37496.0F / 65535.0F,-65280.0F / 65535.0F, -12693.0F / 65535.0F, -33792.0F / 65535.0F ); assertEquals("c",-37496.0F / 65535.0F , cmykcolor.getCyan(), .001); assertEquals("m",-65280.0F / 65535.0F, cmykcolor.getMagenta()); assertEquals("y",-12693.0F / 65535.0F, cmykcolor.getYellow()); assertEquals("k",-33792.0F / 65535.0F, cmykcolor.getBlack()); PDDeviceGray pdDevicegray = new PDDeviceGray(); PDFont font = null; boolean stroke = false; org.apache.fontbox.util.BoundingBox box = null; String textRenderingModeAsString = "fill"; TextPosition tp = new TextPosition((float)(Math.PI),null,"Helvetica"); AffineTransform at = new AffineTransform(); Paint paint = c.derivePaint(pdDevicegray, font, stroke, box, textRenderingModeAsString, tp, at); Color col = ((PDGraphicsState)at).nonStrokingColor; assertNotNull(col); }

}