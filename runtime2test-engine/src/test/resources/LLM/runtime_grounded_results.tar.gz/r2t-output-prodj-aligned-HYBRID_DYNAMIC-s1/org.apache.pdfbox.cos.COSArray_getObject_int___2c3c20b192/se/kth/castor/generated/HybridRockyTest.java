package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testGetObjectInt() throws Exception { assertEquals("test1".hashCode(), this.array.getObject(0).toString().hashCode()); assertTrue(!(this.array.getObject(0) == null)); }

}