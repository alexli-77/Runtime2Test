package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetResources() throws Exception { PDDocument doc1 = new PDDocument(); PDFont font = new FOPDFFont("Helvetica", "WinAnsiEncoding"); FontMapping fm = createFakeFontMapWithoutAfmAndPfbFiles(font); doc1.setResourceCacheValueGenerator(() -> fm); assertEquals(0, doc1.getPageCount()); List<PDFont> fontsFromDoc2 = generateSomeRandomPagesInNewFileUsingTheGeneratedDocAsSourceForType3GlyphWidthCalculation(doc1).stream().map(page -> page.findDescendantByClass(PDFont.class)).collect(Collectors.toList()); for (int i = 0; i < fontsFromDoc2.size(); ++i) { assertThat(fontsFromDoc2.get(i), is(equalToComparingFieldByFieldRecursively(font))); } }

}