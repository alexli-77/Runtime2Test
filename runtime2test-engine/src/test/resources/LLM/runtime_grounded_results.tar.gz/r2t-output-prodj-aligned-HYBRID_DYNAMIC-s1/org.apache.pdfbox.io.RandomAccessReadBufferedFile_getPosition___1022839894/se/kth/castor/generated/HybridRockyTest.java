package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferedFileRockyTest {

@Test public void testGetPosition() throws IOException { assertEquals(0, stream.getPosition()); }

}