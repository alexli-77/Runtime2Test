package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public void testIsEOFFalse () throws Exception{ RandomInputStream iStream = new MockRandomInputStream(); assertEquals("", true,$OBJ$.isEOF());  }

}