package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDEncryptionRockyTest {

@Test public void testGetCryptFilters() throws Exception { PDDocument document = loadEncrypted("helloWorldRsa4096.pdf"); assertEquals(1, document.getSecurityHandler().getAccessPermission().getRevision()); }

}