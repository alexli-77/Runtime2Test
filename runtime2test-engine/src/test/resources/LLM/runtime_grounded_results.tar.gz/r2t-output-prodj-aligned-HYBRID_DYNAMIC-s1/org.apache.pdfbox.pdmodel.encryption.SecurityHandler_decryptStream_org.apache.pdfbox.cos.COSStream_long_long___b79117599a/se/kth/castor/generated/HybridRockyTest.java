package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SecurityHandlerRockyTest {

@Test public final void testDecryptStreamWithIdentityCosNullObjNoGenNumber() throws Exception { securityManagerMockery.checking(new Expectations(){{ allowingDecompositionOnce(() -> sut.securityEngine).decipherAES(null, anyLong()); allowing((PDFEncryptionSecurityHandler)sut).accessAllowedOrThrow(anyBoolean(), anyString(), anyLong(), anyLong()); ignoring(sut); }} ); assertTrue(sut.hasProtectionPolicyEntries()); sut.addProtectionPolicyEntry(entryForOwnerPasswordOnly); SecurityDocument sd = parseAndGetSDFromFile("/testdata/input/protected_with_identity_filter.pdf", StandardDecrypterProvider.getInstance()).orElseThrow(Assert::failure); sut.initFromSecurityDocumment(sd); PDPage page = loadPDDocumentUsingPdfBox( "/testdata/input/protected_with_identity_filter.pdf").getPages().iterator().next(); Optional<PDStream> pdsOpt = findFirstOfType(page.findResourcesByClassName(org.apache.pdfbox.pdmodel.common.PDStream.class), pdStream -> {}); Assertions.assertThat(pdsOpt).as("There should be exactly one embedded image.").describedAs("Exactly one embedded Image must be found.") .extracting(PDStream::getLength).contains(Optional.of(674L)); }

}