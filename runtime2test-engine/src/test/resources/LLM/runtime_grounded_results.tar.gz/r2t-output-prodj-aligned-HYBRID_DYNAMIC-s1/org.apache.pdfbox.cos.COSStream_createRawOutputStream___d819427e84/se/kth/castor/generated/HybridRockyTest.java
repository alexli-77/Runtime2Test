package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

@Test public final void testCreateRawOutputStream() throws Exception { InputStream inputstream1 = this.getClass().getResourceAsStream("/test-documents/" + "helloWorldDoc.txt"); PDDocument doc2 = new PDDocument(); try (PDPage page3 = new PDPage()) { doc2.addPage(page3); java.util.List<Object> list4 = page3.getAnnotations(); COSDictionary cosdictionary5 = new COSDictionary(); COSArray array6 = new COSArray(); array6.setDirect(true); cosdictionary5.put(COSName.CONTENTS, array6); annotation = new PDBorderlessAnnotation(cosdictionary5); annotation.setRectangle(new PDRectangle()); annotation.drawAppearanceToCurrentPageForFormFlattening((PDAcroForm)null,(PDFontFactory.DEFAULT_ENCODER),doc2,inputstream1,"Hello World",0,0f,-1); assertNotNull(annotation.getContents()); String string7 = annotation.toString(); assertTrue(!string7.contains("\r")); byte abyte8[] = annotation.toByteArray(); ByteArrayInputStream bytearrayinputstream9 = new ByteArrayInputStream(abyte8); AnnotationUtils.validateContentEntryWithNoNewlines(bytearrayinputstream9); } finally { doc2.save(outputstream); doc2.close(); } }

}