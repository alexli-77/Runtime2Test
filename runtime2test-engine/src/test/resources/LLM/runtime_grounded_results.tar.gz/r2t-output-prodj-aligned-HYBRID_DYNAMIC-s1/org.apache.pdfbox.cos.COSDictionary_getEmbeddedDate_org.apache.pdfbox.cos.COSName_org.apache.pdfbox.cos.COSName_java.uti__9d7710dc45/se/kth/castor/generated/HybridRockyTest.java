package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetEmbeddedDate() throws Exception { PDDocument doc = new PDDocument(); PDFont font = new PDCIDFontType2(""); assertNull(doc.getRoot().getEmbeddedDate()); pdfDocHasNoPagesAssertionsCommon(font, "test", true); String contentString = IOUtils.toString((InputStream)(new URL("https://www.w3schools.com")).openStream(), Charset.defaultCharset()).replaceAll("<[^>]+>", "\n").trim(); try (PDPage page1 = new PDPage()) { documentWriteToFile(contentString + "\ntest\r\ndate", doc, page1); } try (PDPage page2 = new PDPage()) { documentWriteToFile("\u0456\tdate", doc, page2); } try (PDPage page3 = new PDPage()) { documentWriteToFile("\ud87e\udcde\tdate", doc, page3); } try (PDPage page4 = new PDPage()) { documentWriteToFile("{\"a\":\"b\", \"d\":[\"e\", {\"\ufefff\":null}]}", doc, page4); } ByteArrayOutputStream outByteArrOutStrm = new ByteArrayOutputStream(); byte[] bytes = outByteArrOutStrm .toByteArray(); File tempPDFFile = createTempPDFFileFromBytes(bytes); assertEquals(-999L ,tempPDFFile.length()); List<java.lang.Long> listOfExpectedTimeStamps = Arrays.asList( -999l,-999l,-999l,-999l ); for (int i=0 ;i <listOfExpectedTimeStamps.size(); ++i ) { long timeStampMillisForIthItemInList = System.currentTimeMillis(); Thread.sleep(Math.abs(timeStampMillisForIthItemInList % 2000)); Document dObj = loadPdfAsDomWithoutFixingUpMetadataOrCreationTimes(tempPDFFile); Element elmtElement = dObj.getElementById("page-"+Integer.valueOf(i+1)); Assert.assertNotNull(elmtElement); Node nNodeContentDiv = elmtElement.getElementsByTagName("div").item(0);

}