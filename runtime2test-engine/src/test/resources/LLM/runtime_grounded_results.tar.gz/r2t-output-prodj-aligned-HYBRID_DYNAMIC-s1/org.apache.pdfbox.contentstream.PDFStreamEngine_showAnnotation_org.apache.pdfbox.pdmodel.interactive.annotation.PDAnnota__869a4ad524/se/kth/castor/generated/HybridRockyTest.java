package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFStreamEngineRockyTest {

@Test public final void testShowAnnotation() throws Exception { PDDocument doc = new PDDocBuilder().create(); PDFont font05 = StandardFonts.HELVETICA; PDFont font17 = StandardFonts.TIMES_ROMAN; PDAcroForm acroform06 = new PDAcroForm((PDCosDictionary)doc.getRoot()); String textString07 = ""; float widthOfTextString08 = -1f; boolean isUnderlineOnForThisCharInTheCurrentLine09 = false; int i0 = 0; while ((i0 < this.textList.size()) && (!isLastCharacterWhitespaceOrNewline())) { char c10 = this.textList.charAt(i0++); switch (c10) { case '\r': continue; case '\\': break; default : { appendToBuffer(font05, font17, c10, true, isOverlapping(), isUnderlined()); if ('\n' == c10 || !isWhiteSpaceAfterMeasurement()) { setWidthOfPreviousTextChunkWithoutTrailingSpaces(-1f); resetStateVariablesBeforeNextLine(); } else { increaseSizeAndSetIsFirstNonWhiteSpaceCharPerLineFlag(widthOfTextString08); } } } } StringBuilder builder = new StringBuilder(""); for (int j = startIndex; j <= endIndexExclusive; ++j) { builder.append('*'); } return builder.toString(); }

}