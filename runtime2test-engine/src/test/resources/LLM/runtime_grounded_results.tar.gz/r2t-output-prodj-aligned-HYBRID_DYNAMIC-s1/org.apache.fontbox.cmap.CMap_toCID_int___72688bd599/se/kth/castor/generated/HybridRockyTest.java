package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapRockyTest {

@Test public void testGetCode() throws Exception { assertEquals("Wrong result", 7893, glyphList.toCID('a', 2)); assertNull("Wrong result", glyphList.toCID(-1, 2)); assertNull("Wrong result", glyphList.toCID('\uD8FF', 2)); }

}