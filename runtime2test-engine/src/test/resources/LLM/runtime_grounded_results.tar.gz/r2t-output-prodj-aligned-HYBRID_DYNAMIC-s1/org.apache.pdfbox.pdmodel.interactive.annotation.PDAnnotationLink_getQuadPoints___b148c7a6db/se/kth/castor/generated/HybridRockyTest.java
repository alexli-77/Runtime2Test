package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLinkRockyTest {

@Test public void testGetQuadPointNullReturned(){ assertEquals("Wrong type",null,pdAnnotationTextMarkupStrikeOut.getQuadPoints()); }

}