package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetDictionaray() throws Exception { PDDocument doc = new PDFParser().parse("target/test-classes/" + filename, null).getPDDocument(); Assertions.assertEquals(new Float(-0x80), pdfDoc.getPage(0).findResources().getValueAsFloatArray("/Matrix")[0], EPSILON); assertNotNull(doc.getPages()); }

}