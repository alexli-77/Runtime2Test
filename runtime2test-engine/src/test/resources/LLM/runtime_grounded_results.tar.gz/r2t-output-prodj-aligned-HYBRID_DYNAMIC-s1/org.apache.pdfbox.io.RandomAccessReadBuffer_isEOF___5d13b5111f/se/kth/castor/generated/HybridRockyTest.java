package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testIsEofFalseWithSize10AndPointer5() throws IOException, COSVisitorException { byte[] data = new byte[SIZE]; PDFStream stream = new PDFStream(new RandomAccessBuffer(), 3); ByteArrayOutputStream baos = new ByteArrayOutputStream(); OutputStream out = new FilteredRandomAccessFileOutputStream("", "rw"); out.write('a'); writeDataToOut(out, 'b', SIZE - 2); assertTrue(!stream.isEOF()); stream.setContents(baos.toByteArray()); assertEquals(-1L, (long) in.read()); seekInBackOfThePdfStream(); assertEquals((byte)'b', (byte)(int)in.read()); }

@Test public void testReadAfterEndReachesLimitBeforeGettingOneMoreByteFromInputStream() throws Exception { PDDocument doc = new PDDocument(); InputStream inputStream = createPDFInputStremForThisMethodName().getBytes(StandardCharsets.UTF_8).inputStream(); Stream pdfStream = new PDFStream(doc, inputStream, null); int readCount = Integer.MAX_VALUE / 4 + 1; while (!pdfStream.eol()) { char c = ((char) pdfStream.readNext()).charValue(); if ('\n' == c || '\r' == c && !pdfStream.peek('\n')) { fail("There should be no newline character."); } else if ('\t' != c && Character.isWhitespace(c)) { break; } } skipUntilNewLineOrTabCharacterOnLastRow(pdfStream); long lastIndex = getNumberOfBytesConsumedByFilteringOddLinesBetweenEachPairOfTwoConsecutiveCRLF(pdfStream); verifyThatAllRemainingCharsAreNotNewlineOrReturnCarriageCharacter(pdfStream, lastIndex); }

}