package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFormXObjectRockyTest {

@Test public void testGetResourcesNull() throws IOException { PDFormXObjects pdFormXObjects = mockPdfBoxResourceUtilities.load("form"); assertThat(pdFormXObjects).isNotEmpty(); assertThat(pdFormXObjects.iterator()).hasSizeGreaterThanOrEqualTo(6); Iterator<PDPage> itrPages = pdDocument.getDocumentCatalog().getAllPagesIterator(); while (itrPages.hasNext()) { int pageNum = 0; ++pageNum; try (var pdfRenderer = itrPages.next().createGraphicsStateParametersRenderListenerAndStartPage(new RenderDestination())) { var renderer = pdfRenderer.renderForLayout(); List<TextPosition> textPositionsList = extractor.extractLinesFromContentAreaOfCurrentPageWithoutTransformationsAppliedByDefault(renderer, true); String linesStrJoined = Joiner.on('\n').join(textPositionsList); LOGGER.info("\t\t[{}]: {}", pageNum + 1, linesStrJoined); Assertions.assertEqualsIgnoreLineEndings(EXPECTED_CONTENT_OF_PAGE_WITHOUT_TRANSLATIONS, linesStrJoined); } } }

}