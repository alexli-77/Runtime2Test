package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetXObject() throws Exception { assertEquals("testPdfBox-Template-ArialFontAndImage", doc.getPageByNumber(1).findResources().getXObject(new COSName("img")).getName()); }

}