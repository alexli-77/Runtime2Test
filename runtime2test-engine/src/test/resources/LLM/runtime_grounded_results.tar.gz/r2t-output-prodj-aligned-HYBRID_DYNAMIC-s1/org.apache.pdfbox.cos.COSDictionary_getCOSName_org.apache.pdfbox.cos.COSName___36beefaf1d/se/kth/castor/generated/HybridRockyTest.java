package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSName() throws Exception { assertEquals("Hello World".length(), doc.getDocumentCatalog().getCOSDictionary().size()); PDStream stream = new PDPageContentStream(doc, doc.addNewPage(), AppendMode.OVERWRITE, true, false); java.awt.geom.GeneralPath path = new GeneralPath(); float xy[] = {-4f / 5f, -3f / 5f}; path.moveTo((float) xy[0], (float) xy[1]); xy = new float[]{0, -4f / 5f}; path.lineTo((float)xy [0] , (float)xy [1]); xy = new float[]{4f / 5f, -3f / 5f };path .curveTo((float)(-3*x + y), (float)-3*x+y, (float)(-3*x+y), (-3*x+y)/4, (float)(-3*x+y),(float)-3*x+y );stream.drawShape(path); stream.close(); String s = IOUtils.toString(new FileInputStream("/tmp/" + doc.getName()), StandardCharsets.UTF_8).replace("\r\n",""); System.out.println(s); PDFParser parser = new PDFParser(new ByteArrayInputStream(IOUtils.toByteArray(new FileInputStream("/tmp/" + doc.getName())) )); parser.parse(); Assertions.assertNotNull(parser.getPDDocument().getTrailer().getCOSDictionary().getItem(COSName.ROOT)); Assertions.assertTrue(parser.getPDFDocument().isEncrypted()); Assertions.fail("This should fail with InvalidPasswordException!"); }

}