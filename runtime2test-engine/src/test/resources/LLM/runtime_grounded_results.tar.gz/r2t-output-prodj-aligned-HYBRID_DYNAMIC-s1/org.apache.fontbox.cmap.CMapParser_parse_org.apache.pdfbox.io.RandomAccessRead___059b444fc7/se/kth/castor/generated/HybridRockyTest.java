package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapParserRockyTest {

@Test public void testParse() throws Exception { assertEquals(expectedResult(), parser.parse(new RandomAccessBufferedFileInputStream(input))); failOnAssertions(); }

}