package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFunctionRockyTest {

@Test public void testSetGet() throws IOException { PDShadingType4 t = createDefault(); assertNull("getRange should return null",t.getDecode()); }

}