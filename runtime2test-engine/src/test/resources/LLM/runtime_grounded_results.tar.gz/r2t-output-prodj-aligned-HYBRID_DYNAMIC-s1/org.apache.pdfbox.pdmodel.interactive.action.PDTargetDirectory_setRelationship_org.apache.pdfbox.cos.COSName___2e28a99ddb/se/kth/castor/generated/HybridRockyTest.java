package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDTargetDirectoryRockyTest {

@Test public final void testGetNameAsUnicodeWithInvalidUtfEncodingByteSequencesShouldBeReplacedByQuestionMarkSymbolsAndNotThrowAnError() throws Exception { org.junit.Assert.assertEquals("\uFFFD\uFFFDFoo", this.testee().withValue("#\xff\xfdfOo").asUnicodeString(), "\n" + ArrayUtils.toStringHex(new byte[] {'#', -64, -63}, true)); }

}