package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetItem() throws IOException { COSDictionary dic = new COSDictionary(); assertNull("null should be default.",dic.getItem(new COSName("a"))); dic.setInt("b","B"); assertEquals("value was wrong!", "B", dic.getString("b")); assertTrue("should have been set!", dic.containsValueOfType(COSString.class)); assertNotNull("null should not have been returned!", dic.getValue()); dic.putAll((Map<? extends COSEntry<?>, ? extends Object>) Collections.<Object>singletonList(new Pair<>(COSInteger.ZERO,"C"))); assertFalse("empty dictionaries are equal?", dic.isEmpty()); assertEquals("wrong size!", 1, dic.size()); Iterator iterator = dic.keySet().iterator(); while (iterator.hasNext()) { String nextElement = (String) iterator.next(); assertEquals("Wrong Key found in Dictionary!\nExpected:\nb\nActual:\n"+nextElement+"\n", "b", nextElement ); break;} assertNull("Didnt find expected entry 'c'", dic.getEntry(COSInteger.ONE)); final int numberToAdd = 5; List listWithNumbersFromOneToFive = IntStream . rangeClosed(1,numberToAdd).mapToObj(i -> i + "@").collect(Collectors.toCollection(() -> new ArrayList())); dic.addValuesAndFlushesIfNecessaryForArrayTypes(listWithNumbersFromOneToFive , true); assertThat(dic.entryCount(),is(equalTo(numberToAdd))); Map map = dic.asUnmodifiableMap(); assertThat(map.values().stream().filter(v-> v instanceof COSFloat ).count(), greaterThanOrEqualTo(numberToAdd - 1L )); assertThat(map.values().stream().filter(v-> !(v instanceof COSFloat)).findFirst(), OptionalMatcher::isEmpty); }

}