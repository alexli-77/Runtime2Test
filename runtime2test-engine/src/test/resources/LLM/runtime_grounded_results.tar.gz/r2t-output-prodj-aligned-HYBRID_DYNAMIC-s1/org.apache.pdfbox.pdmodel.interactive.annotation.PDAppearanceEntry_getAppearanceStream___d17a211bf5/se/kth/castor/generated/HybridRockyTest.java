package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceEntryRockyTest {

@Test public void testGetAppearanceStream() throws Exception { Assertions.assertThrown(() -> resourceDictionaryEntry().getAppearanceStream(), IsInstanceOfAssertFactories .instanceOf(java.lang.RuntimeException.class)); }

}