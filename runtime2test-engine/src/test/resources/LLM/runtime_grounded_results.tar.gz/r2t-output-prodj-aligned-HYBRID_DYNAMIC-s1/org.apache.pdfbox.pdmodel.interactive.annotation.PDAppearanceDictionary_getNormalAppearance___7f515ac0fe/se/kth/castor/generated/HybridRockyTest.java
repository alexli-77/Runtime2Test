package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceDictionaryRockyTest {

@Test public void testGetNormalAppearanceReturnedNullWhenNoEntriesPresentInDict() throws Exception { assertThat("testGetNormalAppearanceReturnedNullWhenNoEntiresPresentInDict failed.", annotationStubMarkupMapping.getNormalAppearance(), Matchers.<Map<String, PDAppearance>>nullValue()); }

}