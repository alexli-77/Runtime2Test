package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetProperties() throws Exception { PDMarkedContentDictionary dictionary1 = new PDMarkedContentDictionary(); Assert.assertNull("No properties expected",dictionary1.getProperties()); }

}