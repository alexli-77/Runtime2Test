package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetEmbeddedString() throws Exception { assertEquals("Hello", pdfDoc.getDocument().getPageByIndex(0).getResources().getFontResource(new PDType1Font("Helvetica")).getName()); }

}