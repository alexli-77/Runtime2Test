package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationFreeTextRockyTest {

@Test public void testGetMargin1465320987327() throws IOException, InterruptedException { PdfAnnotation annot = createPdfAnnot("test-resources/annotationHandlerTest/annots/Markup/markupannotwithrectdifferentfromborder.pdf"); Assertions.assertThat(annot.getRect()).isEqualTo(new Rectangle(-4f,-5f)); assertEquals(-4, annot.getBorder()); }

}