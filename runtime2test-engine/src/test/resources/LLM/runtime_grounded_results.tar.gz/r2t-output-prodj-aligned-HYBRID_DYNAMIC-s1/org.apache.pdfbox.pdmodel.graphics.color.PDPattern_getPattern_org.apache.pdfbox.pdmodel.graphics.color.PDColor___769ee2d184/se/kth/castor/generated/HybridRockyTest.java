package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDPatternRockyTest {

@Test public void testGetPattern() throws Exception { PDResources pdResources = mock(PDResources.class); when(pdResources.hasDefaultGray()).thenReturn(true).when(pdResources.getShadingDictionary(anyString())) .thenThrow(new RuntimeException()); assertNull(pdResources.getPattern("/SomeUnknown")); }

}