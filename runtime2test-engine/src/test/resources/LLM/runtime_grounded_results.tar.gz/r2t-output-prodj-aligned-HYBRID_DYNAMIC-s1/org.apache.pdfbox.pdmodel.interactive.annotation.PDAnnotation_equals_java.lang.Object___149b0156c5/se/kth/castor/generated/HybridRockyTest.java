package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testEquals() throws IOException, InterruptedException { PDDocument document1 = new PDDummyDocument("test", ""); PDAcroForm acroform1 = createAcroFormWithAnnotations(document1); assertTrue(acroform1.getField("text").equals((new PDFunctionalMock()).createTextWidget())); document1.close();  }

}