package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testToCosNumerIntgerLisstAllElementsAreOfTypeLong() throws IOException, ParseException { List<String> inputStreamContentAsStrings = Arrays.asList("123456789", "2"); byte[] contentBytesForInputStream = stringCollectionToListByteArray(inputStreamContentAsStrings).toArray(new Byte[stringCollectionToListByteArray(inputStreamContentAsStrings).size()]); InputStream fakeInputStreamThatReturnsDataInChunks = createFakeInputStreamThatOnlyReadsPartiallyAtATimeAndThenThrowsEOFException(contentBytesForInputStream); String sutFileName = "/fakedatafile"; PDDocument doc = mockPdDocWithInputStreamOpenedFromFileSystemUsingMockito(fakeInputStreamThatReturnsDataInChunks, sutFileName); COSDictionary dictionaryUnderTest = (PDPageTree)doc.getPages().getKids().iterator().next(); assertEquals(dictionaryUnderTest.toString(), 2, dictionaryUnderTest.size()); Iterator<? extends COSBase> iteratorOverDictionaryValues = dictionaryUnderTest.valuesIterator(); while (iteratorOverDictionaryValues != null && iteratorOverDictionaryValues.hasNext()) { assertTrue(!(iteratorOverDictionaryValues.next() == null)); } }

}