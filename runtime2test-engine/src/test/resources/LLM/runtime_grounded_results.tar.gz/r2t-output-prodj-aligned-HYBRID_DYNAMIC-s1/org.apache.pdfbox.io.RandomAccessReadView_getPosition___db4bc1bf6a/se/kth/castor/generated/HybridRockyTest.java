package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public void testGetPosition001(){ assertEquals(new Long(2), new PdfObjectInputStream((byte[])null).getPosition()); }

@Test public void testGetPosition002(){ assertEquals(new Long(2), inStream.getPosition()); }

@Test public void testGetPosition003(){ assertEquals(new Long(2659876l), outStream.getPosition()); }

}