package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapRockyTest {

@Test public void testFromChar() throws Exception { assertEquals("\\u0e2a", pdfDocEncoding.toUnicode((char) 7)); assertNull(pdfDocEncoding.toUnicode(' ')); assertNotSame("\ufffd\ufffd", pdfDocEncoding.toUnicode('\ud801')); // U+D801 not mapped in PDFDocEncodings table but still valid UTF-16 string - see http://www.fileformat.info/info/unicode/char/d801/index.htm
for (final String str : new String[]{"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!\"§$%&/( )?*+~`´^°<>{}|€#,.;:-="}) { final Character c = str.charAt(str.indexOf('.') + 1); assertTrue(c != '.'); assertEquals("'" + c + "' should map correctly.", str.substring(0, str.lastIndexOf(".")), pdfDocEncoding.fromChar(c).toString()); } failOnIllegalInput(); try { pdfDocEncoding.toUnicode(-1); Assertions.fail("Should have thrown exception"); } catch (@SuppressWarnings({"unused", "null" }) IllegalArgumentException ex) {} try { pdfDocEncoding.toUnicode(Character.MAX_VALUE + 1); Assertions.fail("Should have thrown exception"); } catch (@SuppressWarnings({"unused", "null" }) IllegalArgumentException ex) {} }

}