package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetNameAsString() throws Exception { COSDocument doc = new COSDocument(); PDStream stream1 = createPDStreamForFile("test-document.txt"); assertNotNull(stream1); COSInputStream inputStream = stream1.getPartiallyFilledStream().createRawImage(); PDFParser parser = new PDFParser((RandomAccessRead)inputStream , false ); parser .parse(); COSReader reader = parser .getSource(); document = reader.readAllPages(); assertEquals("This should have been 'PDF'.", "PDF".toLowerCase(), document.getTrailer().getDictionaryObject(COSName.ROOT).asDictioaryEntryMap() .getOrDefault(new COSSimpleKey(COSName.TYPE),null ) .getValue() .toString()); String val = document.getTrailer().getDictionaryObject(COSName.INFO).asDictioaryEntryMap() .getOrDefault(new COSSimpleKey(COSName.CREATOR),"").getValue().asString().trim(); assertTrue("Expected 'Creator' but got '" + val+ "' instead.", val != null && !val.isEmpty()); val = document.getTrailer().getDictionaryObject(COSName.INFO).asDictioaryEntryMap() .getOrDefault(new COSSimpleKey(COSName.MODIFICATION_DATE),"" ).getValue().asDate().toString(); System.out.println(val); assertFalse("Expected non empty modification date.", val==null || val.length()<20); }

}