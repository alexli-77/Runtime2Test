package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessInputStreamRockyTest {

@Test public void testReadByteArrayIntIntWithZeroLengthReturnsSameValueAsInput () throws IOException { assertEquals(-1, pdfStreamReaderUnderTest.read(new byte[]{}, 0, 0)); verifyNoMoreInteractions(randomAccessFileMockedForThisTestOnly); reset(randomAccessFileMockedForThisTestOnly); }

@Test public void testReadByteArrayIntIntWhenBufferIsSmallerThanSizeOfThePdfDictionaryKeywordAndThatPartiallyMatchesInTheCurrentBlockThenCopiesOverToOutput (@Capturing RandomAccessInputStream randomAccessInputStreamStubbedDueToLackOfKnowledgeOnHowItWorksButItsNotUsedAnyway) throws IOException { final InputStream mockInputStream = createNiceMock(InputStream.class); expect(mockInputStream.available()).andAnswer(() -> available).anyTimes().once(); replayAll(); whenNew(PDFParser.class).withArguments((PDDocument) anyObject(), sameInstance(stream), false).thenCallRealMethod(); stream = new PushBackInputStream(new ByteArrayInputStream(SAMPLE_DATA), BLOCKSIZE + 5 /* some extra data */ ); PDFTextStripper stripper = new PDFTextStripperByArea (); stripper.setStartPage(STARTPAGE); stripper.setTextExtractionStrategy(new SimpleTextExtractionStrategy()); String extractedString = stripper.getText(document); Assertions.assertTrue(extractedString.contains("Hello World")); }

}