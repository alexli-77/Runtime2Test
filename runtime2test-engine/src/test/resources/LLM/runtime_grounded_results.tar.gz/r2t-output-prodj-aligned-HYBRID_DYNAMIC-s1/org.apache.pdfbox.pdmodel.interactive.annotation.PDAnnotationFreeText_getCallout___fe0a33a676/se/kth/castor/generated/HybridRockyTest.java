package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationFreeTextRockyTest {

@Test public void testGetSetCallOutWithTwoCoordsOnly(){ PDFont font = PDType0Font.load(doc, new File("src/test/resources/fonts/Helvetica-BoldOblique.afm"), false); doc.setDefaultPageSize(new PageLayoutPosition()); page = doc.createPage(); annotationDictionary = createFreeTextAnnotationDictioanry(page ,font ); assertNull(annotationDictionary.getCallout(), "The value should be empty"); }

}