package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapRockyTest {

@Test public void testToCID() throws Exception { assertEquals("Wrong result", 798, fontEncodingInfo.toCID('e', 'n')); }

}