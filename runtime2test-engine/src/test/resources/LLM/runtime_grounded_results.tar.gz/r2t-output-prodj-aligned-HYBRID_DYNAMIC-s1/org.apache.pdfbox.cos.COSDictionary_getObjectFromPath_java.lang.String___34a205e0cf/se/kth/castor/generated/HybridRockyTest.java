package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetObjectFromPath() throws Exception { COSDocument doc = new COSLoader().loadPDF(); PDPage page1 = new PDFParser(doc).parse().getPages().get(0); assertNotNull(page1.findResources()); COSBasedSecurityHandler securityHandler = SecurityHandlersManagerFactory.INSTANCE.newInstanceForTypeAndDoc(CryptFilterTypesEnum.STANDARD, doc); COSDictionary rootDict = securityHandler != null ? securityHandler.decryptDictionary(doc.getTrailer()) : doc.getTrailer(); String keyToFind = "/Root"; Object foundObj = rootDict.getValueAsStringOrStreamOfNameOrDecodedBytes(keyToFind); assertEquals("/Pages", foundObj); }

}