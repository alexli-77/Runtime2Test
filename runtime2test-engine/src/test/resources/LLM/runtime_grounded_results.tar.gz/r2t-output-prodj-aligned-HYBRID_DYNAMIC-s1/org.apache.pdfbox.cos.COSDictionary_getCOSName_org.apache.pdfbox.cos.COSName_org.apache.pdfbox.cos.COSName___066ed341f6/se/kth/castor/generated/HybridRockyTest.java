package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSName() throws Exception { assertEquals("Hello World!".length(), docMetadataDic.size()); assertNotNull(docMetadataDic.getItem(new COSName("Title"))); assertTrue((docMetadataDic).containsKey(new COSSimpleEntry<>(new COSName("Creator"), new PDCosString("test")).getCosKey())); assertFalse((docMetadataDic).containsKey(new COSSimpleEntry<>(new COSArray()).getCosKey())); assertThatCode(() -> metadataXformDocInfoToPdfA.transform(metadataStreamObj)) .doesNotThrowAnyException(); }

}