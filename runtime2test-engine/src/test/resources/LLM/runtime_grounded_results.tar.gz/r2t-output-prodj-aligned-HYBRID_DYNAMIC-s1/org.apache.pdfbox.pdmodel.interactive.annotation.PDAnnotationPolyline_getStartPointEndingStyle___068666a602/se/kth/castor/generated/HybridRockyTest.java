package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public void testGetStartPointEndingStyle() throws Exception { PDDocument doc = new PDDocument(); PDAcroForm form = new PDAcroForm(doc); assertEquals("None", form.getField("name").getStartPointEndingStyle()); assertNull(form.getField("name").getEndPointEndingStyle()); doc.close(); }

}