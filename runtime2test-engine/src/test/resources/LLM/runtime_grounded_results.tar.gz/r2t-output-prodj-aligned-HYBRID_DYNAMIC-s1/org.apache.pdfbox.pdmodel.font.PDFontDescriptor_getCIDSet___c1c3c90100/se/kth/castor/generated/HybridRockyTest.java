package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetCIDSet2() throws Exception { PDType1Font font = new PDType0Font(); Assertions.assertNull(font.getCIDToGID()); }

}