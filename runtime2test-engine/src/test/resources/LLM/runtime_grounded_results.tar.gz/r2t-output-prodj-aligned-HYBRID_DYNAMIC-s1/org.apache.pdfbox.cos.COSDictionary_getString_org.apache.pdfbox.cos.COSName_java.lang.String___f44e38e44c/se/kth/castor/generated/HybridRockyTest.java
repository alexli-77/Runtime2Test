package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCosFloat() throws IOException { assertEquals(-0.1f, this.dictionary.getFloat("Foo", -2), EPSILON); }

}