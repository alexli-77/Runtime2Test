package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetSetStartArrowHead() throws IOException { PDPage page = new PDPage(); document.addPage(page); annotation = createDefaultAnnotation(); assertEquals("None", annotation.getStartArrowHead()); String arrowheadValue = "Open"; annotation.setStartArrowHead(arrowheadValue); assertEquals(arrowheadValue, annotation.getStartArrowHead()); try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) { annotatedPdfDocument.saveAsStream(outputStream); byte[] bytes = outputStream .toByteArray(); PDFParser parser = new PDFParser(new RandomAccessBuffer(bytes)); parser.parse(); Assertions.assertThatCode(() -> validateAnnotations()).doesNotThrowAnyException(); } catch (IOException e) { failWithMessage("%s exception thrown while parsing pdf.", e.getMessage()); } finally { IOUtils.closeQuietly(annotatedPdfDocument); } }

}