package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceContentStreamRockyTest {

@Test public void testSetNonStrokeColorNullPattern() throws Exception { try (PDFont font = new PDFont()) { Color c = new Color(.6f,.2f,.3f).convertToRGBFormat(); assertTrue("Setting a color should succeed", contentStream.setNonStrokingColor((float[])c)); checkLastOperatorEquals("/DeviceRGB rg"); } }

}