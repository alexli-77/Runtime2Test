package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetStartPointEndingStyle1() throws IOException { try (InputStream inputStream = new FileInputStream("target/test-data/" + namePrefix + "input_" + methodName + ".pdf")) { PDDocument document = Loader.loadPDF(inputStream); List<PDPage> pages = document.getPages(); assertEquals(pages.toString(), 5469783L, pages.size()); String expectedValue = "butt"; checkLineEndingsForAllAnnotationsInPageRangeOfType(document, "annotations", "line annotation with endpoints that are not connected to a rectangle or ellipse", page -> ArrayUtils.contains(page.findFreeTextByContents("%E2%8A%B7"), "%E2%8A%B7") ? "" : expectedValue); } finally { IOUtils.closeQuietly((Closeable) inputStream); } }

}