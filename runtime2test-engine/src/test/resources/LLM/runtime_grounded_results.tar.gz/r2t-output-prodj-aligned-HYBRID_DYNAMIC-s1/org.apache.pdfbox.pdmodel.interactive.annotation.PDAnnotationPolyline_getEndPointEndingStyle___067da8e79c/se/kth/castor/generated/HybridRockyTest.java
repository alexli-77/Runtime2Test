package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public void testGetStartAndEndPointsWithNoValuesSet() throws Exception { PDPage page = new PDPixelMap(); AnnotationUtils.setRectangleForQuadpoints(page, annotationDictionary); assertEquals("Should be none", "None", annot.getLeader()); assertTrue("start and endpoint should not have a leader length set.", !annot.hasCustomDistanceToNextEndpoint()); String startLengthStr = annot.getStartPointEndingStyle(); String endLengthStr = annot.getEndPointEndingStyle(); assertNotNull("There is no value of starting or ending leader length string returned!", startLengthStr); assertFalse("The default value 'None' shouldn't appear as an actual setting here!", startLengthStr.equalsIgnoreCase("none")); assertNotNull("There is no value of starting or ending leader length string returned!", endLengthStr); assertFalse("The default value 'None' shouldn't appear as an actual setting here!", endLengthStr.equalsIgnoreCase("none")); assertEquals("Default value should match that provided by constructor...", "", annot.toString(), true); }

}