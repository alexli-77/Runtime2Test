package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetCapHeight() throws Exception { assertEquals(-1f, fd.getCapHeight(), .005f); dic.setItem("CapHeight", new COSInteger(-1)); assertEquals(.7683939f, fd.getCapHeight(), .005f); }

}