package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDShadingRockyTest {

@Test public final void testSetFunction() throws IOException { InputStream input1 = this .getClass ( ) .getResourceAsStream ("tint-function-02.pf"); PDColorSpace cs1 = pdfDoc.loadPDModelFromFile("PdfBox", "colorSpaces/" + "iccbasedrgb".toLowerCase()); List<String> names1 = Arrays.asList("GrayCS","RGBCS","CMYKCS","SeparationCS"); assertThat(cs1).isNotNull(); int index = 0; Iterator iter = names1.iterator (); while (iter.hasNext()) { String name = ((String) iter.next()).trim(); if (!name.equalsIgnoreCase("/Default")) { PDFunction func = FunctionFactory.createSpecShadingFunction((PDFunctionType3) pdmodel ,input1,"ICCBased",new ArrayList(),null,(float[]) null ); CSDeviceInfo deviceInfo = new CSDeviceInfo(); DeviceColorSpace devColourSpace = cs1.parseDevicespace(deviceInfo); ColorSpace colourSpace = devColourSpace.getJavaxColorspace(); float[] rgb = Colourspaces.convertToRgb(colourSpace,func.eval((double)(index++)/(names1.size()))[0]); Assertions.assertEquals(cs1.getName ()+": "+rgb [0],"0.576471 ",Assertions::roundedFloatComparisonWithDelta); } else break; } }

}