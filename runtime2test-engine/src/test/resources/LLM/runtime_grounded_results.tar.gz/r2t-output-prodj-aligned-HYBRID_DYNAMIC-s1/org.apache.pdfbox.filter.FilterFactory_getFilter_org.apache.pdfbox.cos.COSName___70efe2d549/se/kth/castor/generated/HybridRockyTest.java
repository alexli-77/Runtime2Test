package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FilterFactoryRockyTest {

@Test public void testGetFilter() throws Exception { assertThat((new FilterFactory()).getFilter(org.apache.pdfbox.cos.COSName.DCT)).isInstanceOf(org.apache.pdfbox.filter.DecodeStream.class); }

}