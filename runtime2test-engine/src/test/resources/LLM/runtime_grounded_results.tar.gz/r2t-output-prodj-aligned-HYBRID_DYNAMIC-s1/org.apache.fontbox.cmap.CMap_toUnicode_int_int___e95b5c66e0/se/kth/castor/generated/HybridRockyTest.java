package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapRockyTest {

@Test public void testCharMap() throws Exception { assertEquals("", uniCodeMapper.toUnicode((char) 0)); }

}