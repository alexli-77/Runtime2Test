package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSStream() throws Exception { assertNotEquals("Should have gotten back stream.",null,pdDocumentCatalog.getCOSStream(new PDStream())); pdDocumentCatalog.setItem(PDPageTree.class,"Pages"); assertNull("There should be no pages.",pdDocumentCatalog.getCOSStream()); }

}