package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetRichContentsNull() throws IOException, COSVisitorException { PDFormXObject xobject = new PDFormXObject(new COSInputStream("".getBytes())); assertThat((xobject).getRichContents()).isEqualTo(null); }

@Test public void testGetRichContentsEmpty() throws Exception { String contents = "1234567890"; InputStream input = new ByteArrayInputStream(contents.getBytes()); byte[] bytes = IOUtils.toByteArray(input); PDFont font = PDType1Font.HELVETICA; float widthOfOneChar = font.getWidthPoint('a', 1f); int numberCharsInLine = Math.round(widthOfOneChar / 4); StringBuilder sb = new StringBuilder(); for (int i = 0; i < numberCharsInLine + 2; ++i) { sb.append("abc"); } String lineWithSpaces = sb.toString(); try (PDDocument doc = new PDDocument()) { doc.addPage(createBlankPDFDocForTests(doc)); List<PDAnnotation> annotationsList = createAnnotationsOnTheFirstPageOfADocAndReturnThemAsArrayList(lineWithSpaces, doc); Iterator<? extends COSBasedObject> itr = annotationsList.iterator(); while (itr.hasNext()) { pdform.setResources(itr.next().getCOSDictionary(), false); break; } pdfRenderer.renderPage(pdform, pageSize); BufferedImage image = rendererContext.getBufferedImage(); Graphics graphics = image.getGraphics(); Font fnt = font.getawtFont(); Rectangle rect = new Rectangle(0, 0, 50, 50); AffineTransform at = new AffineTransform(); at.translate(-rect.x - rect.height, -rect.y); at.rotate(Math.PI / 2d); affineTransformationMatrix.transformRect(at); graphics.drawGlyphVector(font.getGlyphVector(graphics .getFontRenderContext(), sb.toString()), at , new Point2D.Float(sb.length()*numberCharsInLine-1, 0), sb.length()*numberCharsInLine+1); ImageIO.write(image,"png",FileUtilities

}