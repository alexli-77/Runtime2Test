package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetString() throws Exception { PDDocument doc = new PDDummy1(); PDAcroForm acroform = new PDCosDocHelper().createAcroFormForPDFBoxWithoutResources("acro", "42"); assertEquals("Expected result was incorrect.", "", acroform.getString(new COSSimpleArray<>(doc), "foo")); }

}