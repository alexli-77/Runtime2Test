package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetCaptionVertialOffset() throws Exception { assertEquals(-32, pdfBoxPageTextStripper.getTextLayoutResultantPosition(), EPSILON ); }

}