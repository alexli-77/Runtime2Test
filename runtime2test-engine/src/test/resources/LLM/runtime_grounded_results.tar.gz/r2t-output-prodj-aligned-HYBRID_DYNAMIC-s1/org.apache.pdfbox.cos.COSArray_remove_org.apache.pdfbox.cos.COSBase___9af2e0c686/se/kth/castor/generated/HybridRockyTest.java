package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testRemove() throws IOException { COSArray cosarray1 = new COSArray(); addObjectsToCosArrayAndAssertOrderedEquals(new Object[]{ "a", 3 }, cosarray1 ); assertTrue("expected true when removing first item in list with one item", cosarray1 .remove(0)); assertFalse("Expected false since there is no more items on the array.", cosarray1 .isEmpty()); assertEquals("There should be only two elements left after removal of last item but found ",2 ,cosarray1 .toList().size()); List<String> expectedResultAfterRemovalOfFirstItemFromCosArrayWithOneItem = Arrays.asList(( String[] ) {"a","b"}); Assertions.assertThat(cosarray1 ).isEqualToComparingFieldByFieldRecursively(createNewCosArrayFromGivenValuesForTests(expectedResultAfterRemovalOfFirstItemFromCosArrayWithOneItem)); // Remove second Item and check that it removes correctly by checking size. assertTrue ("expected True as we have removed the last value", cosarray1 .remove(0)); assertEquals ("there shouldn't exist any values now so length should be zero or empty but found ",0 ,cosarray1 .toList().size()); }

}