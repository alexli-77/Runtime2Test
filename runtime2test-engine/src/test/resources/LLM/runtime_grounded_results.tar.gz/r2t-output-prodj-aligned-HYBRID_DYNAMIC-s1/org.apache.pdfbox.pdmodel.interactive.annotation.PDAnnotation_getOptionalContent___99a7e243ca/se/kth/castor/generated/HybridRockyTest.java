package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetOptionalContentsNoGroupOrMembershipDictionary() throws IOException, COSLoadException { PDAnnotationMarkup pda1 = new PDAnnotationText(); assertNull("Should be no Optional Content", pda1.getOptionalContent()); }

}