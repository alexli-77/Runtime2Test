package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetPageNullIfNotAvailable() throws IOException, InterruptedException { PDAnnotationWidget widget = createSample(); Assertions.assertThat((widget).getPage()).isNull(); }

}