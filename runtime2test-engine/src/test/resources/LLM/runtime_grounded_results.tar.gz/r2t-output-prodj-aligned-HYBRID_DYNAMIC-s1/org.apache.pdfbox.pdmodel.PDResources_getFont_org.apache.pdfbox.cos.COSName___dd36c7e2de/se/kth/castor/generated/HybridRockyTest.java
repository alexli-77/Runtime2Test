package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetFont() throws Exception { assertThat("Unexpected value.", page.getResources().getFont(new COSName("TimesNewRomanPS-Bold")), isA(PDType1NF.class)); }

}