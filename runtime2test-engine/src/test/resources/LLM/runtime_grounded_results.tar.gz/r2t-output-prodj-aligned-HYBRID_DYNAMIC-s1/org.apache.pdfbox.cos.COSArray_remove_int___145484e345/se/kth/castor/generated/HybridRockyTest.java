package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testRemove() throws IOException { PDDocument doc = new PDDummy(); COSArray cosArray = (COSArray)doc.getPage(0).getResources().getResourceCache().put("Font", null); COSBase base = addToCosArryyAndGetObjectAtIndexZero(cosArray, 3L); assertEquals((Long)base.asNumber(), Long.valueOf(3)); base = addToCosArryyAndGetObjectAtIndexOne(cosArray, -1f); assertTrue(Float.isNaN( ((PDAbstractTransformationMatrix)base).getValue())); base = addToCosArryyAndGetObjectAtIndexTwo(cosArray, true); assertFalse( ((PDBoolean)base).toBoolean()); }

}