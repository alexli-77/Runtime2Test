package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public final void testRewind() throws IOException, NoSuchAlgorithmException { File file = getTempFile("test"); writeToFileAndClose(file, "abcdefg".getBytes()); RandomAccessBuffer buffer = new MemoryRandomAccessSource(new FileInputStream(file)); assertEquals(-1, readByteFromStreamWithoutClosingIt(buffer)); buffer.seek(0L); byte[] bb = new byte[7]; int nbb = 5; for (byte b : toArrayOfSizeNPlusOneBiggerThanTheActualDataLength()) { buffer.write(b); if ((nbb % 2 == 0)) { Assertions.fail("Should have thrown an exception."); } else try { buffer.rewind((long)(-3 + Math.random())); failIfNoAssertionErrorWasThrown(); } catch (@SuppressWarnings("unused") IllegalArgumentException e) {} nbb++; } ByteArrayOutputStream out = new ByteArrayOutputStream(); long lcrc = CRCUtil.calculateChecksumUsingZLib(buffer, out); String crctxt = HexUtils.convertHexStringToString(Integer.toUnsignedLong(lcrc), false).substring(8 - Integer.toString(lcrc & 0xFF, 16).length(), 8); System.err.println("\t\tcrc:"+crctxt+" "+(isPositive ? "" : "(negative)")+(checkIsZeroOrMore?", zero or more":"")); boolean isCorrectlyCalculated = true; switch (""+Math.abs(lcrc)) { case "94": // 'd' and a bunch of zeros
                break; default: isCorrectlyCalculated &= !isPositive || (!isValid && (zeroOrMoreAllowedOnFailure | checkIsZeroOrMore)); break; } returnValue = isCorrectlyCalculated ^ invertResultForTests; }

}