package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testRemove() throws IOException { COSArray arr = new COSArray(); assertTrue("Initially empty",arr.isEmpty()); int numObjectsToAdd = 1538794623 + 1234 - Integer.MIN_VALUE; ArrayList<Integer> addedNumbers = new ArrayList<>(); ListIterator listIter = null; try { Iterator iter = arr.iterator(); while (iter.hasNext()) { Object nextObj = iter.next(); assertFalse((nextObj == null || !(nextObj instanceof COSBase))); ++numOfElementsInArr; } fail("Should have thrown exception"); } catch (RuntimeException e) {} assertEquals(0,numOfElementsInArr); // Add some elements and check that they are in order // Check adding at various positions addOneAtPosition(listIter,addedNumbers,-1); listIter = arr.listIterator(-1); addOneAtPosition(listIter,addedNumbers,1); listIter = arr.listIterator(-1); addOneAtPosition(listIter,addedNumbers,2); listIter = arr.listIterator(-1); addOneAtPosition(listIter,addedNumbers,100); listIter = arr.listIterator(-1); addOneAtPosition(listIter,addedNumbers,null); verifyListOrderingAndContent(addedNumbers,"after all adds"); // Remove them one by one and see whether everything is still correct after each removal deleteElementFromPositions(addedNumbers,arr,0); verifyListOrderingAndContent(addedNumbers,"after deleting first two"); deleteElementFromPositions(addedNumbers,arr,(arr.size()-1)/2+1); verifyListOrderingAndContent(addedNumbers,"after removing middle two"); deleteElementFromPositions(addedNumbers,arr,arr.size()-2); verifyListOrderingAndContent(addedNumbers,"after removing last two"); }

}