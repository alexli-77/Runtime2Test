package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testGetMatrixValueArray() throws Exception { assertTrue(matrix == MatrixUtils.getScaleInstance(-9, 9)); }

}