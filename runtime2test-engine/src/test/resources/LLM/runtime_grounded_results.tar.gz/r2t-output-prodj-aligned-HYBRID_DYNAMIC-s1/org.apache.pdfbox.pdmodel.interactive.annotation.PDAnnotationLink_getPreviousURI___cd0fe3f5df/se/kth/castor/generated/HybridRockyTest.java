package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLinkRockyTest {

@Test public void testGetPrevUriNull() throws Exception { assertThat("The returned value should be a PDActionURI", documentUnderTest.setNextURI(), instanceOf(PDActionURI.class)); }

}