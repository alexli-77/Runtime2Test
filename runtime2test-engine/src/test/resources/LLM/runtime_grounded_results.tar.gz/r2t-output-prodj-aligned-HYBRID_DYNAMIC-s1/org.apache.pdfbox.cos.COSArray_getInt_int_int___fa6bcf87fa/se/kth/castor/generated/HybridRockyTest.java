package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testGetInt() throws Exception { COSArray cosarray = new COSArray(); assertEquals(-2567489, cosarray.<Integer>getInt(0,-2567489)); assertEquals(-2567489, cosarray.<Integer>getInt(1,-2567489)); }

}