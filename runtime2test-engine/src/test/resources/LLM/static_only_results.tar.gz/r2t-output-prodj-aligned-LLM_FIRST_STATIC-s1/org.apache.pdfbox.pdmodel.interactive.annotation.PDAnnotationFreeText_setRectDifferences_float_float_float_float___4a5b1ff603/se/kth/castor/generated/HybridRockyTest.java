package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationFreeTextRockyTest {

@Test public void testSetMargin() throws Exception { annotationDictionary.setRectDifferences(-10f,-25f,368974f, -2221f ); assertEquals("-10",annotationDictionary.getCosObject().getDictionaryObject(org.apache.pdfbox.cos.COSName.L).toString()); }

}