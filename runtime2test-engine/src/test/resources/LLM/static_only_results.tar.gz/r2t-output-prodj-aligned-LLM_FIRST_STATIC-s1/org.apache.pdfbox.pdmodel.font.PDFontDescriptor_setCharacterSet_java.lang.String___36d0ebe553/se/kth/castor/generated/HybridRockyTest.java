package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testGetEncoding() throws Exception { assertEquals("WinAnsi", ttfFont.getBaseFont()); }

}