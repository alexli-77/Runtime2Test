package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolygonRockyTest {

@Test public void testGetSetVertices2D(){ assertEquals("1", new Float(5).toString()); }

}