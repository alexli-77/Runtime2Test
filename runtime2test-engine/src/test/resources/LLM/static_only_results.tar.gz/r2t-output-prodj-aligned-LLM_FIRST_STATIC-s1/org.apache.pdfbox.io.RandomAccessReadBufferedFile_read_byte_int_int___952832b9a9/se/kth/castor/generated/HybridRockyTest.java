package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferedFileRockyTest {

@Test public void testRead() throws IOException { RandomAccessInputStream rai = new BufferedRandomAccessFile("test", "r"); byte[] buf = new byte[256]; for (long i = 0; i <= PAGE_SIZE + 3L * BUFFER_LENGTH / 4; ++i) { assertEquals((int)(BUFFER_LENGTH >> 1), rai.read(buf)); String s = new String(buf).trim().replaceAll("\n","").toLowerCase(); System.out.println(String.format("%d:%s%n", i, s)); Assertions.assertTrue(ArrayUtils.isSameContents(new char[]{ 'a', 'A' }, s.substring(0, 2).toCharArray())); Assertions.assertTrue(ArrayUtils.isSameContents(' ', s.charAt(2))); Assertions.assertTrue(ArrayUtils.isSameContents(new char[]{ 'B', 'C' }, s.substring(3, 5).toCharArray())); Assertions.assertTrue(ArrayUtils.isSameContents(new char[]{ '\t','\u0089'}, s.substring(7, 9).toCharArray()), () -> ArrayUtils.toString(s.subSequence(7, 9)) ); Assertions.assertTrue(ArrayUtils.isSameContents('\uFFFF', s.charAt(9)), ()-> Integer.toHexString(s.codePointAt(9))); Assertions.assertFalse(Character.isISOControl(s.charAt(10))); Assertions.assertNotNull(s.matches(".*\\p{IsInPrivateUse}.*")); } rai.close(); }

}