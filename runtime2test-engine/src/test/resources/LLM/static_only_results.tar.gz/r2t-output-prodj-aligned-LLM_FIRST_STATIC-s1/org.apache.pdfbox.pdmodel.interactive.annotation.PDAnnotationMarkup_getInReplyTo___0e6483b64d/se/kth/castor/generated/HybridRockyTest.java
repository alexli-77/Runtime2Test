package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetInReplyToNullCase() throws Exception { PDTextAnnotation annot1 = new PDTextAnnotation(); assertThat("Expecting no IRT",annot1.getInReplyTo(),is((nullValue()))); }

}