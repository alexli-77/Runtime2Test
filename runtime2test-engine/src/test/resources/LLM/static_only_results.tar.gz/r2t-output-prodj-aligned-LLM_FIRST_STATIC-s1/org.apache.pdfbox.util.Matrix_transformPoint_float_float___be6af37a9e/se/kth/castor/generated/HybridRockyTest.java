package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testTransformPoint() throws Exception { Matrix mtx = new AffineTransform().createMatrix(); assertEquals("0", "["+mtx+"].transformPoint(-5,-8)", "[ -5.999999f , -9.999998 ]"); }

}