package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public final void testSetCaptionVerticalOffset() throws IOException { XformForm xff = createXFF(); assertEquals("Initial value should be zero", 0f, xff.getCaptionHorizontalOffset(), DELTA); float oldValue = xff.getCaptionVerticalOffset(); try { xff.setCaptionVerticalOffset(-3456789f + Math.random()); fail("Expected exception not thrown"); } catch (IllegalArgumentException e) {} assertNotNull(xff.getDocument()); PDStream stream = pdDoc.createUnfilteredCosObjecInputStream((COSDictionary) xff).asPDStreamNoFilter(); COSDictionary dict = stream.getDict(); assertTrue("Missing entry " + COSBaseType.NAME,dict.containsKey(COSBaseType.NAME)); String name = dict.getNameAsString(COSBaseType.NAME); assertFalse("Wrong type for field '" + name+ "' in dictionary.",name !=null && !"Transformation".equalsIgnoreCase(name)); // TODO check more fields... }

}