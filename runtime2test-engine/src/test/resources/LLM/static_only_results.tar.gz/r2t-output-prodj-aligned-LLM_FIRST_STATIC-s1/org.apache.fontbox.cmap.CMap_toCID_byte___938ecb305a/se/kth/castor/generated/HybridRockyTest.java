package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapRockyTest {

@Test public void testGetCode() throws IOException { Assertions.assertEquals(-123456789, csi.toCID("abc".getBytes())); }

}