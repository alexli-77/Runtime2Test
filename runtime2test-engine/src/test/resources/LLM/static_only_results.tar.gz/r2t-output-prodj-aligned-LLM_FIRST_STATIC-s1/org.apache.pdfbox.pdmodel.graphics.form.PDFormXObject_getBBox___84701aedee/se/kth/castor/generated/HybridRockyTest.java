package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFormXObjectRockyTest {

@Test public void testGetBBoxWithNoBoundingBoxSetReturnNull(){ FormXObject xobject = createForm(); assertThat(xobject).isNotNull(); assertThat(xobject.getBBox()).isEmpty(); }

}