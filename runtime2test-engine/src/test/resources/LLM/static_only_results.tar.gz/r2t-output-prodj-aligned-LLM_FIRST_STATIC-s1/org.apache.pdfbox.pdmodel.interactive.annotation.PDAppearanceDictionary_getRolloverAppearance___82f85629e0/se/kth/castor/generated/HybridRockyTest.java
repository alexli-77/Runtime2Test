package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceDictionaryRockyTest {

@Test public void testGetROnlyOneElement() throws IOException, InterruptedException { PDAnnotationFileAttachment fileattachment = new PDAnnotationFileAttachement(""); assertNull(fileattachment.getNormalAppearance()); assertNotNull(fileattachment.getRolloverAppearance().values().iterator().next()); assertEquals(1, fileattachment.getRolloverAppearance().size()); }

}