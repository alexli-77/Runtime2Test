package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FlateFilterDecoderStreamRockyTest {

@Test public void testReadOneByteAtATime() throws Exception { PdfEncryptionInputStream input = new PdfEncryptionInputStream(new ByteArrayInputStream("abc".getBytes()), null); assertEquals('a', input.read()); assertEquals((byte)'b',input.read()); assertEquals(-1,input.read()); }

}