package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testRemove() throws Exception { COSArray cosArray1 = new COSArray(); Assertions.assertFalse((Boolean)(new Boolean(cosArray1.contains(null)))).as("Should be false"); COSInteger cis34256 = null; try { assertThatThrownBy(() -> cosArray1.add(cis34256)).hasMessageContainingAll("NullPointerException", "Parameter must not be null").isInstanceOfAny(IllegalArgumentException.class, NullPointerException.class); failIfCosObjIsUnmodifiableOrFrozen(cis34256); } catch (RuntimeException e){ throw new RuntimeException(e); }}

}