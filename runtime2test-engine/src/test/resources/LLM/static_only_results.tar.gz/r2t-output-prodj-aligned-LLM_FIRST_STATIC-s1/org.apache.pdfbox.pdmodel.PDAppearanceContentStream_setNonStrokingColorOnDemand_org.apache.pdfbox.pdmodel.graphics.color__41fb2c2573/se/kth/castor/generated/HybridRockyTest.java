package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceContentStreamRockyTest {

@Test public void testSetNonStrokingColorOnDemandNull() throws Exception { assertFalse("Should be able to handle a null", pdPageContents.setNonStrokingColorOnDemand((PDColor)null)); Assert.assertEquals(-1L, contentsLength(), "No change expected"); }

}