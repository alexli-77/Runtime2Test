package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetPageWithoutAPageRefShouldReturnNull() throws Exception { PDAnnotationWidget widget = createNewInstance(); assertThat("The returned value should be null", widget.getPage(), is((org.apache.pdfbox.pdmodel.PDPage)null)); }

}