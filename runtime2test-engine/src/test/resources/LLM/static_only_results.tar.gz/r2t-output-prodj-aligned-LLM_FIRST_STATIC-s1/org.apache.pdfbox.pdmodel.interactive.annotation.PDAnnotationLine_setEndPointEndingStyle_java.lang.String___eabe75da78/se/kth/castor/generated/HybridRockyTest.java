package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testSetStartAndEndPointsWithStyles() throws Exception { PDPage page = this.testResultsDir.createPage(PDRectangle.A4); List<PDAnnot> annotationsBeforeAdditionOfThisOne = Arrays.asList((PDAnnotation[])page.getAnnotations()); annotationToBeCreatedOnPageForTests("", ""); assertThat(annotationsBeforeAdditionOfThisOne).containsExactlyElementsIn(page.getAnnotations()).inOrder(); assertEquals("/Contents [(\n" + "(0 597 m\r\nxc -yc l S /I3 gs BT \\\\/F1 Tj ET)\r\n] >>\r\nendobj\r\ndict begin\r\n<< /Subtype /Link>> annot endobj", annotation.toString(), ignoreNewLinesBetweenWordsCompareStrategy())); String expectedContentStreamDataAfterSettingUpValues = "/Contents [\n(\n(687 570 m\rxc -yc l S /I1 gs BT \\(/Courier-Oblique Italique E)/FontType 0 Tf ET)\n]\n>>"; COSDictionary cosDict = annotation.getCOSDictionary(); assertNotNull(cosDict.getStringValue(org.apache.pdfbox.cos.COSName.CONTENTS), () -> "expected content stream data ["+expectedContentStreamDataAfterSettingUpValues+"]. Found none."); InputStream inputStreamFromPdfBox = annotation.getAppearanceAsFormXObjects(null)[0]; try (InputStream is = inputStreamFromPdfBox){ byte[] bytesReadByPdbox = IOUtils.toByteArray(is); Assertions.assertTrue(() ->new String(bytesReadByPdbox,"UTF-8").equalsIgnoreCase(expectedContentStreamDataAfterSettingUpValues),()-> "contentstream of pdbox should be equal to "+expectedContentStreamDataAfterSettingUpValues+". It was found as:\n"+IOUtils.readAllToString(inputStreamFromPdfBox)+"\n")); } }

}