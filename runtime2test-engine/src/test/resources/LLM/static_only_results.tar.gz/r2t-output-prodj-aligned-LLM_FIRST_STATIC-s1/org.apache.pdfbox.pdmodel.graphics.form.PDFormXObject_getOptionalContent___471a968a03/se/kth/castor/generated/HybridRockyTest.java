package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFormXObjectRockyTest {

@Test public void testGetOptionalContents() throws IOException, COSVisitorException { PDPage page1 = new PDPixelMap(); assertNull("There should be no OC",page1.getOptionalContent()); }

}