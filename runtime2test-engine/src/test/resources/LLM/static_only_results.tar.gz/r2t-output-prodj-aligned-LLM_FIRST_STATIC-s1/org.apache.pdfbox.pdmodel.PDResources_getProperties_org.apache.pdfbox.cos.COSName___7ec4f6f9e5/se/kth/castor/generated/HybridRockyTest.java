package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetEmpty() throws IOException { PDMarkInfo markinfo = new PDDocument().getPage(0).getMarkInfo(); assertEquals("", markinfo.getName()); assertNull(markinfo.getValueDictionaryEntryForTypeAndKey("PdfName.MKA", "Prop1")); assertNull(markinfo.findResourceByID(2)); }

}