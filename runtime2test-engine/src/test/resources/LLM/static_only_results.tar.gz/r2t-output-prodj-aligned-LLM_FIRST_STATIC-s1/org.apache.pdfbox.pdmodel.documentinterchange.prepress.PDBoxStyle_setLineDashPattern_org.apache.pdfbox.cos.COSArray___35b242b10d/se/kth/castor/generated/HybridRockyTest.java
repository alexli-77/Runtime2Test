package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDBoxStyleRockyTest {

@Test public final void testSetLineDashPattern() throws Exception { BoxStyle bstyle1 = new BoxStyle(); assertNull("Initial value of D",bstyle1.getDictionary().getItem(COSName.D)); ArrayList<Float> listOfFloats = Arrays.<Float> asList((float)(3), (float)(2), (float)(4), (float)(5),(float)(6)); COSArray cosarray = new COSArrayList<>(listOfFloats , "[]"); bstyle1.setLineDashPattern(cosarray ); List<? extends Number> retrievedValueAsNumberList = ((COSDictionary )bstyle1 . getDictionary()).getValues(COSName.D).toList(); int i =0 ;for (Object o :retrievedValueAsNumberList){if(!o.equals(new Float(i++))){fail ("Incorrect values in line dash array");}} }

}