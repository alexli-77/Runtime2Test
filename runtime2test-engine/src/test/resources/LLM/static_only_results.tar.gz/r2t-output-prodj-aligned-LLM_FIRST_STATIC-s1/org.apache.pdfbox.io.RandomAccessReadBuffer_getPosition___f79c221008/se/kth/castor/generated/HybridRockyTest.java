package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testGetPositon() throws IOException, InvalidPasswordException  { assertEquals(0L, pdfSource.getPosition()); }

}