package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDInlineImageRockyTest {

@Test public final void testSetColorSpace() throws IOException { PDDeviceCMYK device = new PDDeviceCMYK(); PDPaint paint1 = new PDPaint(); assertNull("paints initial value is null", paint1.getColorSpace()); paint1.setColorSpace(device); assertNotNull("paints with non-null values are not equal to null.", paint1.getColorSpace()); PDDeviceGray gd = new PDDeviceRGB(); paint1.setColorSpace(gd); try{new PDFontDescriptorDictionary().setFontFile2("/home/jhiller/Desktop"); fail("PdfBox should have thrown an exception."); } catch (IOException ex){assertEquals("wrong message","Error reading font file /home/jhiller/Desktop",ex.getMessage()); }  }

}