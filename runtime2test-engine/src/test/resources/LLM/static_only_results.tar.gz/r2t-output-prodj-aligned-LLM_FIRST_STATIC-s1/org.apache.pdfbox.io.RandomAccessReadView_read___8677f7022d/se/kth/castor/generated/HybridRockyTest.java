package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public void testIsAtEndOfFile2() throws IOException, InterruptedException { PdfReader reader = new PdfReader(new RandomAccessBufferedFileInputStream("target" + File.separatorChar + "test-output", 4096)); InputStream inputStream = getPageContentRawStream(reader); PageRandomAccess fileParser = createInstanceWithInputAndStartOffset(inputStream, 7385L); assertTrue(!fileParser.isEof()); Thread.sleep(100); fileParser.close(); }

}