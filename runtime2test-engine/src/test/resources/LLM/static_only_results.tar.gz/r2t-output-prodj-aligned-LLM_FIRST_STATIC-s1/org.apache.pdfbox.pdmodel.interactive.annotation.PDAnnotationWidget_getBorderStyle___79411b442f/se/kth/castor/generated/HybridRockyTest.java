package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public void testGetBorderStyle() throws IOException { PDAnnotationLine pdAnnot1 = (PDAnnotationLine) annotationList[0]; assertNull("The PDFBox class should be able to read a missing BS entry", pdAnnot1.getBorderStyle()); }

}