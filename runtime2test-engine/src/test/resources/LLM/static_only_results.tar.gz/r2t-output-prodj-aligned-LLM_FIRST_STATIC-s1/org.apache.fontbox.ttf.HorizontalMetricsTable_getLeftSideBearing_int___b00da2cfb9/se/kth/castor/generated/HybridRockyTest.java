package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HorizontalMetricsTableRockyTest {

@Test public void testGetLeftSideBearings() throws Exception { assertEquals(-34, ttf.getFont().getCmapFormat12Subtable("UniGB-UCS2").getLeftSideBearing((short) 65)); }

}