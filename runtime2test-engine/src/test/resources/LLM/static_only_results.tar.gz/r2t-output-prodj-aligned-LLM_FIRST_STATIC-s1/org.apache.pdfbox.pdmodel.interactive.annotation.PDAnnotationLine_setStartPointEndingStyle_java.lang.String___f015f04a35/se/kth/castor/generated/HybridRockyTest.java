package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testSetStartPointEndingStyle() throws IOException { PDPage page1 = this.testUtilsDocument.createSimplePage("First Page"); AnnotationOptions options = AnnotationsToPdfaConversionOptionBuilder.builder().buildAnnotationsToPdfaConversionOption(); PDFont font = PDType1Font.HELVETICA; String textValue = "Some Text"; float xPos = 5f + .3762948F*page1.findMediaBox().width-font.getStringWidth(textValue)/1000; annotationsCreatorUnderTest.annotate(new SimpleTextAnnotation(xPos, yCoordForEvenPages+yShiftIncrementer++, -1), pdfDoc, annotatedFileWriter).withStrokeColor(colorSpaceFactory.fromCosObj(STROKECOLOR)).withFillColor(colorSpaceFactory.fromCosObj(FILLCOLOR)) .withOpacity(.5d).toList()); assertEquals(".", annotationMapUnderTest.iterator().next().getValue().toString(),"endings are not correct!"); }

}