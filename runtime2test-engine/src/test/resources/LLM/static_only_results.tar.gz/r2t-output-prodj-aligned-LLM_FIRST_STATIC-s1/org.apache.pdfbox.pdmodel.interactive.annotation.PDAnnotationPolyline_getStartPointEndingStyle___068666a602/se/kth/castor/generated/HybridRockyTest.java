package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public void testGetStartPointEndingStyleNoLeEntry() throws Exception { annotationUnderTest = new PDAnnotationTextMarkup(); assertEquals("None", annotationUnderTest.getStartPointEndingStyle()); }

@Test public void testSetAndGetStartPointEndingStyleDefaultValue() throws IOException { String expectedResult = "OpenArrow"; annotationUnderTest.setStartPointEndingStyle(expectedResult); String actualResult = annotationUnderTest.getStartPointEndingStyle(); assertNotNull(actualResult); assertTrue(!actualResult.isEmpty()); assertThat(actualResult).isEqualToIgnoringCase(expectedResult); }

@Test public void testSetAndGetStartPointEndingStyleValidValues() throws IOException { String[] validResults = {"None", "ClosedArrow"}; String[] invalidResults = {"Invalid", ""}; for (int i = 0; i < validResults.length; ++i) { annotationUnderTest.setStartPointEndingStyle(validResults[i]); String result = annotationUnderTest.getStartPointEndingStyle(); assertNotNull(result); assertFalse(result.equalsIgnoreCase(invalidResults[1])); assertTrue((!result.equalsIgnoreCase(invalidResults[0])) || (!result.equalsIgnoreCase(validResults[1]))); } }

}