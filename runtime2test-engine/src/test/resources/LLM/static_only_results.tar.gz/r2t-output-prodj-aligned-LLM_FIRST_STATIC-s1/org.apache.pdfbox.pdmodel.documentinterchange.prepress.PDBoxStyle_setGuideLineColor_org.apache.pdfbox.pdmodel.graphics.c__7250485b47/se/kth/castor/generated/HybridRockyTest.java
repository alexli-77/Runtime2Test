package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDBoxStyleRockyTest {

@Test public final void testSetPatternName01() throws Exception { PDFont font = createFont("Arial", "Helvetica"); FontBoxShading shading = addSimpleGouraudTriangleMeshToPageWithTexturesAndColors(font, page); assertEquals("/P2-Hexa-Rand", ((PDFunctionType4)shading.getFunction()).getName()); }

}