package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDShadingRockyTest {

@Test public final void testSetFunction() throws IOException { PDSeparationColorSpace sepCS1 = (PDSeparationColorSpace) pdDocument.getPageModele().getDefaultResources().createDeviceCMYK(); assertNotNull("function should not be empty",sepCS1.getFunction()); org.apache.pdfbox.pdmodel.common.PDDictionary dict2 = new org.apache.pdfbox.pdmodel.common.PDDictionary(); org.apache.pdfbox.cos.COSDictionary dictobj =new org.apache.pdfbox.cos.COSDictionary(); dictobj.put(org.apache.pdfbox.cos.COSName.TYPE,"Pattern"); dictobj.put(org.apache.pdfbox.cos.COSName.MATRIX , org.apache.pdfbox.util.Matrix.singularScaleInstance(0)); dictobj.put(org.apache.pdfbox.cos.COSName.BBOX, org.apache.pdfbox.cos.COSInteger.ZERO );dictobj.put(org.apache.pdfbox.cos.COSName.RESOURCES, new org.apache.pdfbox.cos.COSDictionary()); dictobj.put(org.apache.pdfbox.cos.COSName.NAME, "a"); dictobj.put(org.apache.pdfbox.cos.COSName.SUBTYPE,"FormType"); dictobj.put(org.apache.pdfbox.cos.COSName.FORMAT, "ImageMask"); dictobj.put(org.apache.pdfbox.cos.COSName.WIDTH, new Integer(5).floatValue()); dictobj.put(org.apache.pdfbox.cos.COSName.HEIGHT, new Integer(3).intValue()); dictobj.put(org.apache.pdfbox.cos.COSName.BITSPERCOMPONENT, new Float(8)); dictobj.put(org.apache.pdfbox.cos.COSName.COLORSPACE, "/CalGray"); dictobj.put(org.apache.pdfbox.cos.COSName.FILTER, org.apache.pdfbox.filter.

}