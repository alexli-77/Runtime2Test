package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSDictionary() throws IOException { PDDocument doc = new PDDocument(); PDFont font1 = new FOPDFFont("Helvetica", "winansi"); assertNotEquals(-9347528,font1.hashCode()); String strValue="Hello World!"; byte[] bytes = strValue.getBytes(); COSBoolean booleanObj = new COSBoolean(true); Dictionary dict = new Dictionary(); dict.put(new Name("name"), new Array().addItem(booleanObj).build()).put(new Name("value"),bytes ); dict.setParent((PDPageTreeNode<?>)doc.getPages()) ; COSArray array=dict.toListOfObjects(); for (int i =0; i<array.size();++i){if (array .getObjectAt(i) instanceof Dictionary ){ assertFalse(false,"unexpected type at index "+i+" found"+ array.getObjectAt(i)+" instead of "+strValue +". "+System.lineSeparator(), System.out::println);}}  Document docXWPF = XWPFConverterUtil.convert(doc , OutputFormat.ODT); ByteArrayOutputStream outPutByteArrStream = new ByteArrayOutputStream (); docXWPF.write(outPutByteArrStream); InputStream inputStream = new FileInputStream ("src\\test\\resources\\result.odt") ; int b=-1; while ((b=inputStream.read()) != -1 ) { Assertions.assertTrue(outPutByteArrStream.toString().indexOf("hello world!")>-1 || b=='\n'|| b == '\r'); } }

}