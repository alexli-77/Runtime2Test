package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceEntryRockyTest {

@Test public void testGetAsDictionaryWithoutEntryThrowsNullPointerException() throws Exception { assertThatCode(() -> pdfTrailerInfoUnderTest.getAsDictionary()).hasMessageContaining("/Root") .doesNotThrowAnyException(); }

}