package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFStreamEngineRockyTest {

@Test public final void testShowAnnotation() throws Exception { PDPageContentStream stream; PDFont font14 = new PdfBoxResourceLoader().getFont("Helvetica-Bold"); stream = createPDFAnotation(font14).createNormalAppearence(); AnnotationsSlide annotatedSlide = addTextToPdDocumentAndGetAnnotatedSlideWithGeneratedAPName(stream); assertTrue(annotatorHelperService.showAnnotation(annotatedSlide)); String generatedApNamelowerCaseString = GenerateAPNamesForAnnotationTestsUtilityClass.convertUppercaseCharacterstoLowercaseCharactersInTheGivenStirng(generateRandomAlphaNumericOfLengthFive()); generateNewAPandAssertItsNotNull(generatedApNamelowerCaseString, annotatedSlide); }

}