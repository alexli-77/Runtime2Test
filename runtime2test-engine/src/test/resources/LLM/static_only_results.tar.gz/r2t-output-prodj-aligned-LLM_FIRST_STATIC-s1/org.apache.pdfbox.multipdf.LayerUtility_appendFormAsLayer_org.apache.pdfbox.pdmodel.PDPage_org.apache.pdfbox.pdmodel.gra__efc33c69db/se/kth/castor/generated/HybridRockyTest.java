package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LayerUtilityRockyTest {

@Test public void testGetCropBox() throws Exception { PDDocument doc = Loader.loadPDF(resourceFile); assertEquals(doc.getNumberOfPages(), 1); PDPage pdPage = doc.getPage(0); Rectangle rect = pdPage.getBoundingBox().createIntersection(pdPage.getArtBox()); assertTrue(!rect.isEmpty()); assertFalse(pdPage.equals(null)); }

}