package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFontDescriptorCapHeightWithNegativeInfinityReturnedByPdfBoxCoreWhenReadingNotDefinedEntryFromDictonaryForSomeReason() throws IOException { COSStream stream = new COSDict().streamify(); PDSimpleFontType1 simpeFont = new PDFontFileAFM("test", "test"); FontMetrics metrics = simpeFont.getFontProgram().getFontMetrics(); assertEquals(-3785f, metrics.getCapHeight(), .01d); }

}