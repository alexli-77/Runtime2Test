package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

@Test public void testGetLengthNoValueSet() throws IOException { assertEquals(-1L, cosWriter.getLength()); }

}