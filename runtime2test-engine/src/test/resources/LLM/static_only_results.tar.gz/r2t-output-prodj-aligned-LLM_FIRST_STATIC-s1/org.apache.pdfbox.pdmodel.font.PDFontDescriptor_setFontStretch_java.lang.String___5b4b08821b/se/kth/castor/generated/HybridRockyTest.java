package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testSetFontStretch() throws IOException { PDType1Font type0PFont = new PDType1Font(); assertNull("Default value is null",type0PFont.getBaseFont()); type0PFont.setSubsetting("abc"); String expectedValue = "Regular"; type0PFont.setFontWeight(expectedValue); assertEquals(expectedValue,"" + type0PFont.getFontWeight().getValue()); }

}