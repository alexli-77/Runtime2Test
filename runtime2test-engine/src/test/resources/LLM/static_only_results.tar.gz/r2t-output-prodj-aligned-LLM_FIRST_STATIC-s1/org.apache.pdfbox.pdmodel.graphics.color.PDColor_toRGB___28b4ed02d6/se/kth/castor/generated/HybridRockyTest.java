package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDColorRockyTest {

@Test public void testToRGB() throws Exception { PDColor pdc = new PDColor((float[])null, null); assertEquals(-16734928, pdc.getAsRGBA()); }

}