package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolygonRockyTest {

@Test public void testGetPathWithNoOperatorsReturnNull() throws IOException { PDShadingType3 shad = createShader("q\n" + "1 g\np\nt"); assertEquals(null, shad.getPath()); }

@Test public final void testGetPathWithTwoElementsAndClosingParen() throws Exception { PDShadingType3 shading = createShader("[(549.87 -399.7), (549.87 -399.), [(549.87 -399.)], [((549.87 -399.).)]]\n" + "[(549.87 -399.), (549.87 -399.), [(549.87 -399.)]] q \n" + "1 G /DeviceRGB cs\na 1 w S Q"); List<float[]> expectedResult = Arrays.<float[]> asList(new float[]{549.87f, -399.7f}, new float[]{549.87f, -399f}); Assertions.assertThat(shading.getPath()).isEqualToComparingElementByElementRecursively(expectedResult); }

@Test public final void testGetPathWithTwoElements() throws Exception { PDShadingType3 shading = createShader("[(549.87 -399.7),(549.87 -399.)] q\n" + "1 G /DeviceGray cs\nb . clr\nx y ml n Q"); List<float[]> expectedResult = Arrays.<float[]>asList(new float[]{549.87f, -399.7f}, new float[]{549.87f, -399f}); Assertions.assertThat(shading.getPath()) . isEqualToComparingElementByElementRecursively(expectedResult); }

@Test public final void testGetPathWithThreeElements() throws Exception { PDShadingType3 shading = createShader("[(549.87 -399.7

}