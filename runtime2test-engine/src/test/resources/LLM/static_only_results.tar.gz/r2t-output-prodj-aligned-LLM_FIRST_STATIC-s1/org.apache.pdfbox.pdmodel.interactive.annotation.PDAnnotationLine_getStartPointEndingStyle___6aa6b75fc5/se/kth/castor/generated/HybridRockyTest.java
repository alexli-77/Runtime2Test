package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetSetStartPointEndingStyle() throws IOException { annotation.setStartPointEndingStyle("Diamond"); assertEquals("Diamond", annotation.getStartPointEndingStyle()); }

}