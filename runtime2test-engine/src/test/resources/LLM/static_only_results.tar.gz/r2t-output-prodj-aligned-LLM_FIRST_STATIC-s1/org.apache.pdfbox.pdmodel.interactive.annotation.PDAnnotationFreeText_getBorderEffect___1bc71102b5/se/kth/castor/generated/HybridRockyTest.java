package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationFreeTextRockyTest {

@Test public void testGetBorderEffectWithNullValueDoesNotFail() throws IOException { PDAnnotationLine annotation = createDefaultAnnot(); assertEquals("Wrong value", 0L, (long) annotation.getBorderEffect()); }

}