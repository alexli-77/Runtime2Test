package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testGetObject2() throws Exception { PDDocument doc1 = Loader.loadPDF("test-documents\\basicPdfFile.pdf"); PDFont font = PDType3Font.createWithPFB(doc1, "test-fonts\\FreeMono.pfb", true); assertEquals("F4857A96-EACC-4BB1-BEAE-3CCABCA19CB8", UUIDUtil.toUuidString(font)); }

}