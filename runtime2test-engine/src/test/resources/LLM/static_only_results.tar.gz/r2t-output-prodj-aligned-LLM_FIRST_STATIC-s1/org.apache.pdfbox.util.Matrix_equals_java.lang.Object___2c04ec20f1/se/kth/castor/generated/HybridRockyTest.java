package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testEquals230174689() throws Exception { Matrix matrix = new Matrix(); assertFalse("Should not be equal",matrix.equals((Object)"")); }

@Test public final void testGetTransposedVectorTransformedByThisMatrixAndGivenPointInverseMultipliedWithOther() throws IOException { PDFont font = PDType1Font.HELVETICA; String string = "Hello World"; Vector vector = getTextDisplacementForStringAtPosition(font, string, 50f, 600f); float[] componentsX = new float[vector.length]; for (int i = 0 ;i < componentsX.length - 1;++i){componentsX[i] = vector.getComponent(i + 1).floatValue();} org.junit.Assert.assertTrue(new Matrix().createAffineTransform().transform(componentsX, 0 ,null)); }

@Test public final void testToString() throws Throwable { System.out.println("toString"); Matrix instance = new Matrix(); String result = instance.toString(); Assertions.assertNotNull(result); Assertions.assertThatCode(() -> Float.parseFloat(instance.getElementAsString(0)) ).doesNotThrowAnyException(); Assertions.assertThatCode(() -> Float.parseFloat(instance.getElementAsString(1)) ).doesNotThrowAnyException(); Assertions.assertThatCode(() -> Float.parseFloat(instance.getElementAsString(2)) ).doesNotThrowAnyException(); Assertions.assertThatCode(() -> Float.parseFloat(instance.getElementAsString(3)) ).doesNotThrowAnyException(); Assertions.assertThatCode(() -> Float.parseFloat(instance.getElementAsString(4)) ).doesNotThrowAnyException(); Assertions.assertThatCode(() -> Float.parseFloat(instance.getElementAsString(5)) ).doesNotThrowAnyException(); }

}