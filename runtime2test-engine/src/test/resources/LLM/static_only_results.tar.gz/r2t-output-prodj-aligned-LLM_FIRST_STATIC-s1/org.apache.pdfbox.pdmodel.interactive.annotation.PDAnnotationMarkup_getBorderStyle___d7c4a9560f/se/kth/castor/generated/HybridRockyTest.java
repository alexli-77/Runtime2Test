package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetBorderStyle() throws IOException { PDAnnotationLine annotation1 = (PDAnnotationLine) annotationsList[0]; assertNotNull("No Border Style", annotation1.getBorderStyle()); }

}