package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LZWFilterRockyTest {

@Test public void testDoEncode() throws IOException{ byte[] bdata2 = "Hello World!".getBytes("ISO-8859-1"); ByteArrayInputStream inputStream3 = new ByteArrayInputStream(bdata2); DeflateParameters deflateParam = (DeflateParameters)(new COSDictionary()).addBooleanEntry(COSName.ASCII_HEX ,true).asDict(); Filter filter4 = new FlateFilter().createDefaultEncoder(deflateParam ); ByteArrayOutputStream baos7 = new ByteArrayOutputStream(); OutputStream outputStream6 = filter4 .encode(inputStream3,baos7, null); assertEquals(-1,outputStream6.read()); String resultString = new String(baos7.toByteArray(),"UTF-8").trim(); System.out.println("\nresult : "+resultString+"\nexpected:" + "\uD8FF\uDCFF\r\n\f\t \n"); assertTrue((resultString == ("\uD8FF\uDCFF\r\n\f\t \n")) || (resultString == ("\uDBFF\udCff\r\n\f\t \n"))); }

}