package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testIsNotAnImage() throws Exception { PDDocument doc1 = new PDDummy().createPDFFromFile("test-data/document027584639.pdf"); assertFalse(doc1.isImageXObject(new COSName("/Foobar"))); }

}