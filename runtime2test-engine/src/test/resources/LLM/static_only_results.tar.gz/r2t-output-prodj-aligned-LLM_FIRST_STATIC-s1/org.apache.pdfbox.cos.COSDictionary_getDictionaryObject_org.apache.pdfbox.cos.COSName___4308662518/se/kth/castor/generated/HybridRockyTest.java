package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

static byte[] encodeBoolToBytes(boolean b){if(!b){return "0".getBytes();}} static boolean decodeFromHex(byte [] bytes,int offset,int length); static boolean decodeFromInts(List listOfNumbers,int offset,int sizeIn

}