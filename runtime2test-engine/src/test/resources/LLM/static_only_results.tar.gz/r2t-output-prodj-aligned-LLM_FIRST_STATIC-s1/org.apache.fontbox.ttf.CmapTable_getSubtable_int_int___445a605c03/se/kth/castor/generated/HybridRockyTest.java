package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CmapTableRockyTest {

@Test public void testGetTableWithDifferentEncodings() throws IOException { CMAPParser parser = new CMAPParser(); InputStream is1250Input = this.getClass().getResourceAsStream("winansi-encoding.bin"); InputStream is874Input = this.getClass().getResourceAsStream("iso8859-thai.bin"); try (BufferedInputStream inp1 = new BufferedInputStream(is1250Input); BufferedInputStream inp2 = new BufferedInputStream(inp1, 36 + 14*2+8*2); ) { TTFFile ttfFile = new TTFFile(); ttfFile.setIsBigEndian(true); Map<String, Object> map1250 = parser.parse(new RandomAccessReadableByteChannelImpl(inp1)); assertNotNull(parser.createCMapFromData((byte[]) map1250.get("data"))); Map<String, Object> map874 = parser.parse(new RandomAccessReadableByteChannelImpl(inp2)); assertTrue(!ArrayUtils.isEmpty((byte[]) map874.get("subTables")[0].getBytes())); } catch (Exception e) { fail(e.toString()); } }

}