package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFStreamEngineRockyTest {

@Test public final void testShowFormWithoutChildrenThrowsNullPointerExceptionOnCurrentPageIsNull() throws Exception { try { this.contentProcessorUnderTest.showForm((PDFont)null); fail(); } catch (AssertionError e) {} assertThat(caughtThrowable()).isInstanceOf(java.lang.IllegalArgumentException.class).hasMessageContaining("The parameter 'font' must not be null."); verifyZeroInteractions(this.pageMock); resetCaughtThrowable(); }

}