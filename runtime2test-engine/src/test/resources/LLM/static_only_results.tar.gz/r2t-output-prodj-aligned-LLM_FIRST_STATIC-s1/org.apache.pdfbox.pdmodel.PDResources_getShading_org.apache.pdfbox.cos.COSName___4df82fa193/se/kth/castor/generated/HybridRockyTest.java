package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetShading() throws Exception { PDDocument doc = new PDFParser().parse("target" + File.separatorChar + "test-data" + File.separatorChar + "simple1.pdf"); assertNotNull(doc.getPages()); COSDictionary pageDict = doc.getPage(0).getCOSObject(); Map<String, String> map = new HashMap<>(); map.put("/Type", "/Pattern"); map.put("/PaintType", "2"); map.put("/BBox[0 0 3564897.87 3564897.87]"); map.put("/Matrix [0.999998092 0 0 -0.000001908 0 3564897.87 ] "); map.put("/XStep", "-1"); map.put("/YStep", "-1"); map.put("/Resources << /ProcSet [/PDF /Text] >> ", ""); map.put("/Length 110660", "n"); byte[] data = BaseEncoding.base64Url().decode("AABlAGMAAAAAAAEgAFQRNpKoMwGzbLy+jFuUkVrIqCfhOtgZmWi3HxvwAAAgAIACARKAGQAAAEBAAAAAAcP//BIeBCdFGkRaW1td2VzdGlzaWEvbWFpbHRvcmluZ2luZywgc2ltcGxlcywgaGVsbGEucXVldSwgb24uaWRlbnRpc3Quam9obiwgdmFsdWUudWNhdGlvbiAtcmFkaW5nIGkgcnVubmluZyBrbm93LCBmb3IgYSIsImhlbGxvd2VicmFja2dyb3VuZEVybAUBAQ=="); ByteArrayInputStream bais = new ByteArrayInputStream(data); map.put("/Filter", "[/FlateDecode]"); COSSubStream substream = createSubStream(pageDict, 0, bais, map, false); assertEquals(-1, substream.readInt(), "

}