package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FilterFactoryRockyTest {

@Test public void testGetFilters() throws Exception { FilterFactory factory = new DefaultFilterFactory(); assertEquals(1, factory.filters.size()); FactoryRegistry<InputStream> registry = mock(FactoryRegistry.class); whenNew(FactoryRegistry.class).withNoArguments().thenReturn(registry); InputStream inputStreamMock = Mockito.mock(InputStream.class); doAnswer((invocation -> { invocation.<OutputStream>getArgumentAt(0, OutputStream.class).write("Hello World".getBytes(StandardCharsets.UTF_8)); return true;})) .when(inputStreamMock).transferTo(any(OutputStream.class), anyLong(), eq(-1L)); ByteArrayOutputStream outputStream = new ByteArrayOutputStream(); try { factory.createInputFile("/test", "/tmp"); fail(); } catch (IllegalStateException e) {} IOUtils.closeQuietly(outputStream); String resultString = new String(outputStream.toByteArray(), StandardCharsets.US_ASCII); Assertions.assertThat(resultString).isEqualToIgnoringCase("Hello World"); }

}