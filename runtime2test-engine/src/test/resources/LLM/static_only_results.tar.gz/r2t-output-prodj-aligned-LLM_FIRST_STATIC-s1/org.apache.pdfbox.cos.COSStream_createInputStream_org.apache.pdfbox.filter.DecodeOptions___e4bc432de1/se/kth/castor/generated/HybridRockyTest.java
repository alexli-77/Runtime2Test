package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

@Test public void testGetByteArrayOutputStreamLengthWithNullValue() throws Exception{ COSDictionary dict1=new COSDictionary();dict1.setItem("Foo",null ); assertEquals(-1 ,((COSBooleanObject )dict1).intValue()); }

}