package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public void testGetEndPointEndingStyleNullCase() throws Exception { Assertions.assertEquals("None", annotation.getEndPointEndingStyle()); }

}