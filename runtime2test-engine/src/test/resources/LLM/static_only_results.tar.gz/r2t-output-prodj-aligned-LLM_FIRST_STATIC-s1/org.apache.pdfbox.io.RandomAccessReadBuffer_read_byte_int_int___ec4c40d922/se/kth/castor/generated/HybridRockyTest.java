package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testChunkedPDFStreamWithOffsetAndLengthLessThanAvailableData() throws IOException { ChunkedInputStream inputstream = new ChunkedInputStream((COSDictionary) null, false, true, "3\r\nThis is a tes".getBytes(), "4\r\nt for the win!".getBytes()); byte[] buffer = new byte[8]; assertEquals("Should be able to get data from first call", 5, inputstream.read(buffer)); String resultString = new String(ArrayUtils.subarray(buffer, 0, 5), Charsets.US_ASCII).trim(); Assertions.assertThat(resultString).isEqualToIgnoringWhitespace("This"); assertNotNull(inputstream.nextBufRef()); assertTrue(inputstream.hasNextByte()); // move pointer ahead so that second read gets called in this method @SuppressWarnings({"squid:S2697","squid:MethodCyclomaticComplexity"}) int bytesLeftInSecondCall = Math.min(length - currentLenOfLastBlock, available()); int totalBytesFromAllCalls = bytesReadFirstPartially + bytesLeftInCurrentBlockForNextGetMoreDataRequest + bytesLeftInPreviousCallIfAny + bytesLeftInSecondCall; assertEquals("Total number of bytes should match ", totalBytesFromAllCalls, bytesReadSoFar); long expectedResult = bytesLeftInSecondCall >= remaining ? remaining : bytesLeftInSecondCall; assertEquals("Expected value should match with actual one.", expectedResult, inputstream.read(buffer, 0, length)); String finalResultString = new String(ArrayUtils.subarray(buffer, 0, (int)(expectedResult)), StandardCharsets.UTF_8); Assertions.assertThat(finalResultString).isEqualToIgnoringCase("\tfor the "); assertFalse(inputstream.hasNextByte()); }

}