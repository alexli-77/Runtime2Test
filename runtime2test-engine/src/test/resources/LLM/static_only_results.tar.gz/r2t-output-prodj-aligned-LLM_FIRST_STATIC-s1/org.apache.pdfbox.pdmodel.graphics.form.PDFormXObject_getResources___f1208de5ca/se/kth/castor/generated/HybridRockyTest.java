package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFormXObjectRockyTest {

@Test public void testGetResources() throws IOException { PDFormXObject pdFormXObj = createAcroformWithoutResourceDictionaryEntry(); assertNull("The returned value should be NULL.", pdFormXObj.getResources()); }

}