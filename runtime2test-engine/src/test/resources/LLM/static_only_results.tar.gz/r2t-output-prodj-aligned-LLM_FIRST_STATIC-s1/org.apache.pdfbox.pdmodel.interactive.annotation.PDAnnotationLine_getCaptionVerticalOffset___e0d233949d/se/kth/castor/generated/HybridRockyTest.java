package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetCaptionVerticalOffsetWithoutCoordinateEntry() throws IOException, InterruptedException { PDFont font = PDType1Font.HELVETICA; COSDictionary dict = new COSDictionary(); dict.setItem("Length", (int)font.getStringWidth("\u263a")); assertEquals(-497.85f, new PDCaption(dict).getCaptionHorizontalPosition(), EPSILON); }

}