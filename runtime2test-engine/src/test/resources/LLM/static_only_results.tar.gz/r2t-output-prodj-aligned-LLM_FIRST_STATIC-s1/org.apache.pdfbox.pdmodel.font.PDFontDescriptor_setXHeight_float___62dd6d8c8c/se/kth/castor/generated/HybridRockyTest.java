package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetXheight() throws Exception { float f1 = .0f; String s2 = "Hello"; FontInfo fi3 = getFont("Helvetica"); Assertions.assertEquals(.0f, (fi3).getAscent(), DELTA); Assertions.assertNotNull((fi3).getEncoding()); Assertions.assertTrue(!((fi3)).isEmbedded()); Assertions.assertFalse((fi3).hasKerningPairs()); Assertions.assertTrue(!((fi3)).isFixedWidth()); Assertions.assertEquals(-84., ((fi3)), -76., FloatDeltaComparator.DEFAULT); assertArrayEquals(new byte[]{(byte)-95}, (fi3).encodeToBytes("i")); ByteBuffer bb4 = null; try { bb4 = CharsetsUtil.toUtfByteBuffer("H", StandardCharsets.UTF_16BE); } catch (IOException e) { fail(); } fi3.addString(bb4); fi3.addCharacterSpacing(f1, f1, f1); Assertions.assertEquals(".notdef", (fi3).getName().toString()); Assertions.assertEquals("/WinAnsiEncoding", (fi3).getBaseEncoding()); Assertions.assertEquals(null, (fi3).getBoundingBox()); Assertions.assertEquals(false, (fi3).equals((Object)"abc"), false); Assertions.assertEquals(true, (fi3).equals((Object)(new PDType0Font())), true); Assertions.assertEquals(true, (fi3).equals((Object)(PDType0Font.load(doc, RESOURCES + "fonts" + File.separator + "LiberationSerif-Regular")))); Assertions.assertEquals(true, (fi3).equalsByDefaultGlyphList((Object)(PDType0Font.load(doc, RESOURCES + "fonts" + File.separator + "LiberationSerif-Italic"))), true); Assertions.assertEquals(false, (fi3).containsCIDRanges(Collections.<Range>emptyList()), false); Assertions.assertEquals(false, (fi3).embedSubsetPrefixes(Collections.<PDFontDescriptorDictionary> emptyList()).isEmpty(), false); Assertions.assertEquals(false,

}