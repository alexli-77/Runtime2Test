package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationSquareCircleRockyTest {

@Test public void testSetRectDifferences() throws IOException { AnnotationUtils util = new AnnotationUtils(getDocument()); PDBorderDictionary dictionary = util.createPDBorderDictionaryFromBorderStyles("border", false); assertEquals(-1f, dictionary.getRectMargin(), EPSILON); assertEquals(-20f, dictionary.getRadiiMargin(), EPSILON); }

}