package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetDictionaryObject() throws Exception { PDDocument doc = new PDDummyPdfDoc("ThisIsAString"); PDFont font1 = new PDFFont(); assertNotEquals(-902743586, font1.hashCode()); String s = "ThisIsAnotherString"; byte[] bb = s.getBytes(); ByteArrayInputStream stream = new ByteArrayInputStream(bb); PDCFFStream pdCffStream = new PDCFFStream((PDDocumentCatalog)null,(COSDictionary)new Dictionary(),stream,"UTF-8",false); Assertions.assertThrows(IllegalArgumentException.class, () -> pdfBoxCorePropertiesMapperUnderTest.setFieldAsDictAndReturnNewInstanceIfExists(pdCffStream, "/Length")); }

}