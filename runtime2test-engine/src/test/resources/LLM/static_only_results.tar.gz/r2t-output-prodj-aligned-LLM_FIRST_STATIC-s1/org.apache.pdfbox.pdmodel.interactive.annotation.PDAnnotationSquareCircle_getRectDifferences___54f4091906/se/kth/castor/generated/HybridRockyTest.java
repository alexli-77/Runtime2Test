package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationSquareCircleRockyTest {

@Test public void testGetSetRectDiff() throws Exception { assertEquals("Wrong number of rect diff values",0, annot2.getRectDifferences().length ); }

}