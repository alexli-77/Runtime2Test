package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStringRockyTest {

@Test public void testHashcodeForceFalseEqualsTrue() throws Exception { byte[] bytes2 = new byte[4]; PdfString string3 = new PdfString("hello", null, false); assertNotSame(string3.getBytes(), string2.getBytes()); assertThat(string3).isEqualTo(new PdfString("hellos")); }

@Test public void testGetValueWithoutNewlineAndSpaces() throws IOException { String s = "This is a sample text\n" + "\rwith some special characters:\t\\\""; ByteBuffer bb = new ByteBuffer(); OutputStream os = bb; try { pdfDocEncryptor.encryptByteRange(s, os, true); } finally { if (bb != null) { bb.close(); } } Assertions.assertThat((PdfObject)(obj)).hasToString("6875696c6f7a6e206d656469612073616d706c652053616d706c65"); }

}