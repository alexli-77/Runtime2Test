package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolygonRockyTest {

@Test public void testGetBorderEffectNull() throws IOException { PDAnnotationLine pdAnno1 = (PDAnnotationLine) annotationList[0]; assertThat("The Border Effect should not exist", pdAnno1.getBorderEffect(), is((nullValue()))); }

}