package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationFreeTextRockyTest {

@Test public void testGetRectDifference() throws Exception { PDBorderEffectDictionary dict1 = createBorder(); assertNull("No effect",dict1.getRectDifference()); }

}