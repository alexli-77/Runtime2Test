package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDPatternRockyTest {

@Test public void testGetPattern() throws Exception { PDResources res1 = new PDResources(); Assert.assertNull(res1.getPattern(null)); PDPattern pdp = new PDTilingPattern(); pdp.setBBox(new PDRectangle(-50,-2369487.2f, 100 ,2369487.2f ) );pdp.setPaintType(PDTilingPattern.PAINT_TYPE_COLOR); pdp.setMatrix(new Matrix(.001,.001, .001,.001, -499810, -2369487.2f)); pdp.setXStepAndYStep(1,1); pdp.addToDictionary(res1); PDFont fnt = new FOPDFFont(); fnt.encoding="Identity-H"; fnt.fontname="ArialMT"; fnt.subtype="TrueType"; fnt.isEmbedded = true ;PDFontDescriptor descrptor = new FontManager().convertFONtoDescprtor(fnt);descrpotor.ascent=-1; descrptor.capHeight=1;descrptor.xMaxExtent=1;descrptor.italicAngle=0;descrptor.stemV=1;descrptor.flags=(short)(0xC0 | 0x040 | 0x10);descrptor.weight=500;descrptor.widthClass=1;descrptor.bBox=[];descrptor.blueValues=[], descriptor.greenValues=[], descriptor.redValues=[]; descriptor.avgWidth=1; descriptor.maxLogicalWidhth=.001;descpotr.missingWidth=.001;descriptor.defaultEncoding ="WinAnsiEncoding";res1.putFont(new COSName ("Helvetica"), descrpotor);Assert.assertEquals("/Pat"+"ter"+Integer.toString(res1.size()), res1.add(pdp).getNameAsString(), "Added Pattern to Resources "); pdpatern = res1.getPattern(new COSName("Pat")); assertNotNull

}