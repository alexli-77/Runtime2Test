package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testToFloatArray2() throws Exception { COSBoolean booleans[] = new COSBoolean[]{new COSBoolean("true"), new COSBoolean("false")}; List<COSBoolean> listOfBooleans = Arrays.asList((booleans)); COSArrayList cosarraylist1 = new COSArrayList(listOfBooleans,null); assertEquals(-3456789f,-cosarraylist1.toFloatArray()[0], .0000001d ); }

}