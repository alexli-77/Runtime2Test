package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSObjectPoolRockyTest {

@Test public void testPut() throws IOException { assertEquals("2", cosDoc1.nextFreeObjNum().toString()); assertNull(docCatalog.getDocumentIDArray()); docCatalog.addDocumentIdEntry(new PDStandardSecurity(secHandler)); assertNotNull(docCatalog.getDocumentIDArray()); PDFParser parser = new PDFParser(); InputStream input = new ByteArrayInputStream(outputstream.toByteArray()); parser.parseStartxref(input); String line = ""; while (!line.startsWith("%EOF")){ line = reader.readLine(); outputstream.writeBytes(line + "\n"); } OutputStream outpustream = new FileOutputStream("/Users/mkl/tempfiles/"+ UUID.randomUUID().toString()+"-testPut.pdf"); pdfWriter.copyPagesAndClose(parser.getPdfReaderInstance().getPageOrgToNewMap().valuesIterator(),outpustream); pdfWriter.close(); }

}