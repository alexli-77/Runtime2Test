package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SecurityHandlerRockyTest {

@Test public final void testDecryptStreamIdentity() throws Exception { SecurityEnvironment env = mock(SecurityEnvironment.class); doReturn(true).when(env).authenticateLocalContent(any()); SecurityProvider provider = mock(SecurityProvider.class); Reader reader = mock(Reader.class); Decrypter dcpr = spy(new StandardDecrypter(reader, password)); PDDocument doc = preparePDForTestsWithPasswordAndDecrypters(dcpr, env, provider); assertEquals((long) 476, dcpr.getCurrentKeyLengthInBits()); verifyNoMoreInteractions(provider, env); }

}