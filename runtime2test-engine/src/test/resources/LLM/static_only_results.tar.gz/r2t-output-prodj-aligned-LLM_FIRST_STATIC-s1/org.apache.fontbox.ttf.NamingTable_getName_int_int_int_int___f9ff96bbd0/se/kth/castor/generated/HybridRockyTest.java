package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NamingTableRockyTest {

@Test public void testGetName() throws IOException { String actual = names.getName("0", "12876", "932", "en"); assertEquals("/F4 Arial Italic", actual); }

}