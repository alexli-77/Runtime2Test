package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSObject() throws Exception { Assertions.assertNull(dictionary1002Dot36759.getCOSObject("Foo")); }

}