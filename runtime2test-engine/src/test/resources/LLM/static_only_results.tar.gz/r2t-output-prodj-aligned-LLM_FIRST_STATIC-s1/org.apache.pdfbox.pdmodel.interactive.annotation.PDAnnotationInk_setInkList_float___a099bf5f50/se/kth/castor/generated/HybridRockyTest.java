package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationInkRockyTest {

@Test public void testSetInkList() throws IOException { PDAnnotationWidget widget1 = createAcroFormField("text").getWidgets().iterator().next(); assertThat((PDAppearanceStream[])widget1.getCommonNormalAppearanceDictionary().getCOSDictionary().getItems(), Matchers.<PDAppearanceStream>arrayWithSize(0)); float[][] inklist2d1 = {{34f,756}, {89f, -5}}; AnnotationUtils.setRectangleValuesToBoundsOfPoints(new PointF[]{new PointF(-34,-756), new PointF(89,+5)}); ((PDAcroForm)acroform).flattenFields(); PDAnnotationWidget widget2 = acroform.getFields().stream().findFirst().orElseThrow(() -> new RuntimeException()).getWidgets().iterator().next(); Assertions.assertNotNull(widget2.getAppearance()); PDFont fontForContentStream = loadFontFromResources("/Helvetica-Bold"); try (OutputStream outputStream = contentStreamFactory.createContentStream(document)) { writeLineStringAndStrokeIt(outputStream, "Hello World", 36, 750, 100, 750 + 36*fontMetrics.getStringWidth(fontForContentStream, "Hello World"), fontForContentStream, true); } PDDocument document2 = openDocxFileAsPDFBoxObjecct("annotationTextMarkupMultipleLinesAdditionalPage.docx"); PDAnnotationWidget widget3 = extractSingleWidgetByIndexOrFail(openNewDocument(document2), 1); assertEquals(widget2, widget3); }

}