package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDColorRockyTest {

@Test public void testGetComponentsPatternColorSpacesCloneCaseNullCS() throws IOException { PDDeviceGray g = new PDDeviceRGB().toCustomObject(); assertNotSame("should not be same", g, pdfDocument); try (PDPage page = new PDPage()) { pdDoc.addPage(page); addAnnotationWithEmptyColorValueToCurrentPage(g); Color expectedResult = new DeviceCMYK(.0f,.0f,.0f,.0f).darker(); List<PDFont> fontsUsedInTextExtraction = Collections.<PDFont>emptyList(); ExtractedText extractedTextFromWholeFileUsingPreviousConfigurationValuesAndFontSubstitutionIfApplicable = extractor.extractUniqueWordsOrTheirEquivalentsForOnePage(new PageWrapper(pdDoc), 0 ,fontsUsedInTextExtraction, false ); Assertions.assertThat((float)(expectedResult .getRed()))   .isEqualTo((float)(extractedTextFromWholeFileUsingPreviousConfigurationValuesAndFontSubstitutionIfApplicable.getTextHighlightingColorsByRangesMap().values().iterator().next()).getRed(),withinPercentage(TESTING_FLOAT_PRECISION)); } catch (IOException e) { throw new RuntimeException(e); } }

}