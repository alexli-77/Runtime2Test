package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetFontBoundingBox() throws Exception { PDType1Font font = getBaseLinePdf().addDefaultPageAndGetFont("Helvetica"); assertNotNull(font); PDFontDescriptor descr = font.getDescript(); Rectangle2D bbxd = descr.getAscentDescenderWidthLeadingHeightDisableKerningTextAdvanceBounds(); int width = MathUtils.round((bbxd.getMaxY()) - (bbxd.getMinY())); float height = ((float)(width)) / this.baseRatioHW + .0f; Assertions.checkArgument(!FloatMath.isNaN(height), "Could not calculate Font Bound Box Height from Width and Ratio."); PDFontDescriptor fdescr = new PDFontDescriptor(); String name = "/" + SystemInfoUtilities.SYSTEM_INFO.OSFamily.name().toLowerCase(Locale.ENGLISH).replace(' ', '-')+"-"+SystemInfoUtilities.SYSTEM_INFO.Architecture+".ttf"; try (InputStream is = ClassLoaderUtility.findResourceAsStream(PDFontFactory.class, name)) { byte[] data = IOUtils.readAllBytes(is); fdescr.setPanoseByteString(data[54], data[63]); fdescr.setCapabilitiesStateFlags(new long[]{87901636}); fdescr.setCharBBoxesFromFile("/fonts/" + name); } else { throw new IOException ("No file found for " + name); } descr.setFontSpecificDataPartOneLength(-1); fdescr.setFirstCharacterIndexOfCompositeCIDRange(0); fdescr.setLastCharacterIndexIncludedForThisEncodingVector(255); fdescr.setItalicAngle(.0f); fdescr.setIsFixedPitchFlag(true); fdescr.setStrokeWeight(false); fdescr.setSymbolic(false); fdescr.setTextReturnModeHorizontalVerticalPositionedBackwardsCompatibleFalseTrueOrUnknown(false); fdescr.setHasToUnicodeMapping(true); fdescr.setTypographicLinegapOverride(.0f); fdescr.setVendorIdentifier(".notdef"); fdes

}