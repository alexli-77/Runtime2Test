package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public void testGetActionWithNullValueShouldReturnEmptyOptional() throws Exception { AnnotationUtils utils = new AnnotationUtils(); assertFalse("The optional should not contain a value", utils.getAnnotationActionsMapFromDictionary(new PDRectangle()).containsKey(ACTION)); }

}