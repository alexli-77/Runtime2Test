package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetType2ResourcesIsNullIfNotPresentInDic() throws IOException, InvalidPasswordException { PDFontDescriptor pdDesc = mock(PDFontDescriptor.class); when(fontProgram.getFontInfo()).thenReturn((Map<String, Object>)null); assertThat("should have no type2 resources", pdfont.getType2CharstringResource(), isEmpty()); verifyNoMoreInteractions(documentHandler); }

}