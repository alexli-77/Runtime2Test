package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetType2NullInput() throws IOException, BadPasswordException { PDTrueTypeFont ttf = new PDTrueTypeFont(); assertEquals("",ttf.getName()); assertFalse(ttf.isEmbedded()); assertNotNull(ttf.toPdfBoxFont().getBaseFont()); try { InputStream input = this.getClass().getResourceAsStream("/Helvetica-BoldOblique.otf"); ByteArrayOutputStream baos = new ByteArrayOutputStream(); IOUtils.copy(input,baos); byte[] bytes = baos.toByteArray(); PDFont pdffont = PDDocument.load(new java.io.ByteArrayInputStream(bytes)).getPage(0).findDescendantFont(); Assertions.fail("Expected IllegalArgumentException when passing bad data."); } catch (IllegalArgumentException e) {} }

}