package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetDate() throws IOException { PDDocument doc = new PDDocument(); try { PDFont font = PDType1Font.HELVETICA; String text = "2013-09-26"; addTextToPage("text", text, font, doc); Calendar calendar = doc.getPages().get(0).getTextAsStreamsUnderlyingCosObjects().get(0).asPDAction().getDate("/CreationDate"); assertEquals(new SimpleDateFormat("yyyyMMdd").parse(calendar.toString()), new Date()); } finally { IOUtils.closeQuietly(doc); } }

}