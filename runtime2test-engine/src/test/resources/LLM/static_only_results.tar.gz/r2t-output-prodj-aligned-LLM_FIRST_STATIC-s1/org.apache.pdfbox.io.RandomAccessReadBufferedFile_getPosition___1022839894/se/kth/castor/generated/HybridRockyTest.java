package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferedFileRockyTest {

@Test public void testGetPosition01() throws IOException, NoSuchAlgorithmException { InputStream is = new RandomAccessInputStream(new ByteArrayOutputStream()); assertEquals(-1L, ((RandomAccess)is).getPosition(), 0); }

@Test public void testGetPosition02() throws Exception { File f = createTempFile("test", "tmp"); try (PDDocument doc = PDDocument.load(f)) { PDFParser parser = new PDFParser((SeekableByteArrayDataSource)doc.getSource(), null); COSReader reader = parser.parse(); SeekableSubset randomaccessreader = new SeekableSubset(randomaccessbufferedinputstreamfactory.createBufferedInputSteamForReading(f), 5387694, -1); byte[] bb = new byte[3]; int rd = randomaccessreader.read(bb, 0, 3); assertTrue(rd > 0 && bb != null); String sss = UtilityMethods.decodeBytesToHexString(bb); System.out.println(sss + ";" + Integer.toUnsignedLong(UtilityMethods.bytesFromAsciiChars('R'))); assertNotNull(randomaccessreader); } finally { deleteTempFiles(); } }

}