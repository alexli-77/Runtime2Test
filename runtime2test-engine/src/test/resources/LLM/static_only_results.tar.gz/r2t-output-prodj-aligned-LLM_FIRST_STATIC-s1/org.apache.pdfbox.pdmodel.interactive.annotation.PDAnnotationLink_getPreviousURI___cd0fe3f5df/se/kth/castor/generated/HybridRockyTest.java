package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLinkRockyTest {

@Test public void testGetPrevUriNullPDActionNoExist() throws IOException { PDDocument doc1 = new PDFBoxResourceLoader().loadPDFDoc("/test-documents/input203794568.pdf"); assertEquals("",doc1.getActions()); }

}