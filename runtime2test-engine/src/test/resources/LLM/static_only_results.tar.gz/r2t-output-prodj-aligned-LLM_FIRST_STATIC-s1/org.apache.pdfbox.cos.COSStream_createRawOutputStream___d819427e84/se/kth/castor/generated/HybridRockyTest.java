package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

@Test public final void testCreateRawOutputStream() throws Exception { PDDocument doc = Loader.loadPDF(getFile()); try (PDPage page1 = new PDPage()) { PDAcroForm form = new PDAcroForm(doc); assertNotNull(form); doc.getDocumentCatalog().setAcroForm(form); doc.addPage(page1); byte[] expectedData = "Hello World".getBytes(StandardCharsets.UTF_8); try (InputStream input = new ByteArrayInputStream(expectedData)) { RandomAccess readBack = form.createRawOutputStream().toRAFOS().getSource(); IOUtils.copy(input, readBack); Assertions.assertEquals(readBack.size(), expectedData.length + 24L); } } finally { CloseQuietly.closeMultiple(doc, StandardSystemHandlers::SYSTEM_OUT); } }

}