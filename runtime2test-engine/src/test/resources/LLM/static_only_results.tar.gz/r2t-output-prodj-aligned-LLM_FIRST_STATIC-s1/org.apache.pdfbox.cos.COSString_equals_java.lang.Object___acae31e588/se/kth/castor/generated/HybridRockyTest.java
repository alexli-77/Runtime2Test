package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStringRockyTest {

@Test public void testEqualsWithNonCosStringReturnFalse() throws Exception { assertThat("This should be equal", cosStringA, is(equalTo(cosStringB))); }

}