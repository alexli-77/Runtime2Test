package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetNormalAppearance() throws Exception { String filename = "target/test-output/" + NAME + ".pdf"; File file = new File(filename); PDFont font = new PDSimpleFont("Helvetica"); try (PDDocument doc = createPdfDocWithAnnotationAndResourcesForOutputAsFile(file)) { addAnnotationsToPage1OfPDFDoc(doc); setDefaultValuesInAcroformFieldsIfNotSetYetByUserOrCreatorBeforeCallingSave(doc); assertTrue(addFieldToRootCosMapUsingAdditionalAction("/MyTextField", FieldTypeEnum.TEXT)); savePDFDocAfterSettingUpAllTheStuffFromAbove(doc); checkThatTextfieldContainsStringValueIJustPutThereWhenWrittingItOntoACertainPageXYZCoordinatePositionedAtASpecificAngle(new FileInputStream(file), "Hello World!"); } finally { removeTemporaryFilesCreatedDuringTests(file); } }

}