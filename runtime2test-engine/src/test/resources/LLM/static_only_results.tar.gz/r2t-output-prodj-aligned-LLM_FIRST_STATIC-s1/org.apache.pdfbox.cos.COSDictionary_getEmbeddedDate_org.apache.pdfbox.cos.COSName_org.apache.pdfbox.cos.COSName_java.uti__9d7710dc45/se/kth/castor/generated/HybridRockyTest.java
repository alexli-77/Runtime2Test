package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetEmbeddedDate() throws Exception { PDDocument document = new PDDocument(); try { PDCatalog catalog = createCatalogWithNestedDict("test", "date"); assertNotNull(catalog.getEmbeddedDate(PDDestination.NAME_PARENT_KEYWORD_DICTIONARY, COSEntries.TYPE_ARRAY, new Calendar())); fail("Expected exception."); } finally { closeQuietly(document); } }

}