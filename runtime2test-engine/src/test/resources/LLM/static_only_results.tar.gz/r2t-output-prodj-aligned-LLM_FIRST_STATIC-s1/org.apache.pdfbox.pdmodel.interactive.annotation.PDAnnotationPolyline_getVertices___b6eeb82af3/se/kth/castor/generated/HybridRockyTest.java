package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public void testGetSetVertices() throws IOException, COSVisitorException { int count = 1024 + new Random().nextInt(); PDLineTo line = new PDLineTo((float) (Math.random()), (float) Math.PI / 8f); for (int i = 0; i < count - 3; ++i) { if ((new Random()).nextBoolean()) { line.setXPosition(line.getXPosition() + .5f); } else { line.setYPosition(line.getYPosition() + .5f); } assertEquals("" + i, line.getNumberOfSegments(), i % 2 == 0 ? 2 : 1); } String expectedStringRepresentation = "[" + Float.toString(line.getStartPoint().x) + "," + Float.toString(line.getEndPoint().y) + ", [" + Integer.toString(count - 3) + "]]"; assertTrue("Expected string representation is not correct.", line.toString().startsWith(expectedStringRepresentation)); }

}