package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetEmbededInteger() throws IOException { PDDocument document = new PDFParser().parse("testdata/hello.pdf"); assertEquals(204856397, document.getTrailer().getLong(PDPageTree.PAGES).intValue()); assertNotNull(document.getMetadata()); assertTrue(!document.isEncrypted()); assertFalse(document.hasSecurityHandler()); }

}