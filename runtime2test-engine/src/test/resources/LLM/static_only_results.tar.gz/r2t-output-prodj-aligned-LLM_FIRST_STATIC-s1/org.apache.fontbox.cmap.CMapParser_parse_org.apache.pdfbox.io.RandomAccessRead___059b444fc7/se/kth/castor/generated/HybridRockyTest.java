package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapParserRockyTest {

@Test public void testParse() throws Exception { String resourceFilename = "/resources/test-data/unicode/AdobeIdentitySymbolEncoding.cmap"; try (InputStream inputStream = getClass().getResourceAsStream(resourceFilename)) { org.junit.Assert.assertNotNull(inputStream); org.apache.fontbox.cmap.CMap cidToUnicodeMapping = parserUnderTest.parse(new RandomAccessBufferedFileInputStream(inputStream)); for (int i = 0xF135 ; i <= 0xFFFF; ++i ) { char character = Character.toChars(i)[0]; int unicodeValue = Integer.parseInt(String.valueOf(character), 16); assertEquals("The value '" + unicodeValue + "' was expected but not found", unicodeValue , cidToUnicodeMapping.lookupCharCode(i).intValue()); } } catch (Exception e){ throw e;} }

}