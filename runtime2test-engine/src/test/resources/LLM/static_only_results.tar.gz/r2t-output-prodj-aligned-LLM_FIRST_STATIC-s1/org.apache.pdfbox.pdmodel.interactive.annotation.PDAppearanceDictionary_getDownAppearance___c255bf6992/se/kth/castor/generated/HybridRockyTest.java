package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceDictionaryRockyTest {

@Test public void testGetRolloverAndUpAppearancesWithNoKeys() throws Exception { assertEquals("Expected empty", true, annotation.getNormalAppearance().isEmpty()); assertNull("Didn't expect a rollover apprearance.", annotation.getRollingOverAppearance()); }

}