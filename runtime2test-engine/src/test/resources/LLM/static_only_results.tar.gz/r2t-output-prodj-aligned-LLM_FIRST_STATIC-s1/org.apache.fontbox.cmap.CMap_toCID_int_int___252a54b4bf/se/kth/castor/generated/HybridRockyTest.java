package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapRockyTest {

@Test public void testToCID() throws IOException { assertEquals("tocids", new Integer(4), pdfEncodingDictionary.toCID('a', 'b')); }

}