package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testGetScalingFactorY() throws Exception { assertEquals("Wrong result", 1f, mtrxA.getScalingFactorX(), 0); assertEquals("Wrong result", -657892.5306f, mtrxB.getScalingFactorX(), 0); assertEquals("Wrong result", 1f, mtrxC.getScalingFactorX(), 0); assertEquals("Wrong result", 0.8f, mtrxD.getScalingFactorX(), 0); assertEquals("Wrong result", 0.4f, mtrxE.getScalingFactorX(), 0); assertEquals("Wrong result", 0.2f, mtrxF.getScalingFactorX(), 0); }

}