package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetEmbeddedString() throws Exception { assertEquals("a", dic1.getEmbeddedString(CosStandardObjects.TYPE, CosNames.NAME), "Expected 'a'"); assertNull(dic2.getEmbeddedString(null, CosNames.NAME), "Didn't expect anything for this one"); assertNotNull(dic3.getEmbeddedString(CosStandardObjects.RESOURCES, CosNames.PROCSSET), "We should have something here."); assertTrue(!dic4.getBooleanItem(CosStandardObjects.ENCRYPT).booleanValue(), "This shouldn't happen!"); }

}