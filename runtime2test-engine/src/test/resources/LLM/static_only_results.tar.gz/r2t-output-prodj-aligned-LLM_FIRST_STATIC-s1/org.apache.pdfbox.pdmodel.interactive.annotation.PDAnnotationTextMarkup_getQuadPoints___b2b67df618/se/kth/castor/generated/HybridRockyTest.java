package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationTextMarkupRockyTest {

@Test public void testGetSetRectangleDifferencesWithNullValuesInConstructor() throws Exception { HighlightAnnotation highlightAnnot = new PdfBoxHighLight(); assertNotNull("There should be a rectangle", highlightAnnot.getRect()); }

}