package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationCaretRockyTest {

@Test public void testSetRectDifferences() throws IOException { PDAcroForm acroform = document.getDocumentCatalog().getAcroForm(); Assertions.assertNull("There should be no differences",acroform.getField("test").getAnnotationDictionary().getItem(PDRadius.RECTDIFFERENCES), null ); }

}