package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

@Test public final void testGetFilteredDataWithFiltersAndEncryption() throws Exception { byte[] expected = "\u25B6\n".getBytes("UTF-8"); String pdfText = PDDocument.load(testUtils.openResourceAsStream("/encrypted/LZWDecryptorTestFile1.pdf")).getPage(0).getText().trim(); assertEquals("\u25b6", Character.toString((char)(int)'◆')); ByteArrayOutputStream output = new ByteArrayOutputStream(); try (PDIncrementalStamper stamper = new PDIncrementalStamper()) { COSDictionary dictionary = stamper.getOriginalCosObjectFactory().createDict(); dictionary.setDirect(true); dictionary.put("Type", COSBase.constantStringValueForName("XRef")); OutputStream filteredOutput = stamper.createUncompressedPDFCopyOfSourceDocumentsExcludePreviousContents(output, dictionary, false, true); filteredOutput.write('\r'); filteredOutput.flush(); byte[] actual = output.toByteArray(); for (byte b : expected) { AssertionsHelper.assertContainsAtLeastOneEqualElement(actual[expected.indexOf(b)] & 0xff , b & 0xff ); } // TODO: Why are we testing with \u25b6? It should have been replaced by '>' according to https://www.unicode.org/Public/MAPPINGS/VENDORS/ADOBE/LATIN1.TXT but it's not in LATIN1.TXT either so I don't know why it was used here. This can probably be removed once the issue #437 has been resolved and then reenabled again when that's fixed. assertTrue(!Character.valueOf('ꀁ').equals(Character.valueOf('\u25b6'))); assertFalse(CharMatcher.ascii().matchesAllOf(pdfText),"ASCII characters found in encrypted file"); } catch (@SuppressWarnings("unused") IllegalArgumentException e) {} }

}