package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetCosArrayForNonExistingEntryReturnNull() throws Exception { assertThat("Didn't expect an array", fontDescObj.getCOSArray(new PDType1Font().getName()), is((nullValue()))); }

}