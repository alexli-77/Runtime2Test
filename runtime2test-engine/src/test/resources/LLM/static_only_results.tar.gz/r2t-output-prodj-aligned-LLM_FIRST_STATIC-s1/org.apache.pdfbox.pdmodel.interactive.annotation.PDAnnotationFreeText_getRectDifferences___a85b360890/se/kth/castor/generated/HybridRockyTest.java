package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationFreeTextRockyTest {

@Test public void testGetRectDifferencesNoMarginSet() throws Exception { Annotation annotation = createAnnotation(); assertEquals("wrong number of rect diff",0,annotation.getRectDifferences().length); }

}