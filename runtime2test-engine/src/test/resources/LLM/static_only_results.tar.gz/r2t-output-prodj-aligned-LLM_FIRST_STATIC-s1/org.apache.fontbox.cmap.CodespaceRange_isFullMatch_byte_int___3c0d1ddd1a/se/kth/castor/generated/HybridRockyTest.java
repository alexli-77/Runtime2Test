package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CodespaceRangeRockyTest {

@Test public void testIsFullMatch() throws Exception { CodespaceRange c1 = new CodespaceRange("00", "9A"); assertTrue(c1.isFullMatch(new byte[]{}, 2)); assertFalse(c1.isFullMatch(null, null)); assertEquals(-375684337, c1.hashCode()); assertNotSame(c1, new Object()); assertNotNull(c1); String s = ""; StringBuilder sb = new StringBuilder(); Formatter formatter = new Formatter(sb); CodeSpace cs = new CodeSpace((short)-1); ByteArrayOutputStream baos = new ByteArrayOutputStream(); DataOutput out = new DataOutputStream(baos); cs.writeToStream(out); try { c1.toPdf(formatter, PDMode.PDFX4); fail("must not happen"); } catch (IOException e) {} assertEquals("/CIDSystemInfo\n" + "<</Registry (Adobe)\n" + "/Ordering (Identity-H)\n" + "/Supplement 0\n" + "/Version 0\n" + "/FontName /Helvetica\n" + "/Registries ([Adobe\\ Registry]) >> setpagedevice\n" + "[/Adobe//UCS]\n" + "(identity-h)\n<<\n" + "\tstartcodespacerange [<00> <FF>\n" + "   <FE><FA><FB><FC><FD><F0><E0><ED][<B0><BF>[<AC><AE>]]>> \n" + "endcodespacerange <<\n" + "</preamble>\n" + "currentdict begin\n" + "/charprocs known {\n" + "/Encoding ISOLatin1Encoding def currentdict dup /WMode 0 def EndPage { pop showpage }\ndef PageBegin{ 0 beginpagesave restoreuserstate savegraphicstate SavePageEnd { showpage restoregraphicsstate } binddef SetCharWidthAndSetSpacing { dup where exch findfont 0 eq {pop .notdef}{dup type /arraytype get =={exch index readhexstring pop}\n/nametype get == {findresource loadname}}ifelse cvx execwidth pop widthshow }binddef CharProcs

}