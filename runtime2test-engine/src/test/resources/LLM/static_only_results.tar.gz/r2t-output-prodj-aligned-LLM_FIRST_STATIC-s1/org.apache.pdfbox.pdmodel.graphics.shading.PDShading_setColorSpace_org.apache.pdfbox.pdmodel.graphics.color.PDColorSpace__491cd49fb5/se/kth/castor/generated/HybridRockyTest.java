package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDShadingRockyTest {

@Test public void testSetColorSpace() throws IOException { PDShadingType1 typeOne = new PDShadingType1(); assertNull("The default should be null",typeOne.getColorSpace()); typeOne.setColorSpace(new org.apache.pdfbox.pdmodel.graphics.color.PDRGB()); assertNotEquals("Should not be equal to null.",null,typeOne.getColorSpace()); }

}