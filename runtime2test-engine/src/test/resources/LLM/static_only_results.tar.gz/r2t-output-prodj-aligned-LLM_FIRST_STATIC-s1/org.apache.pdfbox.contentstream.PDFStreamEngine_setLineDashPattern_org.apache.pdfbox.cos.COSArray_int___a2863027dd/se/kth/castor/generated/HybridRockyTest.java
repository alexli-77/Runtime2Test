package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFStreamEngineRockyTest {

@Test public final void testSetLineDashPattern() throws IOException { PDPainter painter = this; assertNotNull("painter should not be null", painter); }

}