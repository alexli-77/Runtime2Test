package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testEquals() throws Exception { PDAnnotation annotation1 = new PDAnnotationText((COSStream) null); assertTrue("The annotations should be equal", annotation1 .equals(new PDAnnotationText())); COSDictionary dictionary2 = new COSDictionary(); annotation1 = new PDAnnotationText(dictionary2, 0, 0, 100, 50); assertFalse("These two objects shouldn't have the same hash code and thus not be considered as equal by their overridden 'hashCode'. But they do.", annotation1 .equals(new PDAnnotationText())); }

}