package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetKeyForValue() throws Exception { COSDictionary dict = new COSDictionary(); assertThat("A dictionary should have no keys",dict.keySize(),equalTo(0)); dict.put("a","b"); assertThat("After adding a single item we expect one key",dict.keySize(), equalTo(1)); dict.removeItem("a"); assertThat("Removing an item removes all references of this object from the dictionary",dict.containsKeyAndMaybeInsideSubtree("a"), is(false)); COSBoolean obj2 = new COSBoolean(true); assertThat("Another boolean object with same content shouldn't be found as its identity changed.", dict.getKeyForValue(obj2),nullValue()); }

}