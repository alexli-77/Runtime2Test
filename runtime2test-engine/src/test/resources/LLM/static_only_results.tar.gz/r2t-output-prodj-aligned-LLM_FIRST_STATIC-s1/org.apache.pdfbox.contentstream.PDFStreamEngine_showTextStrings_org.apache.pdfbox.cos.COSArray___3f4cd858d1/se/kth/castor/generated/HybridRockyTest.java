package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFStreamEngineRockyTest {

@Test public void testShowTextStringsWithSpacingAdjustmentsNoSpaceAfter() throws Exception { PDPage page = new PDPixelMap(); PDFont pdFont = loadPdFont("/fonts/Helvetica"); assertNotNull(page); assertTrue(!page.containsKey(new COSObjectable[]{})); try (OutputStream out = page.createContentStream()) { contentStreamWriter.setContext(out); ContentStreamWriterTokenizer tokenizer = createMockedTokenizerForOperatorsAndValues(OPERATORNAME_BEGININLINEIMAGEWITHSPACINGADJUSTMENTS, OPERANDTYPE_ARRAY, "500 g", "324 -6897 -1392 -3220 SQ\n" + "\r" + "/Courier-Oblique findfont  30 scalefont setfont     \n" + "[ 2 ] 0 dtransform             Tm      [(\uFFFD)\'\\n] TJ                       ", "showtextstringswithspacingadjustments", OPERATORDRAWOBJECTVALUE, "EI "); replayAll(); List<Operator> operators = streamEngineUnderTest.processSubStream(tokenizer).toList(); verifyAll(); Assertions.assertThatCode(() -> { final Operator operator = operators.iterator().next(); final Object operand = operator.getArguments().iterator().next(); final String actualResult = CharMatcher.invisible().removeFrom(operand == null ? "" : operand.toString()); MatchersAssert.assertThat(actualResult, CoreMatchers.equalToIgnoringCase("\ufffd")); }).doesNotThrowAnyException(); } catch (final Throwable e) { throw new RuntimeException(e); } }

}