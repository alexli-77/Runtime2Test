package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetCIDSetWithNoValueShouldReturnNull() throws Exception { assertThat("Expected value", subjectUnderTest.getCIDSet(), IsEqual.<Object>equalTo((null))); }

}