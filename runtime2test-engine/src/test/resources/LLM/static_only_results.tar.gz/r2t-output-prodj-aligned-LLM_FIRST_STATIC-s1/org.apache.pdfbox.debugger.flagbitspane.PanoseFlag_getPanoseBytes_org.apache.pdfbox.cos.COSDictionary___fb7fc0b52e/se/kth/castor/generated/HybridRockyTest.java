package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PanoseFlagRockyTest {

@Test public void testGetCosNumber() throws IOException, URISyntaxException { File file = new ClassPathResource("fonts/ttf/Arial-BoldItalicMT-32bit.otf").getFile(); try (PDDocument doc = PDDocument.load(file)) { PDFont font = loadFontFromPDFBoxDoc(doc).orElseThrow(() -> new IllegalStateException()); assertEquals((float)font.toUnicode("a"), (char)'a'); } }

}