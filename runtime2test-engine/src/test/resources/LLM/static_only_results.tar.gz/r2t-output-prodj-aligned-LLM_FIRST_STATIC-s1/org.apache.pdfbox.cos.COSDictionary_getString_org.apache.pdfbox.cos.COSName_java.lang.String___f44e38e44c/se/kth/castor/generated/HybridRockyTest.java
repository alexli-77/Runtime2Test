package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetString() throws Exception { COSDocument doc = new COSDocument(); PDDestination dest1 = createDestWithType("XYZ", "test"); PDDestination dest2 = createDestWithType("FitH", "test"); PDSignature signature = addSignatureToDocumetn(doc); assertEquals(null, signature.getFieldMDP()); String s = signature.toString().replaceAll("\r\n?|\n|\\t","").trim(); Assertions.assertTrue((dest1 + "\n" + dest2).equalsIgnoreCase(s)); doc.close(); }

}