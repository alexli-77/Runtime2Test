package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSObjectKeyRockyTest {

@Test public void testEquals() throws Exception { assertTrue("equal", new COSObjectKey(1, 0).equals(new COSObjectKey(1, 0))); }

@Test public void testNotEqualNumberDiffers() throws Exception { assertFalse("not equal because of different numbers", new COSObjectKey(2, 0).equals(new COSObjectKey(3, 0))); }

@Test public void testNotEqualGenDifferes() throws Exception { assertFalse("not equal because of generation differs", new COSObjectKey(1, 578964).equals(new COSObjectKey(1, 578965))); }

@Test public void testNullIsNotAValidInputForEqualityChecking() throws Exception { assertFalse("null is not a valid input for equality checking", new COSObjectKey().equals((COSBase) null)); }

}