package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessInputStreamRockyTest {

@Test public void testSkip() throws IOException { InputStream in = new ByteArrayInputStream("123456789".getBytes()); RandomAccess readInput = new ReadRandomAccessFile(in, "rw"); assertEquals(-1L, readInput.skip(-1)); assertEquals(Long.MAX_VALUE - 1, readInput.skip((long)(Integer.MAX_VALUE * Math.random())), 0d); for (int i = 0; i < Integer.MIN_VALUE / 2; ++i) { int bytesToRead = randomizer.nextInt(Byte.SIZE + 1); byte[] buffer = new byte[bytesToRead]; readInput.readFully(buffer); String expectedString = Arrays.toString(buffer).substring(1, buffer.length - 1); assertEquals(expectedString, readInput.getStringFromPosAndLength(positions.peek(), bytesToRead).trim().replaceAll("\r", "\n")); positions.push(positions.pop() + bytesToRead); pos++; } }

}