package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testIsEndOfFileTrueWhenPointerEqualsSizeAndNotAtBeginning() throws IOException, InterruptedException { assertThat(stream.isEOF(), equalTo(true)); stream.seek(-1); assertThat(stream.read(), notNullValue()); assertFalse("Should be false", stream.isEOF()); }

}