package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SecurityHandlerRockyTest {

@Test public void testEncryptString() throws Exception { String s1="This is some sample text."; byte[] b1 = s1.getBytes("UTF-8"); PDStandardSecurity sec2 = (PDStandardSecurity) doc.getDocumentCatalog().getACroSDictionary().setFilterName("Adobe.PubSec", "V4").getDictionaryObject(PDSignature.DIGEST_METHOD_KEYWORD).asStream().getDecodedContentsAsPDFTextStripper().getTextForPage(-1).toString().substring(360 + 59).replaceAll("\n","").trim().getBytes("ISO-8859-1"); assertEquals(sec2[7],'e'); }

}