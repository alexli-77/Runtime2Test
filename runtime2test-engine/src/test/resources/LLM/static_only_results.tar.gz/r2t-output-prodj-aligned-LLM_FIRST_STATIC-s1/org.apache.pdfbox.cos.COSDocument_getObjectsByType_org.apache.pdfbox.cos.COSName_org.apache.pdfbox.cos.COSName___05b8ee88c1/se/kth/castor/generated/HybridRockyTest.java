package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDocumentRockyTest {

@Test public void testGetObjetsByTypes35098764() throws Exception { PDDocument doc = Loader.loadPDF("cannot-parse-and-reproduce-issue-from-user"); COSDictionary rootDict = doc.getDocument().getTrailer(); List<? extends COSBase> dictStreamArray = ((PDDictionary)rootDict.getItem("Root")).getDirectKidsAsListOfCosObjs(); assertEquals(dictStreamArray.toString(), "[[true], [false]]", dictStreamArray.toString()); }

}