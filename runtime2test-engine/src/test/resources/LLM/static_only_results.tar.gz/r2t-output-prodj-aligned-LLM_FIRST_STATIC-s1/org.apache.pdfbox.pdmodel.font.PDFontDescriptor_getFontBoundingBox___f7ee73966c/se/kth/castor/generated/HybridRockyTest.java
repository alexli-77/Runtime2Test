package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFontBoundingBox() throws IOException { try (InputStream inputStream = PDType0Font.class .getResourceAsStream("PDCIDFont-IdentityH.pfb")) { PDFont font = FontFactory.createFont(inputStream, "Cp1252"); assertTrue(font instanceof PDSimpleFont); assertNotNull(((PDSimpleFont) font).getBaseFont()); assertEquals(-769, ((PDSimpleFont) font).getDescent(), EPSILON); assertEquals(834, ((PDSimpleFont) font).getAscent(), EPSILON); assertFalse(((PDSimpleFont) font).isItalic()); assertFalse(((PDSimpleFont) font).isSerif()); assertEquals(false, ((PDSimpleFont) font).hasKerningInfo()); assertEquals(new java.awt.geom.Point2D.Float(.5f,.5f), ((PDSimpleFont) font).getUnderlinePosition()); assertEquals(new java.awt.geom.Point2D.Float(.5f,.5f), ((PDSimpleFont) font).getStrikelinePosition()); assertEquals(null, ((PDSimpleFont) font).getWidthFromCMap(".notdef")); assertEquals(true, ((PDSimpleFont) font).embedded); assertNotNull(((PDSimpleFont) font).toUnicode); assertEquals("WinAnsiEncoding", ((PDSimpleFont) font).encodingScheme); assertNotNull(((PDSimpleFont) font).cmapToUnicode); assertEquals(false, ((PDSimpleFont) font).containsCodePoints(Collections.<Integer>emptySet())); assertEquals(false, ((PDSimpleFont) font).containsGlyphNames(Collections.<String> emptyList())); assertEquals(new int[]{}, ((PDSimpleFont) font).getCharacters().stream().sorted().distinct().collect(Collectors.toList()).toIntArray()); } catch (IOException e) {} fail(); }

}