package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCOSDict() throws IOException { PDDocument doc = new PDDocument(); PDFont font = PDType1Font.HELVETICA.createFont(); assertTrue("Should have set Helvetica as default", font.getBaseFont().equals("/Helv")); doc.close(); }

}