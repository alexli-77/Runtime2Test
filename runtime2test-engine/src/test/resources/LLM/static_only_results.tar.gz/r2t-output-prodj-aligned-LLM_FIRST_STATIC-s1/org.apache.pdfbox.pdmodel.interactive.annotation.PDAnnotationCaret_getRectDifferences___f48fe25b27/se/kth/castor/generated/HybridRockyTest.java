package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationCaretRockyTest {

@Test public void testGetRectDifferencesWithNoMarginSetShouldReturnEmptyArray(){ assertEquals("",0, underTest.getRectDifferences().length ); }

}