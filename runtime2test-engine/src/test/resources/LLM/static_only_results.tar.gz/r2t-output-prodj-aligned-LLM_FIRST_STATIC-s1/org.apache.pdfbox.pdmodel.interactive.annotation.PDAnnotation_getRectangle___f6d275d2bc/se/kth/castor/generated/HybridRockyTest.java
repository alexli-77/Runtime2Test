package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetCosFloatArrayReturnNullForNonExistentKey() throws Exception { assertThat(testSubject.getCOSFloatArray(new org.apache.pdfbox.cos.COSName("foo"))).isEqualTo(null); }

}