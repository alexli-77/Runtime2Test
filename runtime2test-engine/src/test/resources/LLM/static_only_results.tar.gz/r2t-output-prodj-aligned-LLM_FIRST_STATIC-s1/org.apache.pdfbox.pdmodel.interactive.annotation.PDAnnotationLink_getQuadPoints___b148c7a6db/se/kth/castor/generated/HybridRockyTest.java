package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLinkRockyTest {

@Test public void testGetSetQuadPoint() throws IOException, COSLoadException { PDAnnotationWidget widget1 = new PDAnnotationText(); Assert.assertNull("Default value is null",widget1.getQuadPoints()); Float[] fvalues = { 0f , 234567890.123456F }; widget1.setQuadPointsAsString(new String[]{ "[" + (float)MathUtils.roundUpToNearestHundredth((double)(-5))+","+(float) MathUtils.roundDownToEvenDigit(-2)+"]" }); assertEquals(widget1.toString(), "[null]"); widget1.setRectangle(new PDRectangle(10, 10)); widget1.setPageRotation(90); PDFont font = FontManagerImpl.getInstance().getStandardFont(PDType1Font.TIMES_ROMAN,"Cp1252", false).font; int rotationAngle = RotatedImageBuilder.calculatePDFRendererOrientationFromMatrixAndDimensions(matrixForNewSizeOfRenderedElementWithGivenWidthHeightIncludingMargin(rotationAngles[i], width, height), width, height); double angleRadians = Math.PI / 180d * (int)(rotationAngle % 360); AffineTransform at = AffineTransform.getTranslateInstance(xOffset - xOriginShiftByXDirection, yOffset -yOriginShiftByYDirection ) .concatenate(AffineTransform.getScaleInstance(scaleRatio, scaleRatio)).rotate(angleRadians ); try{ BufferedImage bi = renderer.render(at, glyphList, textPositioningStrategy, true, textStateParameters); }catch(IOException e){ throw e;} catch(RuntimeException re ){ fail("Failed to draw and create image for given data."); } Matrix matrixAfterDraw = ((BufferedImageOp)op).getMatrixBeforeOperation(); Rectangle2D boundsAfterDraw = op.getBounds2D(matrixAfterDraw); if(!boundsAfterDraw.contains(textPositions[j]))fail("The drawn area does not contain the position where we drew it!"); }

}