package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testToCosStringStringList1() throws Exception { List<String> result = cosArray.toCOSStrings(""); assertEquals(2,result.size(), "Expected two strings."); String expected[] = {"",""}; for ( int idx = 0 ;idx < result.size(); ++idx ) { assertTrue(expected[idx].equalsIgnoreCase(result.get(idx)), "Strings do not match!"); } }

}