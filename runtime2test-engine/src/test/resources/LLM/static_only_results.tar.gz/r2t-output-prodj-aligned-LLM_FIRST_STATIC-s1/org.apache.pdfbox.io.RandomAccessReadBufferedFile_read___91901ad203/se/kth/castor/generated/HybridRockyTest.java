package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferedFileRockyTest {

@Test public void testGetPositionInBytesOfFirstByteOnNextLineAfterNewlineCharIsReturnedAsOneIfNoSuchCharacterExistsAtTheEndOfStream() throws Exception { final String content = "This is a text line.\n"; assertEquals("The position of the first character after newline in last line should be one.", 1, new PDFTextStripper().getTextPositionsForSingleWordAndCountLinesFromContent(content).lastEntry().getValue()); }

@Test public void testGetPositionInBytesOfLastByteBeforeNewlineCharIsZeroWhenThereAreOnlyEmptyLinesSeparatedByAFormFeedCharacterThatHasNotBeenConsumedYet() throws Exception { final String content = "\f\r\n" + // Windows-style EOL sequence with form feed before it and an empty line afterwards that has not yet been consumed by stripping off trailing CR characters.
            "\u2028\r\n"; List<Map.Entry<String, Integer>> resultList = new ArrayList<>(); for (final Map.Entry<String, Integer> entry : new PDFTextStripper().getTextPositionsForMultipleWordsAndCountLinesFromContent(content)) { System.out.println(entry.toString()); resultList.add(new AbstractMap.SimpleImmutableEntry<>((char)(int)' '+entry.getKey(), entry.getValue())); } Assertions.assertIterableContainsSubset(Arrays.asList(resultList), Arrays.asList(new HashMap.SimpleImmutableEntry<' ',Integer>(3))); }

}