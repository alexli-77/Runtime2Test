package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetInt() throws IOException { PDDocument doc = new PDDummy().createPDFDocumnetWithACosArrayAsRootElement(); assertEquals(-1052684379L,doc.getPage(0).getResources().getFont("F").asDictionary().getInteger("FirstChar")); }

}