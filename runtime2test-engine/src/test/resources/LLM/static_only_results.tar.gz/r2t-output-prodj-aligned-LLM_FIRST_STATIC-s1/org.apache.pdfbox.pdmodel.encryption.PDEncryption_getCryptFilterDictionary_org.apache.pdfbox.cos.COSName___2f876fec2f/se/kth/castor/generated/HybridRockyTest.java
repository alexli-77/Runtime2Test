package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDEncryptionRockyTest {

@Test public void testGetString() throws Exception { PDDocument document = new PDDummy(); Assertions.assertEquals("", document.getStringValue()); }

}