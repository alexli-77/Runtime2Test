package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceEntryRockyTest {

@Test public void testGetSubDictioanry() throws Exception { PDAnnotationWidget widget = createSampleAcroForm().getField("textfield").getWidget(); assertTrue("/Annot".equals(widget.getName())); COSArray array = (COSArray) ((PDDictionary) widget).item("AP", "N"); COSDictionary dictionary = (COSDictionary) array.getObject(0); COSBase base = dictionary.getItem(new COSName("Off")); assertNotNull(base); assertEquals(COSInteger.ZERO, base); }

}