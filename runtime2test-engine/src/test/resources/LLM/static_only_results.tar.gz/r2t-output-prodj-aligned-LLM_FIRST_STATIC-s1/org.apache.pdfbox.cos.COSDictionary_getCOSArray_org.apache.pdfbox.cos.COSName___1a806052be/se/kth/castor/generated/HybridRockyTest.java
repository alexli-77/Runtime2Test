package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCosString() throws IOException, URISyntaxException { try (PDDocument doc1 = Loader.loadPDF(new File("target", "test-input235074689.pdf"))) { PDPage page1 = doc1.getPages().get(0); assertEquals("/Type /Font\n" + "/Subtype /TrueType\n" + "/BaseFont /Helvetica-BoldOblique\n" + "/Encoding /WinAnsiEncoding\n" + "/DescendantFontCount 1\n" + "\n" + ">>", page1.findResources().toString()); } }

}