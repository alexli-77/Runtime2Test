package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testGetScalingFactorX() throws Exception { AffineTransform at; for (int i : new int[]{45,-90}){at = MatrixUtils.createAffineTransform(i); assertEquals("getScalingFactorX", Math.abs((double)(new double[]{(3f),(-8)}).length), Math.abs((double)MatrixUtils.toArrayDouble(at)), .001d); }}

}