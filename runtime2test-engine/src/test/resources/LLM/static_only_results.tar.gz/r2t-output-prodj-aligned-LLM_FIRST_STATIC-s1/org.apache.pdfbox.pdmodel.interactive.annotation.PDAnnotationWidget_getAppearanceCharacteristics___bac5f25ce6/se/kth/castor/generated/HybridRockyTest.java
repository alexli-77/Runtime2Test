package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public void testGetAppearanceCharacteristics() throws Exception { PDAnnotationWidget widget = createDefault(); assertNull("There should be no Appearance Characteristic Dictionary",widget.getAppearanceCharacteristics()); }

}