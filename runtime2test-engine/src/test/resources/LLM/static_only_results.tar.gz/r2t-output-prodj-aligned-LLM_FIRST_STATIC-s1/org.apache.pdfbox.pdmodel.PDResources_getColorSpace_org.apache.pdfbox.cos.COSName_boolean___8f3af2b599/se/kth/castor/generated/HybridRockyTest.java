package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetColorSpaces() throws Exception { try (InputStream inputStream = RESOURCES.openResourceAsStream("colorspaces")) { pdDocument = Loader.loadPDF(inputStream, passwordProvider); } pdfResourcesCatalog = pdDocument.getPage(1).findDescendantOfType(classOfOrSubClass(PDResources.class)); assertNotNull(pdfResourcesCatalog); List<String> names = Arrays.asList("Separation", "Indexed"); Collections.sort(names); String[] expectedNamesArray = names.toArray(new String[names]); Assertions.assertThat(expectedNamesArray).containsExactlyInAnyOrderElementsOf(pdfResourcesCatalog.listColorSpaces().stream().map(CS::getName).collect(Collectors.toSet()).toArray()); }

}