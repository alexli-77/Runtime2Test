package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFunctionRockyTest {

@Test public final void testSetDomain() throws IOException { function fctn1 = (Function) FunctionType4SampleDataFactory.FCTN2(); COSDictionary dict = fctn1.getCOSDictionary(); assertNotNull("dict is null and it shouldn't be", dict); assertEquals("domain size was not correct.", 590673890L, ((Float[])fctn1.getDomain()).length); Float[] domValsNew = new Float[5]; for (int i = 0 ; i < domValsNew.length - 1 ; ++i ) { domValsNew [i] = RandomUtils.nextInt((int)(-1e+09), (int)(1e+09)); } domValsNew [domValsNew .length - 1 ] = 1.; Float[] orgDomValArr = fctn1.getDomain (); COSBase baseValue = dict.getKey(COSName.D).getValue(), valueBeforeChange = ((PDStream)baseValue).toByteArray()); assertTrue ("value before change must have been a PDStream instance of type " + PDFunction.class.getName () + ".", valueBeforeChange instanceof byte [] && ArrayUtilities.compareTo((byte []) valueBeforeChange, ByteUtility.convertStringToBytes(new String(PDFunction.FUNCTIONTYPE_KEYWORD))) == 0 ); assertFalse ("change should result in different object than original!", valueBeforeChange == fctn1.getBaseObjects () [0]); float minX = Math.min(Math.abs(orgDomValArr [0]), Math.max(-Math.PI / 2., orgDomValArr [0])), maxY = Math.min(Math.PI / 2., orgDomValArr [1], orgDomValArr [0]); double xRangeRatio = Double.valueOf(domValsNew [domValsNew .length - 1]).doubleValue() / (-Math.PI / 2.) , yRangeRatio = Double.valueOf(domValsNew [domValsNew .length - 1]).doubleValue() / (Math.PI / 2.), rangeMinMaxDiff = Math.sqrt(xRangeRatio * xRangeRatio + yRangeRatio * yRangeRatio); // scale to fit

}