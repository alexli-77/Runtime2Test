package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HorizontalMetricsTableRockyTest {

@Test public void testGetAdvanceWidth() throws IOException, FontFormatException { assertEquals("expected to be equal", 348, font.getAdvanceWidth('A')); }

}