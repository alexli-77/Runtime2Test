package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSNameRockyTest {

@Test public void testGetNameAsUtf8WithNonAsciiChars() throws Exception { PdfDictionary dict = new PdfDictionary(); ByteArrayOutputStream outStream = new ByteArrayOutputStream(); PdfWriter writer = new PdfWriter(outStream); Document doc = new Document(writer); PdfObject obj = new PdfNumber("4"); obj.put(PdfName.NAME, "test\uDCEC\uDD6E\uDBA1\uDCFC"); assertEquals("\ufffd", ((PdfLiteral)obj).getName()); }

}