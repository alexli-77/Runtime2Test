package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetItem2() throws Exception { assertNull("Should be no entry", dict.getItem((COSName)null)); assertEquals("Wrong value for " + COSName.COLORSPACE, colorSpaces[0], dict.getItem(COSName.COLORSPACE).getName()); COSSubsetDictionary subsetDict = new COSSubsetDictionary(); subsetDict.putAll(dict); assertNotNull("No entry found with both names in map but not as separate entries.",subsetDict.getItem(new COSArray())); assertTrue("Both values should match!", Arrays.equals(colorSpaces,subsetDict.values().toArray(new String[]{}))); }

}