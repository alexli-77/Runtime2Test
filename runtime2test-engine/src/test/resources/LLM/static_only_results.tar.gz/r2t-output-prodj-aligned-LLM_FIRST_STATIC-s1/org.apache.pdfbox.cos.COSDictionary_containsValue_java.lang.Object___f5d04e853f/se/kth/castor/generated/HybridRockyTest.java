package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testContainsValueCosNullPointerException1285409376() throws Exception { assertFalse("Should not contain", new COSDictionary().keySet().iterator().next().containsValue(null)); }

}