package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetFloat() throws Exception { PDFontDescriptorFontSpecification fs1 = new PDFontDescriptorFontSpecification("Arial", "Identity-H"); assertEquals(-0.6f, fs1.getFloat(PDFontDescriptorFontSpecification.KEY_ITALICANGLE), EPSILON); PDFontDescriptorFontSpecification fs2 = new PDFontDescriptorFontSpecification("Helvetica", "Italic") {{ setItem(PDFontDescriptorFontSpecification.KEY_ITALICANGLE, -954378F); }}; assertEquals(-0.6f, fs2.getFloat(PDFontDescriptorFontSpecification.KEY_ITALICANGLE), EPSILON); }

}