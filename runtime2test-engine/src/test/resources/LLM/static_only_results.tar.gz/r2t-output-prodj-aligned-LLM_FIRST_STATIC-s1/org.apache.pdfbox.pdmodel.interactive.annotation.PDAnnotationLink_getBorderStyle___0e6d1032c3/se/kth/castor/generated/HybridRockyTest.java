package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLinkRockyTest {

@Test public void testGetLineWidth01(){PDAnnotationMarkup annotation = new PDAnnotationText(); assertNull("The default value for a Line Width shall be 0", annotation.getBorderStyle()); }

}