package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testReadEOF() throws IOException, NoSuchFieldException, IllegalAccessException { ByteArrayInputStream byteStream = new ByteArrayInputStream("Hello World".getBytes()); PdfReader pdfReaderMocked = PowerMockito.mock(PdfReader.class); WhiteboxImpl.setInternalState(byteStream,"stream",new RandomAccessFileOrArray(null)); InputSource inputSourceMocked = Mockito.spy((InputSource)(ByteArrayInputStream)byteStream); doReturn(inputSourceMocked).when(pdfReaderMocked).createCopierForExternalObject(); try (RandomAccessBuffer randomAccessBuffer = new ReadableSeekableStreamAdapter(inputSourceMocked)) { Assertions.assertEquals(-1 ,randomAccessBuffer.read(),"Should have reached EOF"); } }

}