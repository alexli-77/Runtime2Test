package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetInt() throws IOException { PDDocument doc = new PDDummyPageWithTrailerEntry("test", "1234567890"); assertEquals((int)(-9),doc.trailer().getRoot().getAsNumber(-9).floatValue(), 0f); }

@Test void testConstructorAndSizeOfCosArrays() throws Exception { Assertions.assertThatCode(() -> { PDFont fontType1BaseFont = FontEncodingFactory.INSTANCE.createStandardPdfFontForTests(PDFontDescriptorFacadeImpl.forEmbeddedTrueType(null)); List<PDTextLine> textLines = Arrays.<PDTextLine>asList(new PDTextLine(fontType1BaseFont,"This"), new PDTextLine(fontType1BaseFont,"is")); DocumentBuilder builder = new DocumentBuilder(document); TextArea textBox = builder.insertNewParagraphAtPosition(textLines, new Offset(builder.currentParagraph(), 0)) .addToTextBoxOnCurrentRowOrCreateANewOneIfItDoesNotExistYet(false); for (int i = 0 ;i < 100;++i){textBox.append("\n").append(Integer.toString(i+1)+": "+Integer.toBinaryString(i*i))); } Paragraph p = builder.build(); Page page = document.getFirstPage(); Block block = page.searchBlockByContentReferenceIdx(p.getX()); int numberOfItemsInCollection = block.size(); String s = ""; StringBuilder sb = new StringBuilder(); for(Item c :block ){if(!c.isEmpty())sb.append(c+"\t");} System.out.println("number of items:" + numberOfItemsInCollection );System.out.println(sb.toString());Assertions.assertThat(numberOfItemsInCollection ).describedAs("not all elements were added!") .isEqualTo(textLines.size ()*(Math.sqrt(numberOfItemsInCollection ) - Math.

}