package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCosString() throws IOException { PDDocument doc = new PDFParser().parse("target/test-data/" + filename, new MemoryUsageSetting(-1L), true).getPDDocument(); try (PDPage page = new PDPage()) { assertEquals("Hello World", page.findNonNullEntryInTreeOrAncestors("/Parent").asDictionary().getCOSString(new COSSymbolTable())); } finally { IOUtils.closeQuietly((Closeable)doc); } }

}