package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetLL(){ LineAnnotation ll = new LineAnnotation(); Assert.assertNull("no COS object",ll.getCosObject()); ll.setCosObject(new PdfDictionary()); Assert.assertNotNull("null cos object",ll.getCosObject()); }

}