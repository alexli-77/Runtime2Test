package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationSquareCircleRockyTest {

@Test public void testGetBorderEffect2() throws Exception { PDAnnotationLine pdal = createAcroForm(); assertNull("The annotation does not have a Border Effect",pdal.getBorderEffect()); }

}