package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFontDescriptor() throws Exception { COSDocument doc = new COSDocument(); PDType1Font fd = new PDTTFont("Helvetica"); Assert.assertNotNull(fd.getBaseFont()); String basefontname = "Courier"; try (PDPage page = new PDPage()) { FontContainer container = new FontContainer((PDFontFactory)null,(PDCIDSystemInfo)null,doc,page); FDFontEncoding encoding = new StandardFDFontEncodings().forCode(basefontname).orElseThrow(() -> new RuntimeException("No standard encoding found")); Map<String, Object> params = new HashMap<>(); params.putAll(encoding.encodeParamsForEmbeddedSubset(fds[i])); int[] codeToByteMapping = ArrayUtils.toPrimitive(params.values().stream() .map(o -> o != null ? Integer.valueOf((int)(byte)o):Integer.valueOf(-1)) .filter(v-> v > -1 && v < 386 ) .sorted() .distinct() .collect(Collectors.toList())); byte[] bytesOfMappedCharsInOrderTheyAppear = IntStream.rangeClosed('a', 'z') .parallel() .map(c -> c >= 'A'?codeToByteMapping[(c & ~7)+ ('Z'-'A')] : codeToByteMapping[c&~7]).toArray(); assertEquals(new BigDecimal(bytesOfMappedCharsInOrderTheyAppear),container.getCharWidthMap().get(basefontname + "-" + i)); } }

}