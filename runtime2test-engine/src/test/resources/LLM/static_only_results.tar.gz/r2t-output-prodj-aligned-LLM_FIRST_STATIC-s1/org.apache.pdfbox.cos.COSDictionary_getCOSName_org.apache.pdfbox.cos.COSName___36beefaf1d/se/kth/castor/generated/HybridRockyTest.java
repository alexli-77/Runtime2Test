package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetCosName() throws Exception { PDDocument doc = new PDDummy().createDocWithOnePageAndFont("Arial", "Helvetica"); PDFont font1 = doc.getPages().get(0).findDescendantFontByTypeface("Helvetica"); assertThat(font1, instanceOf(PDFontDescriptorStandard.class)); String baseFontKeyword = "/BaseFont"; COSDictionary dict = ((PDStream)font1.getResource()).getContentsAsArray()[0].asDict(); assertEquals("/Times-Roman", dict.getNameItem(baseFontKeyword),"Wrong value for /BaseFont keyword."); }

}