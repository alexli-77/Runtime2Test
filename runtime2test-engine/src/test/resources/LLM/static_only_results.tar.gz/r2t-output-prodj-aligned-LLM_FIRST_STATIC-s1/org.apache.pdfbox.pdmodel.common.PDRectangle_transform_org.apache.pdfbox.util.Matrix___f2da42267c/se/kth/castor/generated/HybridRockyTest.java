package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDRectangleRockyTest {

@Test public void testTransform() throws Exception { Rectangle r = new Rectangle(-5f,-9f ,8f, -7f ); Matrix mtx = new AffineTransform().rotate(.5).scale(1,.5 ).translate(2, .5f ).createAffineTransformer().buildTransform(); GeneralPath gpath = r.toPath(mtx); assertTrue("Expected result is "+gpath+" but actual was "+r.transform(mtx)+"", false); }

}