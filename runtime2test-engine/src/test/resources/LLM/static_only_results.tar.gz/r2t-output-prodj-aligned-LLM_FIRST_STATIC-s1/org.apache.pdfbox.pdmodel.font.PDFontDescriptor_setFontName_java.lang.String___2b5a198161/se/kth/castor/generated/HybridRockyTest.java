package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetFontName() throws Exception { FontType0 ft1 = createDummy(); Assertions.assertNull("No Name",ft1.getName()); String sname="NewName"; ft1.setFontName(sname); COSDictionary dict = ((PDCIDFontType2)ft1).toPDStream().getCOSDictionary(); PDDocument doc = mock(PDDocument.class); when(doc.isEncrypted()).thenReturn(false); when(dict.containsKey(new COSName("/BaseFont"))).thenAnswer((invocationOnMock -> true)); assertEquals("Wrong BaseFont","Times-Roman",dict.getStringValue(new COSSimpleParser())); assertNotNull("Missing /Encoding entry in dictionary",dict.getEntryIfPresentAndOfClass(COSName.ENCODED_CHARACTERS,"C")); assertTrue("Missing \""+sname+"\" as a key to an encoding dictionary.",dict.keyContainsPrefixOrStarsWith(COSName.build(sname))); }

}