package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationSquareCircleRockyTest {

@Test public void testGetSetBDClipBox() throws IOException { PDBorderEffectDictionary dic2 = new PDBorderEffectDictionary(); assertNull("No clip box",dic2.getClipping()); COSArray arr1 = new COSArray(); arr1.add(new COSFloat(-50));arr1.add(new COSInteger(768934));arr1.add(new COSInteger(575865));arr1.add(new COSFloat(6645));dic2.setClipping(arr1); assertEquals("clip array","[ -50 768934 575865 6645 ]",dic2.toPDFString(),"Wrong clippng"); }

}