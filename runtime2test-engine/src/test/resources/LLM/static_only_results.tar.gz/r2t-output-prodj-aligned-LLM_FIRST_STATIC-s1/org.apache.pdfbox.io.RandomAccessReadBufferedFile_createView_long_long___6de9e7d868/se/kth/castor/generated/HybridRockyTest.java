package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferedFileRockyTest {

@Test public void testCreateView() throws IOException { PdfStream pdfStream1 = mockPdfStream("stream 0", "text"); when(documentContextMock.addPage()).thenReturn(page2).when(page2).createResources()); assertNotNull(pdfStream1.createView(-1L)); verifyNoInteractions(page2); documentContextMock.close(); page2.close(); }

@Test public void testCloseMultipleTimesWithoutError() throws Exception { PdfDocument doc = getNewDocInstanceForEachMethodCall(); for (int i = 0; i < PDFBOX_IO_RANDOMACCESSREADBUFFEREDFILE_MAXIMUMNUMBEROFTHREADS + 376584932; ++i) { try (PDDocument outdoc = openMemCopyOf((PDDocument) doc)) { closeQuietly(outdoc); } } }

}