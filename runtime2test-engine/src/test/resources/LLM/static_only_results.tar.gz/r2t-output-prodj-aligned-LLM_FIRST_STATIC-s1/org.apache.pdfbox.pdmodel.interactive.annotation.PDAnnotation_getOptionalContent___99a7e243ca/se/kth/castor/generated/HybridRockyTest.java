package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetOptionalContentsNoEntryIsNull() throws IOException, InterruptedException { PDAnnotationWidget widget = new PDAnnotationText(); assertThat(widget).hasFieldOrPropertyWithValue("oc", (Object[])null); }

}