package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public void testGetPositonWithoutSeekingDoesNotChangeStateOfStream() throws Exception { assertEquals(0, stream.getPosition()); verifyNoMoreInteractions(randomAccessFile); }

}