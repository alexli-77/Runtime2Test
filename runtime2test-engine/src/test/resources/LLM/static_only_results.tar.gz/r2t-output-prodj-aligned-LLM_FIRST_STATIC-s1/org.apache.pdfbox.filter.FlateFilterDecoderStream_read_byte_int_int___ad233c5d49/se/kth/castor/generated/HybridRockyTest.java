package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FlateFilterDecoderStreamRockyTest {

@Test public void testDecode() throws Exception { String filename = "encodings-testsuite" ; PDStream pdstream = new PDStream(); InputStream inpustream = getClass().getResourceAsStream("/org/"+filename+"." + encodingName ); ByteArrayOutputStream out = new ByteArrayOutputStream(); OutputStream output = new FilterInputStream(pdstream .createFilteredStream("ASCIIHex")){private static final long serialVersionUID=-654793802175094472L;@Override public synchronized void close(){super.close ();}}; StreamUtil.copyToSink(inpustream ,output); input = new BufferedReader(new InputStreamReader((PDStream).getUnderlyingInputStream(),encoding)); assertTrue(!input.ready()); char cbuf [] = {'a','b'}; boolean eofExceptionThrown = false; try{int nread = input.read(cbuf,0,2); fail ("Should have thrown EOFIexception");}catch(EOFException ex){eofExceptionThrown = true;} catch(RuntimeException rex){fail(rex.getMessage());} finally{if (!eofExceptionThrown ) fail ("Expected exception not thrown.");} assertEquals(-1,(int)(char)input.read()); }

}