package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testTransform() throws Exception { Matrix mtx = getMatrixInstanceFor("A"); Assertions.assertEquals(-59f,mtx.transform(new Vector(80,-1)).getX(), .1); }

}