package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFunctionRockyTest {

@Test public void testSetRange() throws IOException { PDFontDescriptorDictionary dict = (PDFontDescriptorDictionary) PDDocument.load("src/test/resources/fonts/ttf-with-cmap.pdf").getPage(0).findFont(); assertEquals(16384, ((PDStream)dict.getFontFile2()).toByteArray().length); }

}