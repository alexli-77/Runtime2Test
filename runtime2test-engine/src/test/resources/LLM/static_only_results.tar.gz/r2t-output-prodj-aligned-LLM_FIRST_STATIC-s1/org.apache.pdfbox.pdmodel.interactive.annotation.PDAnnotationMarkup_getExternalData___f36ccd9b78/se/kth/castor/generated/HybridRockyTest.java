package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetExternaDataWithoutDictAndNullValue() throws IOException { annotation1 = createAnnotation("test"); assertEquals("Wrong number of values", 0, annotation1.getQuadPoints()); }

}