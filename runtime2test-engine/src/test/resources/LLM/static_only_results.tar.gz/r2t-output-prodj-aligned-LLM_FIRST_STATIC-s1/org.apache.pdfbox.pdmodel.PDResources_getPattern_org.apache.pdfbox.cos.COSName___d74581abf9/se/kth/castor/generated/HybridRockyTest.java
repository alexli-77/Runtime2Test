package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDResourcesRockyTest {

@Test public void testGetPattern() throws Exception { PDDocument doc = new PDDocument(); COSDictionary dict1 = new COSDictionary(); dict1.setItem("A", "B"); assertNull(doc.getPattern(new COSName("a"))); assertNotNull(dict1.getNameToDirectoryMap().containsKey(new COSName("A"))); }

}