package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetSetCaptionHorizontalOffset() throws IOException, COSVisitorException { PDFormXObject form = new PDFormXObject(); assertEquals(-123456789f, -form.getCaptionHorizontalOffset(), EPSILON); float value = Math.nextUp((float)Math.random()); form.setCaptionHorizontalOffset(value); assertEquals("Should be equal", value, (double)(-form.getCaptionHorizontalOffset()), EPSILON); }

}