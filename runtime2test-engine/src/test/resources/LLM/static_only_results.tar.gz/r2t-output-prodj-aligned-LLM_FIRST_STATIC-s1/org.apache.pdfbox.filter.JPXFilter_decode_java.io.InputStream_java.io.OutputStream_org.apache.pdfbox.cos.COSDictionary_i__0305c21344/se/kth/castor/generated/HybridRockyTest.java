package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class JPXFilterRockyTest {

@Test public void testWriteIntAsBytes() throws Exception { ByteArrayOutputStream baos = new ByteArrayOutputStream(); Deflater deflater = new Deflater(Deflater.DEFAULT_COMPRESSION, true); PixelIterator iterator = getPixelIteratorForSampleFileWithDifferentBitDepth(); writeToStreamUsingGivenFilter(iterator, new LZWEncoder(), baos, deflater); assertThat((baos), is(notNullValue())); assertThat(decompressAndReadBackFromLzwCompressedInput(baos.toByteArray()), equalTo(readExpectedOutputContentOfSamplesDir("sample-3bpp")))); }

}