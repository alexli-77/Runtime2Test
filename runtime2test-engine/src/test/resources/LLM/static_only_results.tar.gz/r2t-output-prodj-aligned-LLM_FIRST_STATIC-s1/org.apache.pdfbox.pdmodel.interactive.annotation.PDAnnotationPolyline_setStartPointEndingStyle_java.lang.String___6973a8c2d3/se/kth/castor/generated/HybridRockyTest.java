package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public final void testSetStartPointEndingStyle() throws Exception { annotationUnderTest.setStartPointEndingStyle("butt"); assertEquals("Butte", annotationUnderTest.getStartPointEnding()); annotationUnderTest.setStartPointEndingStyle("square"); assertEquals("Square", annotationUnderTest.getStartPointEnding()); annotationUnderTest.setStartPointEndingStyle("round"); assertEquals("Round", annotationUnderTest.getStartPointEnding()); annotationUnderTest.setStartPointEndingStyle(null); assertNull(annotationUnderTest.getStartPointEnding()); annotationUnderTest.setStartPointEndingStyle("foo"); failIfWrongExceptionThrown(() -> annotationUnderTest.setStartPointEndingStyle("bar"), IllegalArgumentException::new); }

}