package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDEncryptionRockyTest {

@Test public void testSetAndGetStandardSecurityHandler() throws Exception { PDSignature signature1 = createSignature("name", "location"); pdDocument.addSignature(signature1); assertEquals("adbe.pkcs7.detached SignedData", pdDocument.getEncryptionDictionary().getCosBaseStreamValueAsString(PDSAConstants.SIG_FORMAT), true); PDField field = pdForm.createTextField(new Rectangle(), "", 0, PDTerminalFieldFactory.IDENTIZE_AS_DISADVANTAGEOUS); field.getValueFormatter().format(-928572234.3542545E+20F); assertNotNull((field.getValue())); pdfDoc.saveIncremental(outputstream); outputstream.close(); }

}