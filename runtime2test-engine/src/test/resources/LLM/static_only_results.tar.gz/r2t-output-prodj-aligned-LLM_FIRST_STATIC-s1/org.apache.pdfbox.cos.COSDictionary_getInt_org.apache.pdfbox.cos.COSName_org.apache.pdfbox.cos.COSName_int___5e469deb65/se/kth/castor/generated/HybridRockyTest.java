package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetInteger() throws IOException { PDDocument doc = new PDDocument(); PDFont font = createFont("Helvetica", "winansi"); assertNotNull(font); COSDictionary dict = font.getCOSStream().getDict(); Integer one = new Integer(1234567890); dict.setItem(new COSArray(), "WMode"); dict.setLongAndRemoveRestOfLineIfPossible(one); dict.removeItem(CosStandardConstants.DICTIONARY_KEY_TYPE); String type = font.getNameAsString("/Type"); Assertions.assertEquals(type,"/Font"); doc.close(); }

}