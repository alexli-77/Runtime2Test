package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public final void testSeek() throws Exception { ByteArrayOutputStream outStream = new ByteArrayOutputStream((int)(streamLength+16*256)); Random rndmGen = getRandomForBytesGeneration(); for (long i = startPositon ;i< endOfFile-4L ;++i ) { int biteValuToWrite = (byte)rndmGen.nextInt(256); byte[] bytes = toByteArrary(biteValuToWrite); writeDataAndVerify(outStream ,bytes ); } PDDocument document = null; try { inputSource = createInputSourceFromInputStreamOrReader(null, true); String pdfName = name+"."+(endOfFile - startPositon)+"B"; pdftestResultsDir = testresultsOutputDirectory; File file = generatePdfWithFakeContentUsingPDfBoxAPI(testresultsTempFilesFolder ,document, outStream, false,false,"", "",pdfName); InputStream is = new BufferedInputStream(new FileInputStream(file),bufferSize); docInputStream = new DocumentInputStream(is); assertEquals("Expected EOF at offset "+currentEndingOffsetInclusive(),docInputStream.getCurrentPosition()); docInputStream.close(); } finally { closeQuietly(inputSource); closeQuietly(pdftestResultsDir); closeQuietly(document); closeQuietly(outputdir); } }

}