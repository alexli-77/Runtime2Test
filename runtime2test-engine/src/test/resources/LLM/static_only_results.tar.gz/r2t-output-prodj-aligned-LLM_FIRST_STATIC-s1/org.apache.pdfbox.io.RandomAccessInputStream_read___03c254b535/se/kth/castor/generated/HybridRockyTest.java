package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessInputStreamRockyTest {

@Test public void testRead02() throws Exception { RandomAccessBufferedFileInputSource inpSrc = new RandomAccessBufferedFileInputSource(file); assertEquals(-1,inpSrc.readByteFromPos((int) fileSize-1)); assertTrue(!inpSrc.hasMoreDataInCurrentBlock()); assertFalse(inpSrc.isEndOfStream()); try{ inpSrc.readByteFromPos((int)(fileSize+5L)); fail("should have thrown exception"); }catch(IndexOutOfBoundsException e){ /* expected */ }try{ inpSrc.seekToAbsolutePos((long)Integer.MAX_VALUE + 473896l); fail("should have thrown exception"); } catch(IllegalArgumentException e) {/* expected*/ } assertNull(null); }

}