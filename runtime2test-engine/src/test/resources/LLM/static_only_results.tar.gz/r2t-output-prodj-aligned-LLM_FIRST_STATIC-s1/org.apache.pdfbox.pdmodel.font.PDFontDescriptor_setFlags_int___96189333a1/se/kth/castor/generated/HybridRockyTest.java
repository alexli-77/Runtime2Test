package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetFontDescriptor() throws IOException { Font fd1 = PDType0Font.load("src/test/resources/fonts", "FreeSerif-BoldItalic.ttf"); Font fd2 = PDType3CharProc.createWithContentStreamAndResources(new StringBuffer(), null).getDescendantResource().getFont(); assertEquals(-4879656L, ((PDType0Font)fd1).fontEncoding.toUnicode((char)3)); assertNotNull(fd2.getBaseFont()); }

}