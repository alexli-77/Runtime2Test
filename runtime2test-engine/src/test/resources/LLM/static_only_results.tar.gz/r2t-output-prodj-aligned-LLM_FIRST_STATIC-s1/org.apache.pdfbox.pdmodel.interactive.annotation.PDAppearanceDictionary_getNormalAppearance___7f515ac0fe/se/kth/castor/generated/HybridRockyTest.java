package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceDictionaryRockyTest {

@Test public void testGetCOSDictionaries2() throws IOException, InterruptedException { PDAcroForm acroForm = pdfDocument.getAcroForm(); assertNotNull("There should have been an Acroform.",acroForm );PDPushButtonField pushbuttonfield1 = acroForm.getField("Push Button"); assertNotNull("A field with name 'Push button' was missing from the document",pushbuttonfield1 );CosDictionary dictobj = pushbuttonfield1 .getWidget().getCOSDictionary ();assertEquals ("Wrong type for widget","Btn",dictobj .getNameAsString()); COSBasedSequence sequenceobj = new CosBasedSequence((COSDictionary)(dictobj .getValue()));List<COSItem> itemslist =sequenceobj.asArrayList();int size =itemslist.size();for ( int i =0 ;i < size ;++i ) {if ( !(itemslist.get(i).isDirect()) && (!(itemslist.get(i).isEmpty()))){throw new RuntimeException("Error.");}}assertTrue("We had more than two entries!",itemslist.size () <= 3); assertFalse("One element should have been removed by trimming.",itemslist.contains(new Integer(-4))); }

}