package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStreamRockyTest {

@Test public void testCreateViewWithFiltersAndEmptyDataShouldReturnNull () throws Exception { PDMemoryDestination destination = new PDMemoryDestination (); assertThat ("Expected empty input for empty data", destination .createView()).isEqualTo(null); }

}