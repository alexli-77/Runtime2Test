package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testGetFontfile2() throws IOException, Exception { PDType1Font ttfont = load("TT-Standard"); assertThat((ttfont).getFontDescriptor().getFontBoundingBox()).isEqualTo(new PDFontGeometry(0f, -685.9374f, 1000f, 794.9374f)); String name = "Courier"; boolean ok = false; try { FontProgram fp = ttfont.toUnicodeFont(); Assertions.fail(); } catch (@SuppressWarnings({"unused", "squid:S00112"}) RuntimeException e) { ok |= checkMessageContains(e, "Cannot create Unicode mapping for ", name + "-Identity-H"); } finally { ok &= !checkMessageNotPresent(name + ".afm", e -> logger.atDebug().addArgument(() -> e).log()); ok &= !checkMessageNotPresent(name + ".ufm", e -> logger.atDebug().addArgument(() -> e).log()); ok &= !checkMessageNotPresent(".notdef", e -> logger.atDebug().addArgument(() -> e).log()); Assertions.assertTrue(ok, ()->"Didn't find any error messages."); } }

}