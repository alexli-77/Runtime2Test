package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLineRockyTest {

@Test public void testGetEndPointEndingStyleNone() throws Exception { PDAppearanceStream appearanceStream = new PDAppearanceStream(); COSDictionary cosDict = new COSDictionary(); COSBase base = COSInteger.ZERO; cosDict.setItem("L", base); PDFont font = mock(PDFont.class); whenNew(PDCosScannerFilterInputStream.class).withArguments((InputStream) any()).thenReturn(mock(PDCosScannerFilterInputStream.class)); try (ByteArrayOutputStream outContent = new ByteArrayOutputStream()) { try (PDDocument doc = new PDDocument()) { doc.addPage(new Page()); pdAnnot = new PDAnnotationTextMarkup(doc); pdAnnot.setContents(base); pdAnnot.constructAppearances(); annotationStub = pdfBoxLoader.createStubFromAnnotationAndField(appearanceStream, pdAnnot, font); assertEquals(0, annotationStub.length()); } catch (@SuppressWarnings("unused") RuntimeException e) {} finally { verifyNoMoreInteractions(font); resetMockedFont(); } } }

}