package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetPopUpNullIfNotPresent() throws IOException, InterruptedException { PDDocument doc = Loader.loadPDF("annotations"); PDFont font = PDType1Font.HELVETICA; AcroForm form = new AcroForm(); doc.setAcroForm(form); List<PDPage> pages = doc.getPages(); PDAcroForm acroForm = createAnnotatedFieldsForTextWidgetsWithAndWithoutAPopup(doc, pages.get(0), font); assertThat((acroForm).getField("text2").retrieveValue()).isEqualToIgnoringCase("some value 4567890 some other value "); }

}