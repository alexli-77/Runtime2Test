package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadBufferRockyTest {

@Test public void testLength1059682347() throws IOException, InterruptedException { final String contents = "This is the content of this file"; writeToFile(contents); assertEquals("Wrong number of bytes written", 33L + contents.getBytes().length, f.length()); }

@Test public void testAvailable1059682347() throws IOException, InterruptedException { final int availability = f.available(); LOGGER.info(() -> Integer.toString(availability) ); Assertions.assertTrue((availability == 0), ()->Integer.toString(f.read())+""); }

}