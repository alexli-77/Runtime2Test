package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSDictionaryRockyTest {

@Test public void testGetBoolean() throws IOException { PDFont font = PDType1Font.HELVETICA; Assertions.assertTrue((font).getFlags().getFlag("Subset", FONTBBOX)); }

}