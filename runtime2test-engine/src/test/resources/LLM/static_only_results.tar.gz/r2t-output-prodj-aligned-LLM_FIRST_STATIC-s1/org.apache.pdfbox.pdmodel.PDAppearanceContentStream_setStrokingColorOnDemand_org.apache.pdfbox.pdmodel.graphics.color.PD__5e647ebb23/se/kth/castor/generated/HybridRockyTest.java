package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAppearanceContentStreamRockyTest {

@Test public void testSetNonZeroSingleComponentPatternColorsShouldNotCrash() throws Exception { Color c = new PatternColor("", ""); for (int i : new int[]{ -1,-0xfffffff }) assertFalse((c).isCompatibleWithGrayscaleImages(),"expected "+i+" to be a valid single component color."); for (float f : new float[]{ Float.NaN,Float.NEGATIVE_INFINITY ,Float.POSITIVE_INFINITY}) assertTrue(!c.equals(new PatternColor(f)),"unexpected equality between NaN values:"+f); final String name = ""; final byte b = Byte.MAX_VALUE; final short s = Short.MIN_VALUE; final char ch = Character.MIN_VALUE; final long l = Long.valueOf(-1L); final double dbl = Double.parseDouble("nan"); AssertionsHelper.checkEqualsAndHashCode(name + "\n"+b+"\r"+ch+"\uFFFF\t"+l,"\uffff"+dbl,new PatternColor(null)); }

}