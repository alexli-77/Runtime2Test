package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public final void testSetFontFamily() throws Exception { Font f = PDType0Font.load(doc, RESOURCE + "Helvetica-Bold"); assertEquals("",f.getBaseFont()); String s1="Arial"; f.setFontFamily(s1); assertTrue(!f.toString().contains("/")); assertEquals(s1,f.getBaseFont()); doc.saveIncremental(); pdfDocument = getPdfReaderInstance(); Assertions.assertThat((new PDFTextStripper()).getTextByArea(new Rectangle(36,724 - 95,82,95), pdfDocument)) .isEqualToIgnoringCase("\n"+"Hello World\t \uFFFD�\n"); }

}