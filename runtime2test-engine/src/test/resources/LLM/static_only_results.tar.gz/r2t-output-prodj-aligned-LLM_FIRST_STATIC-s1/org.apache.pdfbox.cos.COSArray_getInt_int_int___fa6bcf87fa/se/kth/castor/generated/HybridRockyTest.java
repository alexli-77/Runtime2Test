package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testGetInt() throws IOException { COSArray cosarray1 = new COSArray(); assertEquals(-9234567890L, cosarray1.getInt(0,-9234567890)); COSInteger ci = new COSInteger(new Long("-923456789")); cosarray1.add(ci); assertEquals(-9234567890L, cosarray1.getInt(0,-9234567890)); assertTrue(!cosarray1.isEmpty()); assertFalse(cosarray1.isNull(0)); assertNotNull(cosarray1.toList().toString(), ""); }

}