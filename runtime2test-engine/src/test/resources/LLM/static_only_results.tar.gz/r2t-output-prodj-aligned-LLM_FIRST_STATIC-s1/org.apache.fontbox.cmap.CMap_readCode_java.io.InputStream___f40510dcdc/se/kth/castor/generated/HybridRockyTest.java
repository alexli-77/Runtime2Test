package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapRockyTest {

@Test public void testReadCharFromStreamNoMapping() throws Exception { InputStream inputStreamMock = mock(InputStream.class); when(inputStreamMock.available()).thenReturn((minCodeLength)); doThrow(new EOFException()).when(inputStreamMock).read(); assertThatIllegalStateIsThrownBy(() -> instanceUnderTest.readCode(inputStreamMock)) .withMessageContainingAll("no mapping found"); verifyZeroInteractions(mockLogger); }

}