package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testGetString() throws Exception { String result = cosArray.getString(-1032947865, "default"); assertEquals("default",result); result = cosArray.getString( -1,"default"); assertNull(result); result = cosArray.getString(1,null); assertNotNull(result); }

}