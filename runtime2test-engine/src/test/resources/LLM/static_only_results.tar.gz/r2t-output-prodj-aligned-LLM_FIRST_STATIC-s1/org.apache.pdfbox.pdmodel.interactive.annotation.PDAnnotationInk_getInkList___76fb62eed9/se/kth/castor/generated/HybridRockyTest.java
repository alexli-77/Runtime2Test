package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationInkRockyTest {

@Test public void testGetSetInkList() throws IOException { PDAnnotationWidget widget1 = new PDAnnotationTextMarkup(PDRectangle.A4).createDefaultAppearanceDictionary("Helvetica").setOpacity(0.5f).buildNormalAppearenceFromResourcesDirectory("/com/tom_eckstein/test/resources"); assertEquals(null, widget1.getCOSDictionary().getItem(org.apache.pdfbox.cos.COSName.IC)); COSDocument doc = new COSDocument(); PDFont font = new PDSimpleFont(); PDBorderEffectFormat borderEffectFormat = new PDBorderEffectFormat(); PDAcroForm acroform = new PDAcroForm(doc); acroform.addSubstituteFontsEntry(font); PDPage page = new PDPage(new PDRectangle()); PDPushButtonField field = new PDPushButtonField(acroform); page.getAnnotations().add(field); try { field.drawBorderAndBackground(page, rectanglesForDrawing(), true); fail(); } catch (IOException e) {} byte[] data = IOUtils.toByteArray((InputStream) field.getValueAsPDFStream()); ByteBuffer bb = ByteBuffer.wrap(data); System.out.println(bb.asCharSequence()); }

}