package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDShadingRockyTest {

@Test public void testSetGetBackground() throws IOException { PDShadingPattern pattern1 = new PDShadingPattern(); document.getResources().addResource("pattern", pattern1 ); assertNull (pattern2 . getBackground()); pattern2 . setBackground((PDColorSpace ) null); assertEquals ("null", ((org.apache.pdfbox.pdmodel.graphics.shading.PDAbstractShadingXObject)(document.getPage(0).findMarkedContentReferenceByIdentifier("MCID-4").getPdfDictionary().getDirectValueAsString()) ).toPDFStream(document), true); }

}