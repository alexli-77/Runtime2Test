package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDTargetDirectoryRockyTest {

@Test public final void testGetName() throws Exception { org.junit.Assert.assertEquals("Hello World", obj.getName()); }

}