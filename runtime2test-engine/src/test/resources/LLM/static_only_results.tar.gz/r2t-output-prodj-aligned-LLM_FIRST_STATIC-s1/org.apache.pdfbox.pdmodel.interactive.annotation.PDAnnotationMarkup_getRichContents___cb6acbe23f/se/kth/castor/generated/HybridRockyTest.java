package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationMarkupRockyTest {

@Test public void testGetRichContents() throws IOException, ParseException { PDAnnotation widget = new PDAnnotationWidget(); String rc1 = "{\\rtf{Hello World!}}"; COSDocument doc = createRTFDocFromString("", false); COSStream cosrc1 = createCosStreamWithContentAndFilters(doc, rc1, PDFFilterConstants.FILTER_NONE, true); assertNotNull(cosrc1); widget.setItem(COSDictionary.ITEM_KID, cosrc1); String contents = widget.getRichContents(); System.out.println("\n" + contents); Assertions.assertEquals("\\par Hello World!\r\n", contents);  }

}