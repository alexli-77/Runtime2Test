package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationLinkRockyTest {

@Test public void testGetAction() throws IOException { try (InputStream inputStream = new FileInputStream("src/test/resources/annotation-actions.pdf")) { PDDocument document = Loader.loadPDF(inputStream); List<PDAnnotation> annotations = document.getPageByNumber(1).getAnnotations(); assertEquals(3, annotations.size()); for (int i = 0 ;i < annotations . size (); ++i ) { if ("".equals((annotations.get(i)).getName())) continue; String name = ((PDAnnotationWidget)(annotations.get(i))).getContents(); switch (name) { case "No Action": assertNull((annotations.get(i)).getAction(),"Unexpected value found"); break; default: fail("Unknown Annotation Name:" + name ); } } } finally { IOUtils.closeQuietly(document); } }

}