package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testToCosArrayMatrix2x2() throws Exception { assertEquals("[[ 1f,  0], [ 0, -1]]", ArrayUtilities.toDoubleString((matrix).getSingle(), false)); }

}