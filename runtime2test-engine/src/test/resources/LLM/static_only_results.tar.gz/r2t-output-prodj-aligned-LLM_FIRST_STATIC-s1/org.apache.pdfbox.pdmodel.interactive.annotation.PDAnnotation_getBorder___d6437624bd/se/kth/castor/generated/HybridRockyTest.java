package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetDefaultAndNoValueSetThenReturnedShouldBeTheSameInstanceForCosNullOrEmpty() throws Exception { assertEquals("If no values were set before getting them they should all " + "be zero", expectedResult, style.getPadding()); }

}