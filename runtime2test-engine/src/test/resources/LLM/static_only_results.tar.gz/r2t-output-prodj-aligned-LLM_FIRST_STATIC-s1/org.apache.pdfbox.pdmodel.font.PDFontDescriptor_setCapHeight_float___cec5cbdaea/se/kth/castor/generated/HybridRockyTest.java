package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFontDescriptorRockyTest {

@Test public void testSetCapHeight() throws Exception { PDFont pdfFont = PDType1Font.HELVETICA; assertEquals("Expected default value to be " + DEFAULT_VALUE, -205, (int)(DEFAULT_VALUE*PDFontUtils.FONTSIZE)); float expectedValue = .34f; pdfFont.setCapHeight((expectedValue)*PDFontUtils.FONTSIZE); String keyToCheckForInDictionary = org.apache.fontbox.afm.AFMParser.KEY_CHEIGHT; AFM afmFile = AFMPreparator.getAFMFromPdfBoxFontAndKeyString(pdfFont,"",keyToCheckForInDictionary); assertTrue("Did not find a match in dictionary for "+keyToCheckForInDictionary+" with actual value of"+afmFile.metrics[8].getValue(),Arrays.stream(afmFile.metrics).filter(x -> x.getName().equalsIgnoreCase(keyToCheckForInDictionary)).findFirst().isPresent()); }

}