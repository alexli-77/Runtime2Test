package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationRockyTest {

@Test public void testGetCOSDictionaryNullReturnedIfKeyDoesNotExistInDictionary() throws Exception { assertThat("Should have been able to find value", pdAnnotationUnderTest.getCOSDictionary(null), CoreMatchers.<COSDictionary>equalTo((COSDictionary) null)); }

}