package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationWidgetRockyTest {

@Test public void testGetActionNoExist() throws Exception { assertNull("There should be no action.", formField.getActions()); }

}