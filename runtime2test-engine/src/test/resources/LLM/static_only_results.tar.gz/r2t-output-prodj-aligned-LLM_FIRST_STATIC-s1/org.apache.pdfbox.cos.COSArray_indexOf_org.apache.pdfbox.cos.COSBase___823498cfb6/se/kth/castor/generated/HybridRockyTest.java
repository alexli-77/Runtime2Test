package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSArrayRockyTest {

@Test public void testIndexOf() throws IOException { PDDocument doc = new PDFParser().parse("target/test-classes/" + filename, "UTF8"); COSArray array = ((PDStream)doc.getPage(2).getResources()).getContentsAsArray(); assertEquals(-1,array.indexOf(null)); array.add((float)3.56749); float[] fArr = {-3f,-2f}; array.toFloatArray(); assertTrue(MathUtils.isEqual(-3f ,array.toFloatArray(), MathUtils.FLOAT_ROUNDING_DIGITS ) ); try{ array.removeRange(0,2); fail("Should have thrown an exception."); } catch(IllegalArgumentException e){ assertNotNull(e); } }

}