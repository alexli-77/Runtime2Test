package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class COSStringRockyTest {

@Test public void testGetStringWithUnicodeBomUtf8() throws Exception { byte[] bb = "test".getBytes("utf-8"); bb = addByteSequenceToArray(bb, UNICODE_BYTE_ORDER_MARK_UTF8); assertEquals("\uFEFFt\u00E9st", cosStringFor(bb).getString()); }

}