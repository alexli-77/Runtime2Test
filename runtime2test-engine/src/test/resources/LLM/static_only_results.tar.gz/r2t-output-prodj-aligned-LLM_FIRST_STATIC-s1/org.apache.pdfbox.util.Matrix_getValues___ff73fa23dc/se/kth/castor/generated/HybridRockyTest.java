package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixRockyTest {

@Test public void testGetValuesSingleDimensionArrayOfAllValuesInTheMatrix() throws IOException, COSLoadException { PDFMatrix mtx = new PDFMatrix(new PDRectangle()); assertEquals("Wrong number of rows", 3, mtx.getValues().length); }

}