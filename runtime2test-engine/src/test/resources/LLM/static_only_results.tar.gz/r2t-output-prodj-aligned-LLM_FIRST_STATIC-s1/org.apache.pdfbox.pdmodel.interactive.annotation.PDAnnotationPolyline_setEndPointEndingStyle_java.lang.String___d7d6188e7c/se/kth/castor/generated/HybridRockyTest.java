package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDAnnotationPolylineRockyTest {

@Test public final void testSetStartAndEndPointsWithDifferentStyles () throws IOException { PDPermissiveDocumentCatalog catalog = this.testPdfFile.openCatalog(); assertNotNull("catalog is not available", catalog); PDAcroForm form = catalog.getAcroForm (); assertNotNull ("acroform is missing in PDF document " + this.testFileName , form ); List<PDPage> pages = this.testPdfFile .getPages(); int pageCount = pages != null?pages.size():0 ; assertTrue(pageCount > 5); Iterator iterator = pages.iterator(); while (iterator.hasNext()) { PageWrapper pw = new PageWrapper((PDPage ) iterator.next()); boolean found = false; COSDictionary annotDict = findAnnotByTypeInsideOfAPage(pw,"Text"); while (!found && (annotDict!=null)){ try{ String value = ""; COSBase baseValue = annotDict.getDirectObject(org.apache.pdfbox.cos.COSName.CONTENTS); if (baseValue instanceof COSStream){ value = IOUtils.toString(new InputStreamReader((InputStream)( (COSStream)baseValue ).createRawInput(), StandardCharsets.UTF_8),StandardCharsets.UTF_8); }else if (baseValue instanceof COSFloat||baseValue instanceof COSInteger){ value += Double.valueOf(Double.parseDouble(baseValue.toString())); }value+=annotDict.getNameAsString(org.apache.pdfbox.cos.COSName.SUBTYPE)+"-"+annotDict.getString(org.apache.pdfbox.cos.COSName.RECT).replaceAll(",","."); }catch(Exception e){ System.out.println("WARNING! "+e+"\nCould not read annotation content from file!"); continue;}if (value.contains(".Rectangle")){ found = true; break; }} if(!found ){ fail("No rectangle annotations were found inside of a page and I was looking for them on file:"+ this.testFileName);}} }

}