package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CMapRockyTest {

@Test public void testGet() throws Exception { assertEquals("A", new StringCharacterSet().toUnicode((char)(97), 1)); }

}