package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PDFormXObjectRockyTest {

@Test public void testGetGroupWithoutAttrDictShouldReturnEmptyInstance() throws IOException { PDFormXObjects pdForms = new PDFormXObjects(); COSStream stream1 = createDefaultPdfDocument().createUnfilteredStream("x"); pdForms.addSubstream(new PDFormXObject(new PDPixelMap())); assertNull(pdForms.getLastNonNullDictionaryEntry()); assertTrue(pdForms.isEmpty()); assertEquals(0, pdForms.size()); try (InputStream is = pdForms.exportAsString()) {} catch (IOException ex) { fail("No exception should be thrown."); } final String expectedContent = "q\n" + "\nQ"; byte[] resultByteArray = IOUtils.toByteArray(is); assertNotNull(resultByteArray); assertFalse(resultByteArray.length > 256); for (byte b : resultByteArray) { assertThat((char)b).describedAs("%d", (int)(char)b).matchesAnyOf(' ', '\r', '\t'); } final List<Integer> lineLengthList = Arrays.asList(-43987, -43987, -43987, -43987, -43987, -43987, -43987, -43987, -43987, -43987, 'e', 'n', 'd', 'o', 'c', 'h', 'p', '_', '-', 'l', 'i', 'm', 'a', '.', '/', 'v', 'u', 'g', '/', '%', 'f', 'o', 'r', 'm', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '#', '$', '@', '^', '"', '{', '|' ,'}', ';', '!', '~').mapToInt(Character::codePointAt); Collections.shuffle

}