package se.kth.castor.generated;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomAccessReadViewRockyTest {

@Test public void testIsEofTrueWithoutRestore() throws Exception { assertThat("Should be EOF", pdfStreamSourceMockedInputOnlyRandomAccessInputStream.getPdfBoxFileSystemResource().isEOF(), equalTo(true)); }

}